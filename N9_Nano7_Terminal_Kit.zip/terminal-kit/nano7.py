#!/usr/bin/env python3
"""Terminal-only, evidence-driven Ghidra research helpers. No Apple firmware included."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time
import xml.etree.ElementTree as ET
import zipfile

KIT = Path(__file__).resolve().parent


def fail(message):
    raise SystemExit(message)


def sha256(path):
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def existing_file(value):
    path = Path(value).expanduser().resolve()
    if not path.is_file():
        fail(f"File does not exist: {path}")
    return path


def ghidra_root():
    override = os.environ.get("NANO_GHIDRA_ROOT")
    if override:
        root = Path(override).expanduser().resolve()
    else:
        try:
            prefix = subprocess.check_output(["brew", "--prefix", "ghidra"], text=True).strip()
        except (FileNotFoundError, subprocess.CalledProcessError):
            fail("Install ghidra with Homebrew, or set NANO_GHIDRA_ROOT to a complete installation.")
        root = Path(prefix) / "libexec"
    if not (root / "support" / "analyzeHeadless").is_file():
        fail(f"Not a complete Ghidra installation: {root}")
    return root


def languages():
    for path in sorted((ghidra_root() / "Ghidra" / "Processors").glob("*/data/languages/*.ldefs")):
        for language in ET.parse(path).getroot().findall("language"):
            yield {
                "id": language.get("id", ""),
                "processor": language.get("processor", ""),
                "endian": language.get("endian", ""),
                "bits": language.get("size", ""),
                "compilers": [item.get("id", "") for item in language.findall("compiler")],
            }


def workspace(value):
    root = Path(value).expanduser().resolve()
    for name in ("originals", "extracted", "projects", "exports", "notes", "logs", "tests"):
        (root / name).mkdir(parents=True, exist_ok=True)
    return root


def inspect(args):
    path = existing_file(args.image)
    result = {
        "input": str(path), "bytes": path.stat().st_size, "sha256": sha256(path),
        "source_url": args.source_url, "model": args.model, "build": args.build,
        "interpretation": "inventory only; executable format, encryption, ISA and model not established",
    }
    with path.open("rb") as stream:
        result["first_64_bytes_hex"] = stream.read(64).hex()
    if zipfile.is_zipfile(path):
        with zipfile.ZipFile(path) as archive:
            result["zip_entries"] = [
                {"name": item.filename, "bytes": item.file_size,
                 "stored_bytes": item.compress_size, "encrypted_flag": bool(item.flag_bits & 1)}
                for item in archive.infolist()
            ]
        result["zip_note"] = "Archive listing only. Entries are not extracted or executed."
    text = json.dumps(result, indent=2, ensure_ascii=True) + "\n"
    if args.out:
        with Path(args.out).expanduser().open("x", encoding="utf-8") as stream:
            stream.write(text)
    print(text, end="")


def carve(args):
    path = existing_file(args.image)
    offset, length = int(args.offset, 0), int(args.length, 0)
    if offset < 0 or length <= 0 or offset + length > path.stat().st_size:
        fail("Extraction range is outside the input file or has zero length.")
    out = Path(args.out).expanduser().resolve()
    if out == path or out.exists():
        fail("Output must be a new file separate from the input.")
    manifest = out.with_name(out.name + ".extraction.json")
    if manifest.exists():
        fail(f"Extraction manifest already exists: {manifest}")
    with path.open("rb") as source, out.open("xb") as target:
        source.seek(offset)
        remaining = length
        while remaining:
            chunk = source.read(min(1024 * 1024, remaining))
            if not chunk:
                fail("Input changed or was truncated during extraction; output is incomplete.")
            target.write(chunk)
            remaining -= len(chunk)
    result = {"input": str(path), "input_sha256": sha256(path), "offset": offset,
              "length": length, "output": str(out), "output_sha256": sha256(out),
              "evidence": args.evidence}
    manifest.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2))


def analyze(args):
    image = existing_file(args.image)
    root = workspace(args.workspace)
    if not re.fullmatch(r"[A-Za-z0-9_-]+", args.project):
        fail("Project name must contain only letters, digits, underscore or hyphen.")
    if any((root / "projects" / (args.project + suffix)).exists() for suffix in (".gpr", ".rep")):
        fail("Project already exists. Choose a fresh --project name; existing projects are never overwritten.")
    if min(args.analysis_seconds, args.function_seconds, args.export_seconds) <= 0:
        fail("Time limits must be positive.")
    if args.function_seconds > 3600 or args.export_seconds > 86400:
        fail("Maximum per-function time is 3600 seconds; maximum export time is 86400 seconds.")
    if not 1 <= args.max_functions <= 1000000:
        fail("--max-functions must be between 1 and 1000000; exports also have a time budget.")
    extra = []
    if args.mode == "raw":
        if not all((args.language, args.compiler, args.base, args.evidence_note, args.evidence)):
            fail("Raw import requires --language, --compiler, --base, --evidence-note and --evidence TSV.")
        choices = {item["id"]: item for item in languages()}
        if args.language not in choices or args.compiler not in choices[args.language]["compilers"]:
            fail("Language/compiler pair is not in this installation. Run the languages command.")
        try:
            base = int(args.base, 0)
        except ValueError:
            fail("--base must be an explicit decimal or 0x-prefixed address.")
        if base < 0:
            fail("--base cannot be negative.")
        extra = ["-loader", "BinaryLoader", "-processor", args.language, "-cspec", args.compiler,
                 "-loader-baseAddr", f"{base:x}"]
    elif args.language or args.compiler or args.base:
        fail("Use --mode raw for an explicitly configured language/compiler/base.")
    evidence = existing_file(args.evidence) if args.evidence else None
    run = root / "exports" / args.project
    run.mkdir(exist_ok=False)
    result_dir = run / "result"
    cmd = ["/bin/bash", str(KIT / "bin" / "ghidra-headless"),
           str(root / "projects"), args.project, "-import", str(image), *extra,
           "-scriptPath", str(KIT / "scripts"), "-max-cpu", "2",
           "-analysisTimeoutPerFile", str(args.analysis_seconds),
           "-log", str(run / "analysis.log"), "-scriptlog", str(run / "script.log")]
    if evidence:
        cmd += ["-preScript", "NanoApplyEvidence.java", str(evidence)]
    cmd += ["-postScript", "NanoExport.java", str(result_dir), str(args.max_functions),
            str(args.function_seconds), str(args.export_seconds)]
    manifest = {"input": str(image), "input_sha256": sha256(image), "mode": args.mode,
                "language_requested": args.language, "compiler_requested": args.compiler,
                "base_requested": args.base, "evidence_note": args.evidence_note,
                "evidence_file": str(evidence) if evidence else None,
                "evidence_sha256": sha256(evidence) if evidence else None,
                "command": cmd, "started_unix": time.time(),
                "interpretation": "Analyst configuration; successful export does not validate its correctness."}
    manifest_path = run / "invocation.json"
    manifest_path.write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    with (run / "console.log").open("w", encoding="utf-8") as log:
        process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                   text=True, errors="replace", stdin=subprocess.DEVNULL)
        try:
            for line in process.stdout:
                print(line, end="", flush=True)
                log.write(line)
            code = process.wait()
        except KeyboardInterrupt:
            process.terminate()
            process.wait()
            fail("Interrupted; project/export may be incomplete. Use a fresh project name on retry.")
    manifest.update(returncode=code, finished_unix=time.time())
    marker = result_dir / "EXPORT_COMPLETE.tsv"
    manifest["export_marker_present"] = marker.is_file()
    manifest_path.write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    if code or not marker.is_file():
        fail(f"Analysis/export did not finish successfully. Inspect {run / 'console.log'}")
    if evidence:
        expected = f"NANO_EVIDENCE_APPLIED {sha256(evidence)}"
        if expected not in (run / "console.log").read_text(encoding="utf-8"):
            fail("Evidence script did not report successful application; inspect logs before trusting this run.")
    print(f"\nReports: {result_dir}\n{marker.read_text(encoding='utf-8')}")
    print("Review metadata, timeout/skipped counts and evidence. This does not prove the selected mapping or ISA.")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    init = sub.add_parser("init", help="create the terminal research workspace")
    init.add_argument("--workspace", default=str(Path.home() / "nano7-research"))
    show = sub.add_parser("languages", help="list actual installed Ghidra language/compiler IDs")
    show.add_argument("--processor", default="")
    inv = sub.add_parser("inspect", help="hash/header/archive inventory, without executable analysis")
    inv.add_argument("image")
    for flag in ("source-url", "model", "build", "out"):
        inv.add_argument("--" + flag, default="")
    cut = sub.add_parser("carve", help="extract a proven offset/length range without overwriting")
    cut.add_argument("image")
    for flag in ("offset", "length", "out", "evidence"):
        cut.add_argument("--" + flag, required=True)
    run = sub.add_parser("analyze", help="new headless project plus bounded evidence exports")
    run.add_argument("image")
    run.add_argument("--workspace", default=str(Path.home() / "nano7-research"))
    run.add_argument("--project", required=True)
    run.add_argument("--mode", choices=("auto", "raw"), default="auto")
    for flag in ("language", "compiler", "base", "evidence", "evidence-note"):
        run.add_argument("--" + flag, default="")
    run.add_argument("--analysis-seconds", type=int, default=600)
    run.add_argument("--max-functions", type=int, default=200)
    run.add_argument("--function-seconds", type=int, default=10)
    run.add_argument("--export-seconds", type=int, default=120)
    args = parser.parse_args()
    if args.command == "init":
        print(workspace(args.workspace))
    elif args.command == "languages":
        print("language_id\tprocessor\tendian\tbits\tcompiler_ids")
        for item in languages():
            if args.processor.lower() in item["processor"].lower():
                print("\t".join([item["id"], item["processor"], item["endian"], item["bits"],
                                  ",".join(item["compilers"])]))
    elif args.command == "inspect":
        inspect(args)
    elif args.command == "carve":
        carve(args)
    else:
        analyze(args)


if __name__ == "__main__":
    try:
        main()
    except (OSError, ValueError, zipfile.BadZipFile) as error:
        fail(str(error))
