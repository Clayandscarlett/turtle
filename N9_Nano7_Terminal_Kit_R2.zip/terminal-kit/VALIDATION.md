# Terminal kit validation

Checked on 15 October 2026 using the actual official Ghidra 12.1.4 headless
analyzer and native Linux x86_64 decompiler, with a full Java 21 JDK. No Ghidra
GUI was opened. Mac-specific behavior is checked against the Homebrew formula
and Ghidra launcher/platform definitions; it has not been executed on a Mac here.

- The original `tests/fixture.c` was compiled to a Linux ELF and imported into a
  fresh project. The final exporter produced 18 function entries, 99 instructions,
  39 memory blocks, 141 references, 81 defined-string rows, and 18 successful
  decompiler results. The expected fixture string and `volume_clamp` function
  were found in the exports. Decompiler warnings for external locations remain
  visible in the logs/status; completed pseudocode is still approximate.
- A separate run with a one-function limit exported one decompiled function and
  correctly reported `export_status=partial`, `decompile_complete=false`.
- Helper checks verified exact hashes/header inventory, bounded range extraction
  and its manifest, invalid-range rejection, output/manifest overwrite rejection,
  existing-project rejection, and raw-import rejection when required evidence
  was absent. Results are recorded in `tests/helper-results.json`.
- `bash -n` checked the launcher. The actual release's LaunchSupport accepted
  the selected full JDK. A runtime-only Java installation without `javac` was
  rejected before analysis.
- `NanoApplyEvidence.java` was compiled and run in real headless Ghidra against
  an original mixed ARM/Thumb fixture. See `tests/evidence-results.json` for its
  completed checks, including error rollback and symbol renaming.

These checks validate the helpers on the exercised fixtures. They do not prove
nano 7 extraction/decryption, a correct nano processor/memory map, Apple behavior,
a completed Freenove port, Mac execution, physical audio, measured frame rate,
charging state, or battery runtime. No Apple firmware was used in these checks.

## R2 direct-install support

- Bash and Python discover the private toolchain from a two-key data file and
  accept both Ghidra native output locations. Environment overrides, paths with
  spaces and equals signs, malformed configuration rejection, Homebrew discovery,
  and the direct-install fallback were checked. Configuration is never executed.
- Actual Linux Ghidra headless import and ARM language enumeration passed using
  the new configuration path.
- The official Gradle 9.7.1 distribution matched its release SHA-256. With JDK 21,
  the actual Ghidra 12.1.4 `buildNatives --dry-run` task graph succeeded.
- Actual `:FileFormats:buildNatives` compilation succeeded on Linux. The resulting
  LZFSE tool passed a byte-exact 65,792-byte encode/decode roundtrip. No extra
  dependency downloads occurred after obtaining Gradle.
- The direct installer is checked against Bash syntax and the documented Ghidra
  native-build paths. Its Mac-specific compilation and final test must execute
  on the user's Mac; no cloud Mac execution is claimed.
