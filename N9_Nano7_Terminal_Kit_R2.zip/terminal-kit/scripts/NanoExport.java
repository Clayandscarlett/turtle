// Export bounded, reproducible analysis evidence without opening the GUI.
// Arguments: output_directory max_decompiled_functions per_function_seconds total_export_seconds
//@category Analysis.Export

import ghidra.app.decompiler.DecompInterface;
import ghidra.app.decompiler.DecompileResults;
import ghidra.app.util.headless.HeadlessScript;
import ghidra.program.model.address.Address;
import ghidra.program.model.address.AddressIterator;
import ghidra.program.model.data.StringDataInstance;
import ghidra.program.model.listing.Data;
import ghidra.program.model.listing.DataIterator;
import ghidra.program.model.listing.Function;
import ghidra.program.model.listing.FunctionIterator;
import ghidra.program.model.listing.Instruction;
import ghidra.program.model.listing.InstructionIterator;
import ghidra.program.model.mem.MemoryBlock;
import ghidra.program.model.symbol.Reference;

import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.AtomicMoveNotSupportedException;
import java.time.Instant;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.stream.Stream;

public class NanoExport extends HeadlessScript {
    private Path output;
    private long started;
    private long deadline;
    private int maximumFunctions;
    private int functionSeconds;
    private boolean analysisTimedOut;
    private final Map<String, Long> counts = new LinkedHashMap<>();
    private final Map<String, Boolean> complete = new LinkedHashMap<>();

    private static int positive(String text, String label, int maximum) {
        int value;
        try { value = Integer.parseInt(text); }
        catch (NumberFormatException error) { throw new IllegalArgumentException(label + " must be an integer", error); }
        if (value < 1 || value > maximum) {
            throw new IllegalArgumentException(label + " must be between 1 and " + maximum);
        }
        return value;
    }

    private static String cell(Object value) {
        if (value == null) return "";
        String input = String.valueOf(value);
        StringBuilder escaped = new StringBuilder(input.length());
        for (int index = 0; index < input.length(); ++index) {
            char character = input.charAt(index);
            switch (character) {
                case '\\': escaped.append("\\\\"); break;
                case '\t': escaped.append("\\t"); break;
                case '\r': escaped.append("\\r"); break;
                case '\n': escaped.append("\\n"); break;
                default:
                    if (character < 0x20 || character == 0x7f) {
                        escaped.append(String.format("\\u%04x", (int) character));
                    } else escaped.append(character);
            }
        }
        return escaped.toString();
    }

    private static void row(BufferedWriter writer, Object... values) throws IOException {
        for (int index = 0; index < values.length; ++index) {
            if (index != 0) writer.write('\t');
            writer.write(cell(values[index]));
        }
        writer.newLine();
    }

    private BufferedWriter table(String filename, Object... headings) throws IOException {
        BufferedWriter writer = Files.newBufferedWriter(output.resolve(filename), StandardCharsets.UTF_8);
        try { row(writer, headings); }
        catch (IOException error) { writer.close(); throw error; }
        return writer;
    }

    private boolean haveTime() throws Exception {
        monitor.checkCancelled();
        return System.nanoTime() - deadline < 0;
    }

    private static String entry(Function function) {
        return function == null ? "" : function.getEntryPoint().toString();
    }

    private void metadata(int exportSeconds) throws Exception {
        try (BufferedWriter writer = table("metadata.tsv", "key", "value")) {
            row(writer, "program_name", currentProgram.getName());
            row(writer, "executable_path", currentProgram.getExecutablePath());
            row(writer, "executable_format", currentProgram.getExecutableFormat());
            row(writer, "language_id", currentProgram.getLanguageID());
            row(writer, "compiler_spec_id", currentProgram.getCompilerSpec().getCompilerSpecID());
            row(writer, "image_base", currentProgram.getImageBase());
            row(writer, "function_count_reported_by_program", currentProgram.getFunctionManager().getFunctionCount());
            row(writer, "analysis_timed_out", analysisTimedOut);
            row(writer, "max_decompiled_functions", maximumFunctions);
            row(writer, "per_function_timeout_seconds", functionSeconds);
            row(writer, "total_export_budget_seconds", exportSeconds);
            row(writer, "export_started_utc", Instant.now());
            row(writer, "interpretation", "Exported evidence does not validate CPU selection, image base, extraction, function boundaries, or reconstructed source.");
            row(writer, "string_scope", "Only strings already defined in Ghidra; undefined bytes and unrecognized resource encodings are not scanned.");
            row(writer, "call_scope", "Resolved call references plus recognized call instructions without resolved call references; dynamic targets and tail calls may be missing.");
        }
    }

    private void functions() throws Exception {
        boolean finished = true;
        long count = 0;
        try (BufferedWriter writer = table("functions.tsv", "entry", "name", "body_bytes", "external", "thunk", "signature")) {
            FunctionIterator iterator = currentProgram.getFunctionManager().getFunctions(true);
            while (iterator.hasNext()) {
                if (!haveTime()) { finished = false; break; }
                Function function = iterator.next();
                row(writer, function.getEntryPoint(), function.getName(), function.getBody().getNumAddresses(),
                    function.isExternal(), function.isThunk(), function.getPrototypeString(false, true));
                ++count;
            }
        }
        counts.put("functions_exported", count);
        complete.put("function_inventory_complete", finished);
    }

    private void strings() throws Exception {
        boolean finished = true;
        long count = 0;
        long tooLarge = 0;
        try (BufferedWriter writer = table("defined_strings.tsv", "address", "data_bytes", "charset", "status", "value")) {
            DataIterator iterator = currentProgram.getListing().getDefinedData(true);
            while (iterator.hasNext()) {
                if (!haveTime()) { finished = false; break; }
                Data data = iterator.next();
                if (!StringDataInstance.isString(data)) continue;
                // A corrupt data definition must not force an unbounded allocation.
                if (data.getLength() > 1024 * 1024) {
                    row(writer, data.getAddress(), data.getLength(), "", "skipped_size_limit", "");
                    ++tooLarge;
                    continue;
                }
                StringDataInstance string = StringDataInstance.getStringDataInstance(data);
                if (string == StringDataInstance.NULL_INSTANCE) continue;
                String value = string.getStringValue();
                row(writer, data.getAddress(), data.getLength(), string.getCharsetName(),
                    value == null ? "undecodable" : "decoded", value);
                ++count;
            }
        }
        counts.put("defined_string_rows", count);
        counts.put("defined_strings_skipped_size", tooLarge);
        complete.put("defined_string_inventory_complete", finished && tooLarge == 0);
    }

    private void referencesAndCalls() throws Exception {
        boolean referencesFinished = true;
        boolean instructionsFinished = true;
        long referenceCount = 0;
        long resolvedCount = 0;
        long unresolvedCount = 0;
        try (BufferedWriter references = table("references.tsv", "from", "to", "type", "operand", "primary", "source");
             BufferedWriter calls = table("calls.tsv", "status", "caller_entry", "callsite", "target", "target_function_entry", "type")) {
            AddressIterator sources = currentProgram.getReferenceManager().getReferenceSourceIterator(currentProgram.getMemory(), true);
            while (sources.hasNext()) {
                if (!haveTime()) { referencesFinished = false; break; }
                Address source = sources.next();
                for (Reference reference : currentProgram.getReferenceManager().getReferencesFrom(source)) {
                    if (!haveTime()) { referencesFinished = false; break; }
                    row(references, reference.getFromAddress(), reference.getToAddress(), reference.getReferenceType(),
                        reference.getOperandIndex(), reference.isPrimary(), reference.getSource());
                    ++referenceCount;
                    if (reference.getReferenceType().isCall()) {
                        Function caller = currentProgram.getFunctionManager().getFunctionContaining(reference.getFromAddress());
                        Function callee = currentProgram.getFunctionManager().getFunctionAt(reference.getToAddress());
                        row(calls, "resolved_reference", entry(caller), reference.getFromAddress(), reference.getToAddress(),
                            entry(callee), reference.getReferenceType());
                        ++resolvedCount;
                    }
                }
                if (!referencesFinished) break;
            }
            InstructionIterator instructions = currentProgram.getListing().getInstructions(true);
            while (instructions.hasNext()) {
                if (!haveTime()) { instructionsFinished = false; break; }
                Instruction instruction = instructions.next();
                if (!instruction.getFlowType().isCall()) continue;
                boolean resolved = false;
                for (Reference reference : currentProgram.getReferenceManager().getReferencesFrom(instruction.getAddress())) {
                    if (reference.getReferenceType().isCall()) { resolved = true; break; }
                }
                if (!resolved) {
                    Function caller = currentProgram.getFunctionManager().getFunctionContaining(instruction.getAddress());
                    row(calls, "unresolved_callsite", entry(caller), instruction.getAddress(), "", "", instruction.getFlowType());
                    ++unresolvedCount;
                }
            }
        }
        counts.put("references_exported", referenceCount);
        counts.put("resolved_call_references", resolvedCount);
        counts.put("unresolved_callsite_rows", unresolvedCount);
        complete.put("reference_inventory_complete", referencesFinished);
        complete.put("recognized_callsite_inventory_complete", referencesFinished && instructionsFinished);
    }

    private void memoryMap() throws Exception {
        boolean finished = true;
        long count = 0;
        try (BufferedWriter writer = table("memorymap.tsv", "start", "end", "name", "initialized", "read", "write", "execute")) {
            for (MemoryBlock block : currentProgram.getMemory().getBlocks()) {
                if (!haveTime()) { finished = false; break; }
                row(writer, block.getStart(), block.getEnd(), block.getName(), block.isInitialized(),
                    block.isRead(), block.isWrite(), block.isExecute());
                ++count;
            }
        }
        counts.put("memory_blocks_exported", count);
        complete.put("memory_map_complete", finished);
    }

    private void instructions() throws Exception {
        boolean finished = true;
        long count = 0;
        try (BufferedWriter writer = table("instructions.tsv", "address", "byte_length", "bytes_hex", "mnemonic", "operands", "containing_function_entry")) {
            InstructionIterator iterator = currentProgram.getListing().getInstructions(true);
            while (iterator.hasNext()) {
                if (!haveTime()) { finished = false; break; }
                Instruction instruction = iterator.next();
                StringBuilder hexadecimal = new StringBuilder();
                for (byte value : instruction.getBytes()) {
                    hexadecimal.append(Character.forDigit((value >>> 4) & 0xf, 16));
                    hexadecimal.append(Character.forDigit(value & 0xf, 16));
                }
                StringBuilder operands = new StringBuilder();
                for (int index = 0; index < instruction.getNumOperands(); ++index) {
                    if (index != 0) operands.append(", ");
                    operands.append(instruction.getDefaultOperandRepresentation(index));
                }
                Function function = currentProgram.getFunctionManager().getFunctionContaining(instruction.getAddress());
                row(writer, instruction.getAddress(), instruction.getLength(), hexadecimal,
                    instruction.getMnemonicString(), operands, entry(function));
                ++count;
            }
        }
        counts.put("instructions_exported", count);
        complete.put("instruction_inventory_complete", finished);
    }

    private void decompile() throws Exception {
        long attempted = 0;
        long succeeded = 0;
        long skipped = 0;
        boolean finished = true;
        DecompInterface decompiler = new DecompInterface();
        try (BufferedWriter writer = table("decompile_status.tsv", "entry", "name", "status", "output_file", "elapsed_ms", "message")) {
            decompiler.toggleCCode(true);
            if (!haveTime()) {
                row(writer, "*", "", "remaining_skipped_budget", "", 0, "Export deadline reached before decompiler setup");
                finished = false;
            } else if (!decompiler.openProgram(currentProgram)) {
                row(writer, "*", "", "decompiler_open_failed", "", 0, decompiler.getLastMessage());
                finished = false;
            } else {
                FunctionIterator iterator = currentProgram.getFunctionManager().getFunctions(true);
                while (iterator.hasNext()) {
                    if (!haveTime() || deadline - System.nanoTime() < 1000000000L) {
                        row(writer, "*", "", "remaining_skipped_budget", "", 0, "Remaining functions were not enumerated after the export deadline");
                        finished = false;
                        break;
                    }
                    Function function = iterator.next();
                    if (function.isExternal()) {
                        row(writer, function.getEntryPoint(), function.getName(), "skipped_external", "", 0, "No local function body");
                        ++skipped;
                        continue;
                    }
                    if (attempted >= maximumFunctions) {
                        row(writer, "*", "", "remaining_skipped_function_limit", "", 0,
                            "Maximum decompiled function count reached; remaining functions not enumerated");
                        finished = false;
                        break;
                    }
                    ++attempted;
                    long before = System.nanoTime();
                    int seconds = (int) Math.min(functionSeconds, Math.max(1L, (deadline - before) / 1000000000L));
                    DecompileResults result;
                    try {
                        result = decompiler.decompileFunction(function, seconds, monitor);
                    } catch (Exception error) {
                        monitor.checkCancelled();
                        row(writer, function.getEntryPoint(), function.getName(), "exception", "",
                            (System.nanoTime() - before) / 1000000L, error.toString());
                        finished = false;
                        continue;
                    }
                    String status;
                    String filename = "";
                    if (result != null && result.decompileCompleted() && result.getDecompiledFunction() != null) {
                        String address = function.getEntryPoint().toString().replaceAll("[^A-Za-z0-9._-]", "_");
                        filename = "decompiled/" + String.format("%06d_%s.c", attempted, address);
                        String code = result.getDecompiledFunction().getC();
                        try (BufferedWriter codeWriter = Files.newBufferedWriter(output.resolve(filename), StandardCharsets.UTF_8)) {
                            codeWriter.write("/* Ghidra reconstructed pseudocode; not original source. */\n");
                            codeWriter.write(code);
                        }
                        status = "decompiled";
                        ++succeeded;
                    } else {
                        status = result == null ? "no_result" : result.isTimedOut() ? "timeout" : result.isCancelled() ? "cancelled" : "failed";
                        finished = false;
                    }
                    row(writer, function.getEntryPoint(), function.getName(), status, filename,
                        (System.nanoTime() - before) / 1000000L, result == null ? decompiler.getLastMessage() : result.getErrorMessage());
                }
            }
        } finally {
            decompiler.dispose();
        }
        counts.put("decompile_attempted", attempted);
        counts.put("decompile_succeeded", succeeded);
        counts.put("decompile_external_skipped", skipped);
        complete.put("decompile_complete", finished);
    }

    @Override
    public void run() throws Exception {
        String[] arguments = getScriptArgs();
        if (arguments.length != 4 || arguments[0].isBlank()) {
            throw new IllegalArgumentException("NanoExport.java requires: output_directory max_functions per_function_seconds total_export_seconds");
        }
        if (currentProgram == null) throw new IllegalStateException("No program is open; no export produced");
        maximumFunctions = positive(arguments[1], "max_functions", 1000000);
        functionSeconds = positive(arguments[2], "per_function_seconds", 3600);
        int exportSeconds = positive(arguments[3], "total_export_seconds", 86400);
        output = Path.of(arguments[0]).toAbsolutePath().normalize();
        if (Files.exists(output, LinkOption.NOFOLLOW_LINKS)) {
            if (!Files.isDirectory(output, LinkOption.NOFOLLOW_LINKS)) throw new IOException("Output must be a real directory");
            try (Stream<Path> contents = Files.list(output)) {
                if (contents.findAny().isPresent()) throw new IOException("Output directory must be empty: " + output);
            }
        } else Files.createDirectories(output);
        Files.createDirectory(output.resolve("decompiled"));
        started = System.nanoTime();
        deadline = started + exportSeconds * 1000000000L;
        analysisTimedOut = analysisTimeoutOccurred();
        metadata(exportSeconds);
        memoryMap();
        functions();
        strings();
        referencesAndCalls();
        instructions();
        decompile();
        boolean allComplete = !analysisTimedOut;
        for (boolean value : complete.values()) allComplete &= value;
        // This is written LAST, after every evidence writer and decompiler is
        // closed. Its existence proves script completion, not a valid import.
        Path pendingMarker = output.resolve("EXPORT_COMPLETE.tsv.pending");
        try (BufferedWriter writer = Files.newBufferedWriter(pendingMarker, StandardCharsets.UTF_8)) {
            row(writer, "key", "value");
            row(writer, "export_status", allComplete ? "complete" : "partial");
            row(writer, "analysis_timed_out", analysisTimedOut);
            row(writer, "elapsed_ms", (System.nanoTime() - started) / 1000000L);
            for (Map.Entry<String, Boolean> item : complete.entrySet()) row(writer, item.getKey(), item.getValue());
            for (Map.Entry<String, Long> item : counts.entrySet()) row(writer, item.getKey(), item.getValue());
            row(writer, "import_validated", false);
            row(writer, "meaning", "Script completed. A complete export does not prove correct extraction, architecture, image base, or recovered behavior.");
        }
        try {
            Files.move(pendingMarker, output.resolve("EXPORT_COMPLETE.tsv"), StandardCopyOption.ATOMIC_MOVE);
        } catch (AtomicMoveNotSupportedException error) {
            Files.move(pendingMarker, output.resolve("EXPORT_COMPLETE.tsv"));
        }
        println("NanoExport finished: " + (allComplete ? "complete" : "partial") + " evidence in " + output);
    }
}
