// Apply an analyst's explicit TSV hypotheses to the current imported program.
// This script does not establish that addresses, names, modes, or functions are correct.
// @category Nano7.Terminal

import ghidra.app.util.headless.HeadlessScript;
import ghidra.program.model.address.Address;
import ghidra.program.model.address.AddressRange;
import ghidra.program.model.address.AddressRangeIterator;
import ghidra.program.model.address.AddressSet;
import ghidra.program.model.lang.Register;
import ghidra.program.model.lang.RegisterValue;
import ghidra.program.model.listing.Function;
import ghidra.program.model.listing.Instruction;
import ghidra.program.model.listing.InstructionIterator;
import ghidra.program.model.listing.ProgramContext;
import ghidra.program.model.symbol.SourceType;
import ghidra.program.model.symbol.Symbol;
import ghidra.program.model.symbol.SymbolUtilities;

import java.math.BigInteger;
import java.nio.ByteBuffer;
import java.nio.charset.CodingErrorAction;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class NanoApplyEvidence extends HeadlessScript {
    private static final long MAX_TSV_BYTES = 16L * 1024L * 1024L;

    private static final class Action {
        final int line;
        final String kind;
        final Address start;
        final Address end;
        final String name;
        final int mode;

        Action(int line, String kind, Address start, Address end, String name, int mode) {
            this.line = line;
            this.kind = kind;
            this.start = start;
            this.end = end;
            this.name = name;
            this.mode = mode;
        }
    }

    private IllegalArgumentException invalid(int line, String message) {
        return new IllegalArgumentException("evidence line " + line + ": " + message);
    }

    private Address mappedAddress(String text, int line) {
        final Address address;
        try {
            address = currentProgram.getAddressFactory().getAddress(text);
        }
        catch (RuntimeException error) {
            throw invalid(line, "invalid address: " + text);
        }
        if (address == null || !address.isMemoryAddress()) {
            throw invalid(line, "invalid memory address: " + text);
        }
        if (!currentProgram.getMemory().contains(address)) {
            throw invalid(line, "address is outside imported memory: " + text);
        }
        return address;
    }

    private Register armTMode(int line) {
        if (!"ARM".equalsIgnoreCase(currentProgram.getLanguage().getProcessor().toString())) {
            throw invalid(line, "tmode is supported only for an ARM program, not " +
                currentProgram.getLanguageID());
        }
        Register register = currentProgram.getLanguage().getRegister("TMode");
        if (register == null || !register.isProcessorContext()) {
            throw invalid(line, "the selected ARM language has no supported TMode context register");
        }
        return register;
    }

    private List<Action> parse(String text) throws Exception {
        List<Action> actions = new ArrayList<>();
        Set<Address> functionEntries = new HashSet<>();
        String[] lines = text.split("\\r\\n|\\n|\\r", -1);
        for (int index = 0; index < lines.length; ++index) {
            monitor.checkCancelled();
            String line = lines[index];
            if (index == 0 && line.startsWith("\ufeff")) {
                line = line.substring(1);
            }
            if (line.trim().isEmpty() || line.stripLeading().startsWith("#")) {
                continue;
            }
            int number = index + 1;
            String[] fields = line.split("\\t", -1);
            for (int field = 0; field < fields.length; ++field) {
                fields[field] = fields[field].trim();
            }
            String kind = fields[0];
            if ("label".equals(kind) || "function".equals(kind)) {
                if (fields.length != 3) {
                    throw invalid(number, kind + " needs exactly 3 tab-separated fields");
                }
                Address address = mappedAddress(fields[1], number);
                try {
                    SymbolUtilities.validateName(fields[2]);
                }
                catch (Exception error) {
                    throw invalid(number, "invalid symbol name: " + error.getMessage());
                }
                if ("function".equals(kind) && !functionEntries.add(address)) {
                    throw invalid(number, "duplicate function entry: " + address);
                }
                actions.add(new Action(number, kind, address, address, fields[2], -1));
            }
            else if ("tmode".equals(kind)) {
                if (fields.length != 4) {
                    throw invalid(number, "tmode needs exactly 4 tab-separated fields");
                }
                armTMode(number);
                if (!"0".equals(fields[3]) && !"1".equals(fields[3])) {
                    throw invalid(number, "TMode must be exactly 0 (ARM) or 1 (Thumb)");
                }
                Address start = mappedAddress(fields[1], number);
                Address end = mappedAddress(fields[2], number);
                if (!start.getAddressSpace().equals(end.getAddressSpace()) || start.compareTo(end) > 0) {
                    throw invalid(number, "TMode needs an ascending range in one memory address space");
                }
                if (!currentProgram.getMemory().contains(start, end)) {
                    throw invalid(number, "TMode range includes an unmapped memory gap");
                }
                int mode = Integer.parseInt(fields[3]);
                if ((start.getOffset() & (mode == 1 ? 1L : 3L)) != 0) {
                    throw invalid(number, "TMode range starts at an unaligned physical code address");
                }
                actions.add(new Action(number, kind, start, end, null, mode));
            }
            else {
                throw invalid(number, "unknown action; use label, function, or tmode");
            }
        }
        return actions;
    }

    private List<Action> contextActions(List<Action> actions) {
        List<Action> contexts = new ArrayList<>();
        for (Action action : actions) {
            if ("tmode".equals(action.kind)) {
                contexts.add(action);
            }
        }
        contexts.sort(Comparator.comparing((Action action) -> action.start)
            .thenComparing(action -> action.end));
        Address activeEnd = null;
        int activeMode = -1;
        for (Action action : contexts) {
            if (activeEnd != null && activeEnd.getAddressSpace().equals(action.start.getAddressSpace()) &&
                action.start.compareTo(activeEnd) <= 0) {
                if (activeMode != action.mode) {
                    throw invalid(action.line, "overlapping TMode ranges assign conflicting modes");
                }
                if (action.end.compareTo(activeEnd) > 0) {
                    activeEnd = action.end;
                }
            }
            else {
                activeEnd = action.end;
                activeMode = action.mode;
            }
        }
        return contexts;
    }

    private void validateContext(Action action) throws Exception {
        Register register = armTMode(action.line);
        ProgramContext context = currentProgram.getProgramContext();
        AddressSet range = new AddressSet(action.start, action.end);
        Instruction containingStart = currentProgram.getListing().getInstructionContaining(action.start);
        if (containingStart != null && !containingStart.getMinAddress().equals(action.start)) {
            throw invalid(action.line, "TMode range begins inside an existing instruction");
        }
        InstructionIterator instructions = currentProgram.getListing().getInstructions(range, true);
        while (instructions.hasNext()) {
            monitor.checkCancelled();
            Instruction instruction = instructions.next();
            if (instruction.getMaxAddress().compareTo(action.end) > 0) {
                throw invalid(action.line, "TMode range ends inside an existing instruction");
            }
            BigInteger existing = context.getValue(register, instruction.getMinAddress(), false);
            if (!BigInteger.valueOf(action.mode).equals(existing)) {
                throw invalid(action.line, "TMode conflicts with an existing instruction; " +
                    "use a clean import or review the current disassembly first");
            }
        }
    }

    private void validateFunction(Action action, List<Action> contexts) throws Exception {
        if (!currentProgram.getMemory().getAllInitializedAddressSet().contains(action.start)) {
            throw invalid(action.line, "function entry has no initialized instruction bytes");
        }
        Instruction containing = currentProgram.getListing().getInstructionContaining(action.start);
        if (containing != null && !containing.getMinAddress().equals(action.start)) {
            throw invalid(action.line, "function entry lies inside an existing instruction");
        }
        if (currentProgram.getListing().getDefinedDataContaining(action.start) != null) {
            throw invalid(action.line, "function entry is occupied by defined data");
        }
        Function containingFunction = currentProgram.getFunctionManager().getFunctionContaining(action.start);
        if (containingFunction != null && !containingFunction.getEntryPoint().equals(action.start)) {
            throw invalid(action.line, "function entry lies inside another existing function");
        }
        if (!"ARM".equalsIgnoreCase(currentProgram.getLanguage().getProcessor().toString())) {
            return;
        }
        Register register = armTMode(action.line);
        if ((action.start.getOffset() & 1L) != 0) {
            throw invalid(action.line, "ARM function entry must be an even physical address; " +
                "provide Thumb state with a tmode row, not a tagged odd pointer");
        }
        BigInteger mode = null;
        for (Action context : contexts) {
            if (context.start.getAddressSpace().equals(action.start.getAddressSpace()) &&
                context.start.compareTo(action.start) <= 0 && context.end.compareTo(action.start) >= 0) {
                mode = BigInteger.valueOf(context.mode);
                break;
            }
        }
        if (mode == null) {
            RegisterValue existing = currentProgram.getProgramContext().getNonDefaultValue(register, action.start);
            mode = existing == null ? null : existing.getUnsignedValue();
        }
        if (!BigInteger.ZERO.equals(mode) && !BigInteger.ONE.equals(mode)) {
            throw invalid(action.line, "ARM function requires an explicit verified tmode range " +
                "or an existing nondefault TMode value; no default mode is guessed");
        }
        if (BigInteger.ZERO.equals(mode) && (action.start.getOffset() & 3L) != 0) {
            throw invalid(action.line, "ARM-state function entry must be four-byte aligned");
        }
    }

    private void applyContext(Action action) throws Exception {
        // Ghidra forbids even an identical context write over existing
        // instructions. Prevalidation checked their modes; retain those bytes
        // and set only the remaining portions of this explicit evidence range.
        AddressSet writable = new AddressSet(action.start, action.end);
        InstructionIterator instructions = currentProgram.getListing().getInstructions(
            new AddressSet(action.start, action.end), true);
        while (instructions.hasNext()) {
            monitor.checkCancelled();
            Instruction instruction = instructions.next();
            writable.delete(instruction.getMinAddress(), instruction.getMaxAddress());
        }
        AddressRangeIterator ranges = writable.getAddressRanges();
        while (ranges.hasNext()) {
            monitor.checkCancelled();
            AddressRange range = ranges.next();
            currentProgram.getProgramContext().setValue(armTMode(action.line), range.getMinAddress(),
                range.getMaxAddress(), BigInteger.valueOf(action.mode));
        }
    }

    private String sha256(byte[] bytes) throws Exception {
        StringBuilder result = new StringBuilder();
        for (byte value : MessageDigest.getInstance("SHA-256").digest(bytes)) {
            result.append(String.format("%02x", value & 0xff));
        }
        return result.toString();
    }

    @Override
    protected void run() throws Exception {
        try {
            if (currentProgram == null) {
                throw new IllegalArgumentException("no imported program is open");
            }
            String[] arguments = getScriptArgs();
            if (arguments.length != 1) {
                throw new IllegalArgumentException("usage: NanoApplyEvidence.java /absolute/path/evidence.tsv");
            }
            Path input = Path.of(arguments[0]).toAbsolutePath().normalize();
            if (!Files.isRegularFile(input) || Files.size(input) > MAX_TSV_BYTES) {
                throw new IllegalArgumentException("evidence must be a regular UTF-8 TSV file of at most 16 MiB");
            }
            byte[] bytes = Files.readAllBytes(input);
            String text = StandardCharsets.UTF_8.newDecoder()
                .onMalformedInput(CodingErrorAction.REPORT).onUnmappableCharacter(CodingErrorAction.REPORT)
                .decode(ByteBuffer.wrap(bytes)).toString();
            List<Action> actions = parse(text);
            List<Action> contexts = contextActions(actions);
            for (Action action : contexts) {
                validateContext(action);
            }
            for (Action action : actions) {
                if ("function".equals(action.kind)) {
                    validateFunction(action, contexts);
                }
            }
            println("[nano7-evidence] source=" + input + " sha256=" + sha256(bytes));
            println("[nano7-evidence] Analyst-provided hypotheses only: syntax/mapping checks do not " +
                "validate firmware identity, execution mode, addresses, function boundaries, or behavior.");
            println("[nano7-evidence] Prevalidated " + actions.size() + " actions for " + currentProgram.getLanguageID());

            int transaction = currentProgram.startTransaction("Apply analyst evidence: " + input.getFileName());
            boolean commit = false;
            int labels = 0;
            int functions = 0;
            int ranges = 0;
            try {
                // Context first even when TSV rows list function entries before their ranges.
                for (Action action : contexts) {
                    monitor.checkCancelled();
                    applyContext(action);
                    ++ranges;
                }
                for (Action action : actions) {
                    monitor.checkCancelled();
                    if ("label".equals(action.kind)) {
                        Symbol symbol = currentProgram.getSymbolTable().createLabel(action.start,
                            action.name, SourceType.USER_DEFINED);
                        if (symbol == null) {
                            throw invalid(action.line, "label creation returned no symbol");
                        }
                        symbol.setSource(SourceType.USER_DEFINED);
                        ++labels;
                    }
                    else if ("function".equals(action.kind)) {
                        // A false disassembly return is not silently accepted. Already-defined
                        // instructions are also checked explicitly because a repeat disassembly
                        // may have no new work to report.
                        boolean decoded = disassemble(action.start);
                        if (!decoded && currentProgram.getListing().getInstructionAt(action.start) == null) {
                            throw invalid(action.line, "disassembly failed at function entry " + action.start);
                        }
                        if (currentProgram.getListing().getInstructionAt(action.start) == null) {
                            throw invalid(action.line, "no instruction exists at function entry after disassembly");
                        }
                        if (!decoded) {
                            println("[nano7-evidence] Reusing the existing decoded instruction at " + action.start);
                        }
                        Function function = currentProgram.getFunctionManager().getFunctionAt(action.start);
                        if (function == null) {
                            function = createFunction(action.start, action.name);
                        }
                        if (function == null) {
                            throw invalid(action.line, "function creation failed at " + action.start);
                        }
                        function.setName(action.name, SourceType.USER_DEFINED);
                        ++functions;
                    }
                }
                monitor.checkCancelled();
                commit = true;
            }
            finally {
                currentProgram.endTransaction(transaction, commit);
            }
            println("[nano7-evidence] APPLIED labels=" + labels + " functions=" + functions +
                " tmode_ranges=" + ranges + " source=" + input.getFileName());
            println("NANO_EVIDENCE_APPLIED " + sha256(bytes));
        }
        catch (Exception error) {
            setHeadlessContinuationOption(HeadlessContinuationOption.ABORT);
            printerr("[nano7-evidence] FAILED; no evidence transaction committed: " + error.getMessage());
            throw error;
        }
    }
}
