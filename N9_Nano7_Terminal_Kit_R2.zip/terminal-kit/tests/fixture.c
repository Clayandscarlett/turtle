#include <stdio.h>

/* Original test fixture. This is not Apple code or a nano emulator. */
static int volume_clamp(int value) {
    return value < 0 ? 0 : value > 100 ? 100 : value;
}

int main(int argc, char **argv) {
    (void) argv;
    printf("NANO_TERMINAL_FIXTURE volume=%d\n", volume_clamp(argc * 20));
    return 0;
}
