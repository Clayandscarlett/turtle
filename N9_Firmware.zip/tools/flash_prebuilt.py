#!/usr/bin/env python3
"""Verify and flash this exact FNK0104B release; leave NVS and data sectors intact."""
from pathlib import Path
import argparse
import hashlib
import json
import sys

def main():
    parser=argparse.ArgumentParser(description='Flash nanoOS 1.1.8-voice-memos-sf-compact to Freenove FNK0104B (N16R8).')
    parser.add_argument('--port',help='Serial port; required if multiple serial devices are connected')
    parser.add_argument('--verify-only',action='store_true',help='Check bundled binary hashes without accessing a device')
    args=parser.parse_args()
    root=Path(__file__).resolve().parents[1]/'bin'
    release=root/'release.json'
    if not release.exists():
        raise SystemExit('No prebuilt v1.1.8 images are bundled. Run BUILD_AND_FLASH.command --build-only first.')
    manifest=json.loads(release.read_text())
    if len(manifest['images'])!=4 or [i['offset'] for i in manifest['images']]!=['0x0','0x8000','0xe000','0x10000']:
        raise SystemExit('Invalid firmware manifest; download and extract the complete ZIP.')
    for item in manifest['images']:
        data=(root/item['file']).read_bytes()
        if len(data)!=item['size'] or hashlib.sha256(data).hexdigest()!=item['sha256']:
            raise SystemExit('Checksum mismatch: '+item['file']+'. Extract a fresh copy of the release.')
    print('All four firmware image checksums verified.')
    if args.verify_only: return
    try:
        import esptool
        from serial.tools import list_ports
    except ImportError:
        raise SystemExit('Install esptool with: python3 -m pip install esptool')
    port=args.port
    if not port:
        ports=list(list_ports.comports())
        if len(ports)!=1:
            for p in ports: print(p.device, p.description)
            raise SystemExit('Connect the board and pass --port YOUR_PORT. Hold BOOT during reset for ROM download mode.')
        port=ports[0].device
    command=['--chip','esp32s3','--port',port,'--baud','460800','--after','watchdog-reset','write-flash',
             '--flash-mode',manifest['flash_mode'],'--flash-freq','80m','--flash-size','16MB']
    for item in manifest['images']:
        command += [item['offset'],str(root/item['file'])]
    esptool.main(command)
    print('nanoOS 1.1.8-voice-memos-sf-compact flashed. Open Voice Memos, record your voice, then stop and play it from Memos.')
if __name__=='__main__': main()
