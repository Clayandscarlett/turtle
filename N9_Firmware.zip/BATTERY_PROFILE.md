# Battery profile for the 3.7 V, 800 mAh LiPo

Three hours of screen-on use is the target, not a measured result. No physical device or current meter was available. Firmware cannot create capacity or determine consumed mAh from voltage alone.

## Default behavior in this candidate

Battery Saver is ON unless explicitly saved off. Settings > Battery contains its switch. It caps effective brightness at 55%; the user's requested brightness is preserved and restored when Battery Saver is disabled. Settings > Brightness explains the cap. On this firmware's square-law PWM curve, the old default request of 70 produces 501/1023 duty; the new cap produces 309/1023 duty, a 38.3% reduction in commanded backlight duty. This is not a measured 38.3% reduction in total phone power or perceived brightness.

WiFi uses minimum modem sleep when Battery Saver is enabled and audio/calls are inactive. Association stays enabled. Audio playback and calls request the previous no-modem-sleep behavior. The WiFi task reevaluates on its 100 ms cycle; commands still notify/wake it immediately. Router compatibility, rejoining, inbound calls and uninterrupted streams need physical checks.

The CPU remains at 240 MHz. The UI respects LVGL deadlines and can wait up to 20 ms rather than waking at least every 5 ms. Identical label updates, unchanged map images and idle workout ring redraws are suppressed. Display refresh is paused while the panel sleeps; service timers continue. The existing 30-second auto-lock remains the default. This improves idle behavior but auto-lock must not be counted as screen-on runtime.

## Electrical target

- Ideal current ceiling: 800 mAh / 3 h = 266.7 mA averaged at the battery terminals.
- A 10% usable-capacity reserve gives a working target of 240 mA average.
- Nominal energy: 3.7 V x 0.8 Ah = 2.96 Wh, or about 0.987 W for three hours before reserve.
- At 240 mA average, 800 mAh is 3.33 h ideally; at 300 mA it is 2.67 h; at 400 mA it is 2 h. Actual cutoff, regulator loss, cell age, temperature, WiFi signal and speaker output affect the result.

## Three-hour physical acceptance test

1. Fully charge the actual connected cell, then run on battery power. Measure current on the battery side of the board. A USB power reading during charging is not the battery discharge current.
2. Enable Battery Saver. Record requested and effective brightness, volume, WiFi signal, board revision and cell identification. Disable auto-lock only for this screen-on test; restore it afterward.
3. Keep the display visibly on for three hours. Use a repeatable workload: navigation/reading, local music, streamed radio and short recordings in recorded proportions. Also measure continuous streaming separately because WiFi power saving is disabled during playback.
4. Log elapsed time, battery-terminal voltage and average current. Check touch responsiveness, recording save/playback, stream continuity and display stability throughout. Measure frame intervals during scrolling rather than using simulator speed as a hardware FPS measurement.
5. Pass only if the device remains usable for at least three hours on this cell at the recorded settings. If average draw exceeds about 267 mA (or capacity is below 800 mAh), the target needs lower measured loads or more usable battery capacity; do not replace measurement with a percentage estimate.

The battery gauge is still voltage-based. Charging status is not measured by this HAL. The new policy does not claim calibrated charge percentage, charging detection, three-hour runtime or sustained 30 FPS.
