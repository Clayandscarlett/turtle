# N9 application and battery diagnosis — third pass

The current ESP32-S3 firmware builds and its four packaged-image checksums pass. All 32 registered applications passed sampled online/offline navigation in English and Cree (128 scenarios); no matrix run reported a sanitizer error, leak, or unexpected label overflow. Another 12,000 randomized steps across both languages passed. This is a diagnostic candidate, not a claim that every feature works on a physical phone.

## Repairs in this pass

- Radio no longer treats queued play intent as completed connection. It waits for an advancing decoder position, tries the configured backup once, times out custom stations without backups, preserves its failure message, and cancels pending tuning when stopped. Four explicit delayed/stalled/cancel cases pass.
- The audio task waits at most 1.5 seconds for the shared HTTP transport lock; reader calls wait at most five seconds. Web/news add a 25-second request budget checked between retries/redirects and at body writes. These prevent unbounded lock waiting and continued body/retry work after the budget, but are **not hard wall-clock deadlines**: an in-progress DNS/TLS/header read or queued earlier download can still take longer. Active transfers are not forcibly interrupted.
- Closed or superseded queued Web work, closed Newsstand pages and closed Maps views skip unnecessary fetching. Liveness tokens are atomic so worker checks do not race UI deletion. The simulator now supports delayed jobs to exercise close-before-completion behavior; it still does not emulate real thread scheduling or TLS memory.
- A malformed MJPEG frame no longer grows an unbounded buffer. Frames are capped at 256 KiB, pre-frame scanning is bounded, and malformed/truncated/oversized JPEG dimensions stop playback safely. Width/height above 640 are rejected; the player still crops its existing output to at most 320 pixels. This is not general video codec support.
- Notes reads stop at 64 KiB. Failed reads cannot open a blank editable replacement. Saves first write a .pending file, check the write and close, then rename. A failed save leaves an existing original intact and displays an error. Pending files may require manual recovery. The host tests cover create/reopen, a forced save-path failure, and a 1 MiB note rejection; physical SD/power-loss behavior remains untested.
- Cached map tile files are capped on read. A restored music queue computes its index before replacing the vector, avoiding invalid iterator use.
- Repeated identical label text, unchanged map image sources, and unchanged Fitness ring angles no longer trigger unnecessary work. Display refresh pauses while the panel sleeps; service timers remain active.

## Battery optimization

Battery Saver defaults ON and is controlled in Settings > Battery. It caps effective backlight brightness at 55% while retaining the requested setting, restores that setting when disabled, and enables WiFi minimum modem sleep while playback/calls are inactive. The CPU stays at 240 MHz. UI waits follow LVGL deadlines, capped at 20 ms instead of 5 ms; WiFi housekeeping uses a 100 ms cycle with immediate notification for commands.

Across 32 controlled ten-second idle-app runs, with startup excluded and all unrelated objects shared between comparison binaries, flushed pixels fell from 1,550,590 to 496,420 (68.0% fewer); flush calls fell from 1,060 to 675 (36.3% fewer). The comparison restores only the previous theme, Fitness and Maps implementations. This measures rendering work, **not whole-device current, battery-life improvement, or hardware FPS**.

The requested 800 mAh / three-hour target implies at most 266.7 mA average battery current ideally. A 240 mA target leaves a 10% capacity reserve. The default 70% requested brightness previously commanded 501/1023 PWM duty; the 55% cap commands 309/1023, 38.3% less duty. Total board power and perceived brightness do not scale directly with this number. See BATTERY_PROFILE.md for the physical acceptance procedure. No three-hour runtime has been measured.

## Verification of this candidate

| Check | Result |
|---|---|
| ESP32-S3 build and packaged images | PASS; 4/4 image hashes |
| Static RAM / flash | 100,076 / 327,680 bytes; 4,688,214 / 6,291,456 bytes |
| App matrix | 32 apps x 2 languages x 2 connectivity states: 128 PASS, each with root and five tap/scroll/back probes |
| New randomized navigation | 6,000 steps seed 934 English + 6,000 seed 935 Cree: PASS, no reported sanitizer/leak/layout errors |
| Functional workflows | Routes, memo record/save/play, close while recording, missing mic, WiFi, nanoLink navigation, abandoned/delayed jobs, sleep/wake stress: PASS |
| Radio connection faults | Delayed success, stalled primary/backup, stalled custom endpoint, cancel pending: 4 PASS |
| Media and saved-data cases | Valid video, four malformed video cases, photo navigation, note create/reopen, failed note write, oversized note, calculator repeated equals: 10 PASS |
| JPEG reader unit cases | Six marker-boundary/missing-end cases; 32 MiB malformed input bounded to 256 KiB allocation: PASS |
| Power policy and bounded-lock checks | 416 PASS, including millis wrap |
| Battery Saver UI | Toggle, saved setting, brightness restoration, dim, sleep and wake assertions: PASS |
| Codec fault injection | 42 PASS from actual driver under ASan/UBSan |
| Approved font coverage | 90 mappings / 66 syllabics codepoints: PASS |
| nanoLink server | 21/21 host integration tests PASS |

Tests use the actual UI under ASan/UBSan. The simulator's radio and battery remain substitutes: stream flags/delays are controlled, no real codec audio is produced, and battery voltage/current discharge is not modeled. RAM/flash sizes exclude dynamic heap/PSRAM peaks. A browser address-field audit warning was visually checked and identified as intentional horizontal editing scroll; that precise case is now excluded by the audit.

## What remains unverified or unavailable

No serial device was attached or flashed. Real recording quality, SD flush/rename latency, codec/USB audio, live TLS under concurrent load, modem-sleep/router compatibility, charging state, calibrated percentage, sustained 30 FPS and three-hour screen-on battery life require the board. Network queue depth, active downloads, and blocking SDK operations can still delay later requests despite the new guards.

Camera and Compass cannot perform their functions without a camera/magnetometer. Video Call has no camera/service. Bluetooth is unimplemented. Cellular calls are unavailable; Phone/Messages use a configured nanoLink relay. Mail needs account/server configuration. Websites needing JavaScript or DRM streaming are outside this text reader. Earlier live SomaFM samples decoded as 128 kbps MP3 on the host; that result was not a physical speaker test.

The approved Cree vocabulary remains incomplete. No translations were invented. Months, dates and many remaining UI messages still need approved words. New battery/error explanatory text also remains English where no approved mapping exists. This candidate does not meet the earlier every-word-in-Cree requirement yet.

Read APPLICATION_CHECK.md for all 32 application-specific outcomes and limits. Prior detailed endpoint/parser/board-reference evidence remains in the diagnostic evidence package; those historical checks are not represented as repeated hardware validation.
