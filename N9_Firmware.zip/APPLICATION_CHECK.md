# Application-by-application check

Each of the 32 registered apps was exercised in English and Cree with simulated connectivity on and off (128 scenarios). Each scenario checked root launch, five deterministic tap/scroll/back branches, and return Home. No test process failed or reported a sanitizer/leak error. Final matrix has no layout warnings. These are sampled workflows, not exhaustive proof of all states or physical functionality.

A browser audit warning was inspected visually: its editable one-line URL field intentionally scrolls within its clipped viewport. The audit now excludes this specific expected case. All 32 linked app entry points are strong implementations; none resolved to the weak Coming soon fallback.

| App | Four matrix cases | Additional evidence / boundary |
|---|---|---|
| music | PASS | Local library/player routes; decoder, SD timing and speaker require device testing. |
| videos | PASS | Valid MJPEG plus missing markers, malformed JPEG and truncation tested; frames bounded to 256 KiB, dimensions <=640x640. Physical decode rate pending. |
| fitness | PASS | Timer/goal screens; only changed ring angles redraw. No motion sensor, so no real steps or distance. |
| podcasts | PASS | Local library and feed/download UI; full downloads and physical playback pending. |
| photos | PASS | JPEG/PNG and corrupt-photo navigation tested; physical SD latency pending. |
| radio | PASS | Delayed connection, failed primary/backup, no-backup failure and cancel tested with explicit simulated stalled/delayed streams. Physical TLS/audio pending. |
| clock | PASS | Clock, stopwatch/timer/alarm navigation and sleep/wake stress; real alarm audio and time synchronization pending. |
| settings | PASS | Routes, WiFi/nanoLink navigation, Battery Saver toggle/dim/sleep/wake assertions pass. Bluetooth service is unavailable. |
| audiobooks | PASS | Shared local-library/player navigation; physical decode/bookmark behavior pending. |
| voicememos | PASS | Fixture-based record/save/play, close while recording, and missing microphone pass. Real microphone, SD errors and recording quality pending. |
| phone | PASS | Keypad/contacts/nanoLink navigation; relay integration tests pass on host. Cellular calls unavailable; actual WiFi calls pending. |
| messages | PASS | UI/nanoLink navigation; relay host integration tests pass. External deployed delivery pending. |
| mail | PASS | Account and compose navigation; actual configured IMAP/SMTP service not supplied or tested. |
| web | PASS | Online/offline reader paths, delayed abandoned request cancellation and prior adversarial parser checks. Text reader cannot run JavaScript. |
| calendar | PASS | Month/day/event navigation; no full physical persistence or complete approved month translation certification. |
| camera | PASS | Unavailable: this board configuration has no camera; explanation and shutter alert tested. |
| weather | PASS | Fixture-driven online/offline navigation; live location/weather and queued cancellation not fully validated on hardware. |
| maps | PASS | Fixture tile navigation; unchanged images no longer reload, closed-view queued work skips fetching, disk tile reads capped. No GPS hardware. |
| notes | PASS | Create/save/reopen, forced write failure preserving original, and 1 MiB note rejection pass. SD power-loss behavior remains physical. |
| reminders | PASS | List/editor/check navigation; physical SD persistence failures remain unverified. |
| stocks | PASS | Online/offline UI; live provider availability and limits are external dependencies. |
| contacts | PASS | List/editor navigation and nanoLink integration; physical import/save stress pending. |
| calculator | PASS | Arithmetic and repeated equals asserted in addition to navigation. |
| compass | PASS | Unavailable: no magnetometer; explanation screen checked. |
| videocall | PASS | Unavailable: no camera/video service; explanation and contacts navigation checked. |
| games | PASS | Game menu/navigation plus random interaction stress; this is not exhaustive proof of every game state. |
| newsstand | PASS | Online/offline feed navigation, delayed close, prior live feed replay and malformed reader cases; queued closed-page work skips fetching. |
| musicstore | PASS | Catalog/download UI; service responses and real downloads remain external/device dependencies. |
| apps | PASS | Store/update UI; no OTA was executed or hardware flashed. |
| passes | PASS | Pass collection/editor navigation; physical storage behavior pending. |
| nowplaying | PASS | Shared transport UI checked; real audio/USB output pending. |
| bible | PASS | Reader/selection navigation checked; content availability depends on installed SD assets. |
