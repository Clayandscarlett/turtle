#!/usr/bin/env python3
"""Fault-test the production Music thumbnail allocator, without a phone/card."""
from pathlib import Path
import os
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parents[1]
with tempfile.TemporaryDirectory(prefix="n9-music-placeholder-") as directory:
    binary = Path(directory) / "placeholder-test"
    subprocess.run([
        os.environ.get("CXX", "g++"), "-std=c++17", "-O1", "-g", "-Wall", "-Wextra",
        "-Wno-unused-parameter", "-Wno-missing-field-initializers",
        "-ffunction-sections", "-fdata-sections", "-fsanitize=address,undefined",
        "-fno-omit-frame-pointer", "-DLV_CONF_INCLUDE_SIMPLE", "-DLV_LVGL_H_INCLUDE_SIMPLE",
        "-Iui", "-Isim/lvgl", "tools/test_music_placeholder.cpp", "ui/apps/music.cpp",
        "-Wl,--gc-sections", "-Wl,--wrap=malloc", "-Wl,--wrap=calloc", "-o", str(binary),
    ], cwd=ROOT, check=True)
    environment = dict(os.environ, ASAN_OPTIONS="detect_leaks=0:halt_on_error=1",
                       UBSAN_OPTIONS="halt_on_error=1")
    for mode in ("pixels", "descriptor", "normal"):
        subprocess.run([str(binary), mode], cwd=ROOT, env=environment, check=True)
