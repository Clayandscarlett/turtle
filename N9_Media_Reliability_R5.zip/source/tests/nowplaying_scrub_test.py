#!/usr/bin/env python3
"""Exercise real Now Playing slider gestures across playback generation changes.

Uses an already built simulator with disposable ten-second PCM WAVs. Checks UI
progress and the production player's persisted seek checkpoint. Audio remains
simulated; this does not measure the device's decoder, touch panel or sound.
"""
import argparse
import os
from pathlib import Path
import subprocess
import tempfile
import wave


def fixture(root):
    (root / "Music").mkdir(parents=True)
    (root / ".nanoos").mkdir()
    (root / ".nanoos/kv.txt").write_text("language=0\nautolock=0\n")
    for name in ("Track00", "Track01"):
        with wave.open(str(root / "Music" / (name + ".wav")), "wb") as output:
            output.setparams((1, 2, 16000, 0, "NONE", "not compressed"))
            output.writeframes(b"\0" * 320000)


OPEN = "wait 1200\nplay-library\nlaunch nowplaying\ntap 120 100\n"
HOLD = "press 120 40\n"  # Midpoint of the ten-second track's native seek slider.
RELEASE = "release\nwait 300\n"
SCENARIOS = {
    "ordinary-seek": (OPEN + HOLD + RELEASE +
                      "expect-current-path Music/Track00.wav\nexpect-label 0:05\n", "Track00", 5000),
    "auto-next-during-hold": (OPEN + HOLD + "wait 9000\n"
                              "expect-current-path Music/Track01.wav\n" + RELEASE +
                              "expect-current-path Music/Track01.wav\nexpect-no-label 0:05\n",
                              "Track01", 0),
    "same-path-restart-during-hold": (OPEN + HOLD + "play-library\n" + RELEASE +
                                      "expect-current-path Music/Track00.wav\nexpect-no-label 0:05\n",
                                      "Track00", 0),
    "repeat-one-during-hold": (OPEN + "tap 28 85\ntap 28 85\n" + HOLD + "wait 9000\n" + RELEASE +
                               "expect-current-path Music/Track00.wav\nexpect-no-label 0:05\n",
                               "Track00", 0),
}


def run(simulator, output):
    for name, (commands, track, position) in SCENARIOS.items():
        directory = output / name
        directory.mkdir(parents=True)
        card = directory / "card"
        fixture(card)
        script = directory / "scenario.txt"
        script.write_text(commands)
        env = dict(os.environ, NANO_SDROOT=str(card), NANO_SIM_ASYNC_DELAY_MS="0")
        env.setdefault("ASAN_OPTIONS", "detect_leaks=0:halt_on_error=1")
        result = subprocess.run([str(simulator), str(script), str(directory / "shots")],
                                cwd=simulator.parent, env=env, stdout=subprocess.PIPE,
                                stderr=subprocess.STDOUT, text=True)
        (directory / "simulator.log").write_text(result.stdout)
        if result.returncode or "unknown command:" in result.stdout:
            raise SystemExit("FAIL %s (exit %s)\n%s" % (name, result.returncode, result.stdout))
        values = dict(line.split("=", 1) for line in (card / ".nanoos/kv.txt").read_text().splitlines()
                      if "=" in line)
        expected = str(card / "Music" / (track + ".wav"))
        if values.get("np_path") != expected or int(values.get("np_pos", -1)) != position:
            raise SystemExit("FAIL %s checkpoint: %r / %r" %
                             (name, values.get("np_path"), values.get("np_pos")))
        if name == "repeat-one-during-hold" and values.get("np_rep") != "2":
            raise SystemExit("FAIL repeat-one gesture did not enable repeat-one")
        print("PASS", name, flush=True)
    print("%d production Now Playing scrub scenarios passed." % len(SCENARIOS))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sim", required=True, type=Path)
    parser.add_argument("--output", type=Path, help="New directory for fixtures, scripts and logs")
    args = parser.parse_args()
    if args.output:
        args.output.mkdir(parents=True, exist_ok=False)
        run(args.sim.resolve(), args.output.resolve())
    else:
        with tempfile.TemporaryDirectory(prefix="n9-nowplaying-scrub-") as directory:
            run(args.sim.resolve(), Path(directory))
