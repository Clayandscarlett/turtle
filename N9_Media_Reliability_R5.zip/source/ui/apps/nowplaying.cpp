/* Now Playing — full-bleed artwork, song info, transport. Tap the artwork for the scrubber,
 * repeat/shuffle and volume; swipe left for the track list. */
#include "media_ui.h"

using namespace th;

namespace media {

struct NP {
    os::Nav* nav;
    lv_obj_t *page, *art, *info_grad, *title, *sub, *play_btn, *play_g;
    lv_obj_t *ovl, *scrub, *t_el, *t_rem, *count, *rep, *shuf, *vol, *live;
    int version = -1;
    int scrub_version = -1;
    uint32_t ovl_until = 0;
    bool scrubbing = false;
    bool scrub_cancelled = false;
};

static void np_art(NP* np) {
    /* art::bind keeps a private copy (cache eviction can never pull it from under us), loads it
     * asynchronously, frees the previous copy on rebind and everything when the widget is deleted. */
    art::bind(np->art, player::current(), 240, &img_ph_art);
}

static void np_refresh(NP* np, bool full) {
    /* A held slider belongs to the playback generation on which it was pressed.
     * EOF can start another track (or repeat the same one) before release. Keep
     * the overlay open, but stop previewing or seeking from that stale gesture. */
    if (np->scrubbing && np->scrub_version != player::version()) np->scrub_cancelled = true;
    if (full || np->version != player::version()) {
        np->version = player::version();
        th::label_set_text(np->title, player::title().c_str());
        std::string s = player::artist();
        std::string al = player::album();
        if (!al.empty() && !player::is_stream()) s += " \xE2\x80\x94 " + al;
        th::label_set_text(np->sub, s.c_str());
        np_art(np);
        char b[32];
        if (player::count() > 0) snprintf(b, sizeof b, "%d of %d", player::index() + 1, player::count());
        else b[0] = 0;
        th::label_set_text(np->count, b);
        bool stream = player::is_stream();
        if (stream) { lv_obj_add_flag(np->scrub, LV_OBJ_FLAG_HIDDEN); lv_obj_remove_flag(np->live, LV_OBJ_FLAG_HIDDEN); }
        else { lv_obj_remove_flag(np->scrub, LV_OBJ_FLAG_HIDDEN); lv_obj_add_flag(np->live, LV_OBJ_FLAG_HIDDEN); }
    }
    if (player::is_stream()) th::label_set_text(np->sub, player::artist().c_str());
    lv_image_set_src(np->play_g, player::playing() ? &gl_pause_l : &gl_play_l);
    uint32_t pos = player::pos(), dur = player::dur();
    if (!np->scrubbing || np->scrub_cancelled) {
        lv_slider_set_range(np->scrub, 0, dur > 0 ? (int32_t)(dur / 1000) : 1);
        lv_slider_set_value(np->scrub, (int32_t)(pos / 1000), LV_ANIM_OFF);
    } else pos = (uint32_t)lv_slider_get_value(np->scrub) * 1000;
    th::label_set_text(np->t_el, fmt_time_ms(pos).c_str());
    th::label_set_text(np->t_rem, dur ? ("-" + fmt_time_ms(dur > pos ? dur - pos : 0)).c_str() : "--:--");
    lv_obj_set_style_image_recolor(np->rep, c(player::repeat() == player::R_OFF ? 0xFFFFFF : 0x3E9BFF), 0);
    lv_image_set_src(np->rep, player::repeat() == player::R_ONE ? &gl_repeat1 : &gl_repeat);
    lv_obj_set_style_image_recolor(np->shuf, c(player::shuffle() ? 0x3E9BFF : 0xFFFFFF), 0);
    if (np->ovl_until && lv_tick_get() > np->ovl_until && !np->scrubbing) {
        np->ovl_until = 0;
        lv_obj_add_flag(np->ovl, LV_OBJ_FLAG_HIDDEN);
        lv_obj_remove_flag(np->info_grad, LV_OBJ_FLAG_HIDDEN);
    }
}

static lv_obj_t* tbtn(lv_obj_t* parent, const lv_image_dsc_t* g, int cx, int cy, int w = 64, int h = 52) {
    lv_obj_t* b = box(parent, cx - w / 2, cy - h / 2, w, h);
    lv_obj_add_flag(b, LV_OBJ_FLAG_CLICKABLE);
    lv_obj_set_style_radius(b, 8, 0);
    lv_obj_set_style_bg_color(b, c(0xFFFFFF), LV_STATE_PRESSED);
    lv_obj_set_style_bg_opa(b, LV_OPA_20, LV_STATE_PRESSED);
    lv_obj_t* im = glyph(b, g, 0xFFFFFF);
    lv_obj_add_flag(im, LV_OBJ_FLAG_EVENT_BUBBLE);
    lv_obj_center(im);
    return b;
}

static void show_overlay(NP* np) {
    lv_obj_remove_flag(np->ovl, LV_OBJ_FLAG_HIDDEN);
    lv_obj_add_flag(np->info_grad, LV_OBJ_FLAG_HIDDEN);
    np->ovl_until = lv_tick_get() + 5000;
}

void push_now_playing(os::Nav* nav, bool animated) {
    NP* np = new NP();
    np->nav = nav;
    lv_obj_t* body = nav->push("Now Playing", os::NavStyle::None, animated, 0x000000);
    np->page = nav->top().obj;
    lv_obj_set_user_data(np->page, NP_TAG);
    lv_obj_add_event_cb(np->page, [](lv_event_t* e) { delete (NP*)lv_event_get_user_data(e); }, LV_EVENT_DELETE, np);

    /* artwork */
    np->art = lv_image_create(body);
    lv_obj_set_pos(np->art, 0, 0);
    lv_obj_set_size(np->art, 240, 240);
    lv_image_set_inner_align(np->art, LV_IMAGE_ALIGN_STRETCH);
    lv_obj_add_flag(np->art, LV_OBJ_FLAG_CLICKABLE);
    on_click(np->art, [np] {
        if (lv_obj_has_flag(np->ovl, LV_OBJ_FLAG_HIDDEN)) show_overlay(np);
        else { np->ovl_until = 1; np_refresh(np, false); }
    });
    /* song info over a dark gradient at the foot of the artwork */
    np->info_grad = box(body, 0, 172, 240, 68);
    lv_obj_set_style_bg_opa(np->info_grad, LV_OPA_COVER, 0);
    lv_obj_set_style_bg_color(np->info_grad, c(0x000000), 0);
    lv_obj_set_style_bg_main_opa(np->info_grad, LV_OPA_TRANSP, 0);
    lv_obj_set_style_bg_grad_opa(np->info_grad, LV_OPA_80, 0);
    lv_obj_set_style_bg_grad_color(np->info_grad, c(0x000000), 0);
    lv_obj_set_style_bg_grad_dir(np->info_grad, LV_GRAD_DIR_VER, 0);
    np->title = label(np->info_grad, "", B15, 0xFFFFFF);
    add_text_shadow(np->title, 0x000000, LV_OPA_80, 1);
    th::dot1(np->title);
    lv_obj_set_width(np->title, 224);
    lv_obj_set_pos(np->title, 8, 26);
    np->sub = label(np->info_grad, "", R13, 0xD0D0D6);
    add_text_shadow(np->sub, 0x000000, LV_OPA_80, 1);
    th::dot1(np->sub);
    lv_obj_set_width(np->sub, 224);
    lv_obj_set_pos(np->sub, 8, 45);

    /* transport bar */
    lv_obj_t* bar = grad(body, 0, 240, 240, 60, 0x2E2F33, 0x0A0A0B);
    lv_obj_set_style_border_width(bar, 1, 0);
    lv_obj_set_style_border_side(bar, LV_BORDER_SIDE_TOP, 0);
    lv_obj_set_style_border_color(bar, c(0x4A4B50), 0);
    lv_obj_t* pv = tbtn(bar, &gl_prev_l, 46, 30);
    on_click(pv, [np] { player::prev(); np_refresh(np, false); });
    np->play_btn = tbtn(bar, &gl_play_l, 120, 30);
    np->play_g = lv_obj_get_child(np->play_btn, 0);
    on_click(np->play_btn, [np] { player::toggle(); np_refresh(np, false); });
    lv_obj_t* nx = tbtn(bar, &gl_next_l, 194, 30);
    on_click(nx, [np] { player::next(); np_refresh(np, false); });

    /* control overlay (tap artwork) */
    np->ovl = fill(body, 0, 0, 240, 240, 0x000000, LV_OPA_60);
    lv_obj_add_flag(np->ovl, LV_OBJ_FLAG_CLICKABLE);
    on_click(np->ovl, [np] { np->ovl_until = 1; np_refresh(np, false); });
    np->t_el = label(np->ovl, "0:00", B11, 0xFFFFFF);
    lv_obj_set_pos(np->t_el, 6, 17);
    np->t_rem = label(np->ovl, "-0:00", B11, 0xFFFFFF);
    lv_obj_align(np->t_rem, LV_ALIGN_TOP_RIGHT, -6, 17);
    np->scrub = slider(np->ovl, 150, true);
    lv_obj_set_pos(np->scrub, 45, 20);
    lv_obj_set_style_height(np->scrub, 5, 0);
    lv_obj_set_style_pad_all(np->scrub, 4, LV_PART_KNOB);
    lv_obj_add_event_cb(np->scrub, [](lv_event_t* e) {
        lv_event_code_t code = lv_event_get_code(e);
        /* input events only: on DELETE the page (and np) is already gone */
        if (code != LV_EVENT_PRESSED && code != LV_EVENT_PRESSING && code != LV_EVENT_RELEASED &&
            code != LV_EVENT_PRESS_LOST && code != LV_EVENT_VALUE_CHANGED) return;
        NP* np = (NP*)lv_event_get_user_data(e);
        if (code == LV_EVENT_PRESSED) {
            np->scrubbing = true;
            np->scrub_version = player::version();
            np->scrub_cancelled = false;
        }
        else if (code == LV_EVENT_RELEASED || code == LV_EVENT_PRESS_LOST) {
            const bool seek = np->scrubbing && !np->scrub_cancelled &&
                              np->scrub_version == player::version();
            np->scrubbing = false;
            np->scrub_version = -1;
            np->scrub_cancelled = false;
            if (seek) player::seek((uint32_t)lv_slider_get_value(np->scrub) * 1000);
        }
        np->ovl_until = lv_tick_get() + 5000;
    }, LV_EVENT_ALL, np);
    np->live = label(np->ovl, "LIVE", B13, 0xFF453A);
    lv_obj_align(np->live, LV_ALIGN_TOP_MID, 0, 15);
    np->rep = glyph(np->ovl, &gl_repeat, 0xFFFFFF);
    lv_obj_set_pos(np->rep, 18, 56);
    lv_obj_add_flag(np->rep, LV_OBJ_FLAG_CLICKABLE);
    lv_obj_set_ext_click_area(np->rep, 12);
    on_click(np->rep, [np] {
        player::set_repeat((player::Repeat)((player::repeat() + 1) % 3));
        os::hud(player::repeat() == player::R_OFF ? "Repeat Off" : player::repeat() == player::R_ALL ? "Repeat All" : "Repeat Song", nullptr, 900);
        np->ovl_until = lv_tick_get() + 5000;
        np_refresh(np, false);
    });
    np->count = label(np->ovl, "", B13, 0xFFFFFF);
    lv_obj_align(np->count, LV_ALIGN_TOP_MID, 0, 56);
    np->shuf = glyph(np->ovl, &gl_shuffle, 0xFFFFFF);
    lv_obj_set_pos(np->shuf, 240 - 18 - 20, 56);
    lv_obj_add_flag(np->shuf, LV_OBJ_FLAG_CLICKABLE);
    lv_obj_set_ext_click_area(np->shuf, 12);
    on_click(np->shuf, [np] {
        player::set_shuffle(!player::shuffle());
        os::hud(player::shuffle() ? "Shuffle On" : "Shuffle Off", nullptr, 900);
        np->ovl_until = lv_tick_get() + 5000;
        np_refresh(np, true);
    });
    /* volume (replaces the nano's volume buttons) */
    lv_obj_t* vlo = glyph(np->ovl, &gl_vol_lo, 0xFFFFFF);
    lv_obj_set_pos(vlo, 12, 206);
    lv_obj_t* vhi = glyph(np->ovl, &gl_vol_hi, 0xFFFFFF);
    lv_obj_set_pos(vhi, 240 - 12 - 15, 206);
    np->vol = slider(np->ovl, 170, true);
    lv_obj_set_pos(np->vol, 35, 209);
    lv_slider_set_range(np->vol, 0, 100);
    lv_slider_set_value(np->vol, os::volume(), LV_ANIM_OFF);
    lv_obj_add_event_cb(np->vol, [](lv_event_t* e) {
        NP* np = (NP*)lv_event_get_user_data(e);
        os::set_volume(lv_slider_get_value(np->vol));
        np->ovl_until = lv_tick_get() + 5000;
    }, LV_EVENT_VALUE_CHANGED, np);
    lv_obj_t* lst = glyph(np->ovl, &gl_list, 0xFFFFFF);
    lv_obj_align(lst, LV_ALIGN_TOP_MID, 0, 150);
    lv_obj_add_flag(lst, LV_OBJ_FLAG_CLICKABLE);
    lv_obj_set_ext_click_area(lst, 14);
    lv_obj_t* lstl = label(np->ovl, "Track List", B11, 0xC8C8CE);
    lv_obj_align(lstl, LV_ALIGN_TOP_MID, 0, 168);
    on_click(lst, [np] { push_queue(np->nav); });
    lv_obj_add_flag(np->ovl, LV_OBJ_FLAG_HIDDEN);

    /* swipe left for the track list */
    lv_obj_add_event_cb(np->page, [](lv_event_t* e) {
        NP* np = (NP*)lv_event_get_user_data(e);
        if (lv_indev_get_gesture_dir(lv_indev_active()) == LV_DIR_LEFT && !player::is_stream()) {
            lv_indev_wait_release(lv_indev_active());
            push_queue(np->nav);
        }
    }, LV_EVENT_GESTURE, np);

    np_refresh(np, true);
    os::every(250, [np] { np_refresh(np, false); }, np->page);
    nav->top().on_show = [np] { np_refresh(np, true); };
}

void push_queue(os::Nav* nav) {
    if (player::queue().empty()) return;
    lv_obj_t* body = nav->push(player::album().c_str());
    lv_obj_set_user_data(nav->top().obj, QUEUE_TAG);
    lv_obj_t* title = nav->top().title;
    struct Data : LibraryRevision {
        int count = 0;
        std::vector<lv_obj_t*> stars;
        os::VList* list = nullptr;
        lv_obj_t* empty = nullptr;
        int player_revision = -1;
        bool current() const {
            return LibraryRevision::current() && player_revision == player::version();
        }
    };
    auto data = std::make_shared<Data>();
    /* rating row for the current song (the nano's star rating) */
    lv_obj_t* rate = grad(body, 0, 0, SCR_W, 34, 0x4A4C52, 0x2A2B2F);
    for (int i = 0; i < 5; i++) {
        lv_obj_t* s = glyph(rate, &gl_star_l, 0x6E7077);
        lv_obj_set_pos(s, 55 + i * 28, 8);
        lv_obj_add_flag(s, LV_OBJ_FLAG_CLICKABLE);
        lv_obj_set_ext_click_area(s, 6);
        data->stars.push_back(s);
        on_click(s, [data, i] {
            if (!data->current()) return;
            int id = player::current();
            const lib::Track* t = id >= 0 ? lib::get(id) : nullptr;
            if (!t) return;
            int r = t->rating == i + 1 ? 0 : i + 1;
            lib::set_rating(id, r);
            for (int k = 0; k < 5; k++) lv_obj_set_style_image_recolor(data->stars[k], c(k < r ? 0xFFFFFF : 0x6E7077), 0);
        });
    }
    lv_obj_t* holder = box(body, 0, 34, SCR_W, lv_obj_get_height(body) - 34);
    auto refresh = [data, holder, title, nav] {
        data->count = player::count();
        data->accept();
        data->player_revision = player::version();
        th::label_set_text(title, player::album().c_str());
        const lib::Track* current = player::track();
        int rating = current ? current->rating : 0;
        for (int i = 0; i < 5; i++)
            lv_obj_set_style_image_recolor(data->stars[i], c(i < rating ? 0xFFFFFF : 0x6E7077), 0);
        os::VListSpec sp;
        sp.count = data->count;
        sp.chevron = false;
        sp.bind = [data](int i, os::VRow& r) {
            clear_row(r);
            if (!data->current() || i < 0 || i >= data->count) return;
            const lib::Track* t = lib::get(player::queue()[i]);
            if (!t) return;
            char b[16];
            snprintf(b, sizeof b, "%d.", i + 1);
            std::string s = std::string(b) + " " + t->title;
            th::label_set_text(r.title, s.c_str());
            th::label_set_text(r.detail, t->dur_ms ? fmt_time_ms(t->dur_ms).c_str() : "");
            if (i == player::index()) lv_obj_remove_flag(r.dot, LV_OBJ_FLAG_HIDDEN);
        };
        sp.click = [data, nav](int i) {
            /* An old visible label must never act on a renumbered/replaced queue.
             * Let the refresh timer rebuild it, then require a new tap. */
            if (!data->current() || i < 0 || i >= data->count) return;
            player::jump(i);   /* preserve the live queue and its exact shuffle order */
            nav->pop(true);
        };
        if (data->list) reset_list(data->list, sp);
        else data->list = new os::VList(holder, sp);
        list_empty_state(holder, data->list, data->empty, sp.count == 0, "No Songs");
    };
    refresh();
    data->list->scroll_to_item(player::index() > 2 ? player::index() - 2 : 0);
    os::every(200, [data, body, refresh] {
        if (lv_obj_is_visible(body) && !data->current()) refresh();
    }, body);
    nav->top().on_show = refresh;
}

} // namespace media
