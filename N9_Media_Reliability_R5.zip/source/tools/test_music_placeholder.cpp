/* Exercise the production Music artwork placeholder with exact allocator faults.
 * Unused app sections are discarded by the linker; art::bind only records the
 * actual descriptor passed by media::set_art. No copied thumbnail implementation.
 */
#include "../ui/apps/media_ui.h"
#include <cassert>
#include <cstdlib>
#include <cstring>
#include <cstdio>

static uint16_t source_pixels[240 * 240];
const lv_image_dsc_t img_ph_art = [] {
    lv_image_dsc_t image{};
    image.header.magic = LV_IMAGE_HEADER_MAGIC;
    image.header.cf = LV_COLOR_FORMAT_RGB565;
    image.header.w = image.header.h = 240;
    image.header.stride = 480;
    image.data = reinterpret_cast<const uint8_t*>(source_pixels);
    image.data_size = sizeof source_pixels;
    return image;
}();

static const lv_image_dsc_t* shown = nullptr;
static bool fail_pixels = false, fail_descriptor = false;
static unsigned pixel_allocations = 0;

extern "C" void* __real_malloc(size_t);
extern "C" void* __real_calloc(size_t, size_t);
extern "C" void* __wrap_malloc(size_t bytes) {
    if (bytes == 44 * 44 * 2) {
        ++pixel_allocations;
        if (fail_pixels) return nullptr;
    }
    return __real_malloc(bytes);
}
extern "C" void* __wrap_calloc(size_t count, size_t bytes) {
    if (fail_descriptor && count == 1 && bytes == sizeof(lv_image_dsc_t)) return nullptr;
    return __real_calloc(count, bytes);
}
namespace art {
void bind(lv_obj_t*, int, int, const lv_image_dsc_t* placeholder) { shown = placeholder; }
}

static void check_thumbnail() {
    assert(shown && shown != &img_ph_art && shown->data);
    assert(shown->header.w == 44 && shown->header.h == 44);
    assert(shown->header.stride == 88 && shown->data_size == 44 * 44 * 2);
    const auto* pixels = reinterpret_cast<const uint16_t*>(shown->data);
    for (int y = 0; y < 44; ++y) for (int x = 0; x < 44; ++x)
        assert(pixels[y * 44 + x] == source_pixels[(y * 240 / 44) * 240 + x * 240 / 44]);
}

int main(int argc, char** argv) {
    assert(argc == 2);
    for (size_t i = 0; i < 240 * 240; ++i) source_pixels[i] = static_cast<uint16_t>(i);
    fail_pixels = std::strcmp(argv[1], "pixels") == 0;
    fail_descriptor = std::strcmp(argv[1], "descriptor") == 0;
    media::set_art(nullptr, -1, 44);
    if (fail_pixels) {
        assert(shown == &img_ph_art); // no half-built descriptor reaches LVGL
        fail_pixels = false;
        media::set_art(nullptr, -1, 44);
    }
    check_thumbnail();
    auto* cached = shown;
    auto allocations = pixel_allocations;
    fail_pixels = true;
    media::set_art(nullptr, -1, 44);
    assert(shown == cached && pixel_allocations == allocations);
    media::set_art(nullptr, -1, 240);
    assert(shown == &img_ph_art);
    std::printf("PASS placeholder %s: valid pixels, allocation fault/retry and stable cache\n", argv[1]);
}
