/*
 * nanoOS HAL for the Freenove FNK0104B (ESP32-S3).
 * Threads:  UI/LVGL = Arduino loop task (core 1)
 *           audio   = "audio" task (core 0) owns the decoder & I2S
 *           worker  = "net" task (core 0) runs run_async() jobs (HTTP, scans)
 */
/* GCC 14 reports a known false positive (-Wfree-nonheap-object) inside std::map node cleanup */
#pragma GCC diagnostic ignored "-Wfree-nonheap-object"
#include "hal.h"
#include "board.h"
#include "es8311.h"
#include "lcd.h"
#include "audio_dsp.h"
#include "tap_sound.h"
#include "svc/memo_wav.h"
#include "svc/power_policy.h"
#include "svc/request_budget.h"
#include "usb_audio.h"
#include "voice.h"
#include <Arduino.h>
#include <Wire.h>
#include <SD_MMC.h>
#include <Preferences.h>
#include <WiFi.h>
#include <Network.h>
#include <HTTPClient.h>
#include "tls_client.h"

#include <Audio.h>
#include <Update.h>
#include <map>
#include <algorithm>
#include <esp_sleep.h>
#include <esp_mac.h>
#include <driver/i2s_std.h>
#include <driver/gpio.h>
#include <driver/rtc_io.h>
#include <esp_sntp.h>
#include <esp_task_wdt.h>
#include <esp_heap_caps.h>
#include <lwip/dns.h>
#include <lwip/sockets.h>
#include <errno.h>
#include <sys/time.h>
#include <mutex>
#include <deque>
#include <atomic>
#include <mbedtls/sha256.h>
#include <ctype.h>

namespace hal {
extern "C" void nano_tls_alloc_reset_stats(void);
extern "C" size_t nano_tls_psram_alloc_bytes(void);
extern "C" size_t nano_tls_psram_alloc_count(void);
extern "C" size_t nano_tls_internal_fallback_count(void);
extern "C" size_t nano_tls_failed_alloc_count(void);

/* One HTTP/TLS transaction at a time.  This keeps peak handshake memory
 * deterministic when Weather, Maps, News, Stocks and Web wake together. */
static std::mutex s_http_transport_mutex;

static Preferences s_prefs;
static bool s_sd = false;
RTC_DATA_ATTR static volatile bool s_time_ok = false;   /* set by the user or by an SNTP sync */

/* ================================================================ lifecycle */
static void jobs_init();
static void dsp_configure(bool usb, uint32_t fs);

/* TLS certificate validation needs a plausible wall clock. On a cold boot the ESP32
 * RTC may start near 1970 and SNTP can itself take several seconds after DHCP. Use
 * the firmware build timestamp only as a bootstrap hint (never as a user-visible
 * "valid" clock), then let SNTP replace it as soon as Wi-Fi is connected. */
static time_t firmware_build_time_hint() {
    static const char* months = "JanFebMarAprMayJunJulAugSepOctNovDec";
    char mon[4] = {}; int day = 1, year = 1970, hh = 0, mm = 0, ss = 0;
    if (sscanf(__DATE__, "%3s %d %d", mon, &day, &year) != 3) return 0;
    if (sscanf(__TIME__, "%d:%d:%d", &hh, &mm, &ss) != 3) return 0;
    const char* mp = strstr(months, mon);
    if (!mp) return 0;
    struct tm t = {};
    t.tm_year = year - 1900; t.tm_mon = int((mp - months) / 3); t.tm_mday = day;
    t.tm_hour = hh; t.tm_min = mm; t.tm_sec = ss; t.tm_isdst = -1;
    return mktime(&t);
}

void init() {
    /* Pins held through a deep sleep (see shutdown()) are released only after they are configured to the
       same level, so nothing glitches. gpio_set_level before pinMode: the output latch is set before the
       driver is enabled (Arduino's digitalWrite is a no-op on a pin that is not yet a GPIO). */
    gpio_set_level((gpio_num_t)AMP_PIN_EN, 1);         /* amplifier off (SC8002B SHUTDOWN is active high) */
    pinMode(AMP_PIN_EN, OUTPUT);
    digitalWrite(AMP_PIN_EN, HIGH);                     /* off until there is something to play: no idle hiss */
    gpio_set_level((gpio_num_t)TP_PIN_RST, 1);
    pinMode(TP_PIN_RST, OUTPUT);
    digitalWrite(TP_PIN_RST, HIGH);
    gpio_set_level((gpio_num_t)LCD_PIN_BL, 0);
    pinMode(LCD_PIN_BL, OUTPUT);
    digitalWrite(LCD_PIN_BL, LOW);
    gpio_hold_dis((gpio_num_t)AMP_PIN_EN);
    gpio_hold_dis((gpio_num_t)TP_PIN_RST);
    gpio_hold_dis((gpio_num_t)LCD_PIN_BL);
    gpio_deep_sleep_hold_dis();
    rtc_gpio_deinit((gpio_num_t)TP_PIN_INT);            /* ext0 wake left it routed to the RTC domain */

    s_prefs.begin("nano", false);
    Serial.println("[boot] preferences ready");
    /* Do NOT globally redirect malloc() into PSRAM during boot.  v1.1.6 briefly
       enabled heap_caps_malloc_extmem_enable() here; that changes allocator semantics
       before I2C/LVGL/display startup and can strand peripheral/library allocations in
       external RAM.  LVGL already has an explicit PSRAM allocator and DMA buffers use
       MALLOC_CAP_INTERNAL, so keep the global allocator conservative. */
    if (psramFound()) {
        Serial.printf("[boot] PSRAM available: %u KB free (global malloc routing unchanged)\n",
                      (unsigned)(heap_caps_get_free_size(MALLOC_CAP_SPIRAM) / 1024));
    }

    /* The FT6336 and ES8311 share this bus.  Never assume begin() succeeded: on a
       sealed device a bad optional peripheral must degrade functionality, not reboot
       the whole OS.  A short Wire timeout also prevents a stuck slave from wedging boot. */
    bool i2c_ok = Wire.begin(I2C_PIN_SDA, I2C_PIN_SCL, I2C_HZ);
    Wire.setTimeOut(50);
    Serial.printf("[boot] I2C %s\n", i2c_ok ? "ready" : "FAILED (touch/audio disabled until next reboot)");

    /* microSD is optional.  A failed 4-bit attempt is explicitly torn down before
       trying conservative 1-bit mode; this avoids carrying partially-created SDMMC
       driver state into the fallback path. */
    SD_MMC.setPins(SD_PIN_CLK, SD_PIN_CMD, SD_PIN_D0, SD_PIN_D1, SD_PIN_D2, SD_PIN_D3);
    s_sd = SD_MMC.begin("/sdcard", false, false, SDMMC_FREQ_HIGHSPEED, 12);
    if (!s_sd) {
        SD_MMC.end();
        delay(10);
        s_sd = SD_MMC.begin("/sdcard", true, false, SDMMC_FREQ_DEFAULT, 12);
    }
    if (s_sd) {
        SD_MMC.mkdir("/.nanoos");
        Serial.printf("[boot] microSD ready: %llu MB\n", (unsigned long long)(SD_MMC.totalBytes() / (1024ULL * 1024ULL)));
    } else {
        SD_MMC.end();
        Serial.println("[boot] no usable microSD; continuing without removable storage");
    }

    bool codec_ok = i2c_ok && es8311_init();
    Serial.printf("[boot] ES8311 %s\n", codec_ok ? "ready" : "unavailable; continuing without codec audio");
    analogReadResolution(12);
    // A full single-cell LiPo presents about 2.1 V through the board's
    // 1:2 divider. Configure this pin explicitly; low attenuation clips it.
    analogSetPinAttenuation(BAT_ADC_PIN, ADC_11db);
    /* Restore a plausible wall clock for TLS. The build timestamp is a minimum so an
       old NVS/RTC value cannot make a newly-built firmware reject current certificates. */
    struct timeval tv;
    gettimeofday(&tv, nullptr);
    const int64_t saved = s_prefs.getLong64("t_saved", 0);
    const time_t hint = firmware_build_time_hint();
    time_t bootstrap = tv.tv_sec;
    if (saved > bootstrap) bootstrap = (time_t)saved;
    if (hint > bootstrap) bootstrap = hint;
    if (bootstrap > 1700000000 && tv.tv_sec < bootstrap) {
        tv.tv_sec = bootstrap; tv.tv_usec = 0; settimeofday(&tv, nullptr);
        Serial.printf("[time] TLS clock bootstrapped: %lld\n", (long long)bootstrap);
    }
    dsp_configure(false, 48000);
    /* run_async() is used during setup() (library rescan in services_init), long before start_tasks() */
    jobs_init();
}

uint32_t millis() { return ::millis(); }
const char* device_name() { return "nanoOS"; }
const char* fw_version() { return "1.1.9-media-reliability-r5"; }
const char* serial_number() {
    static char sn[16] = {0};
    if (!sn[0]) {
        uint8_t m[6];
        esp_efuse_mac_get_default(m);
        snprintf(sn, sizeof sn, "N7%02X%02X%02X%02X%02X", m[1], m[2], m[3], m[4], m[5]);
    }
    return sn;
}
uint32_t free_heap() { return heap_caps_get_free_size(MALLOC_CAP_INTERNAL); }
uint32_t free_psram() { return heap_caps_get_free_size(MALLOC_CAP_SPIRAM); }

/* ================================================================ time */
time_t now() { return time(nullptr); }
void set_time(time_t t) {
    struct timeval tv = {t, 0};
    settimeofday(&tv, nullptr);
    s_time_ok = true;
    s_prefs.putLong64("t_saved", (int64_t)t);
}
// A timestamp restored from flash is only a TLS/bootstrap hint. It is not a
// current clock after power loss. Wait for NTP or an explicit user setting.
bool time_valid() { return s_time_ok && now() > 1700000000; }
void set_timezone(const char* tz) { setenv("TZ", tz, 1); tzset(); }

/* ================================================================ power */
static std::atomic<bool> s_power_saver{true};
static uint8_t s_requested_backlight = 0;
bool power_saver_enabled() { return s_power_saver.load(); }
void backlight(uint8_t pct) {
    s_requested_backlight = pct;
    lcd_backlight(power_policy::brightness(pct, power_saver_enabled()));
}
void set_power_saver(bool enabled) {
    s_power_saver = enabled;
    backlight(s_requested_backlight);
}
void panel_sleep(bool s) { lcd_sleep(s); }
void display_invert(bool on) { lcd_invert(on); }
void display_landscape(bool on) { lcd_landscape(on); }

static int s_batt_mv = 0;
static uint32_t s_batt_t = 0;
int battery_mv() {
    if (!s_batt_t || ::millis() - s_batt_t > 5000) {
        uint32_t acc = 0;
        for (int i = 0; i < 8; i++) acc += analogReadMilliVolts(BAT_ADC_PIN);
        int mv = (int)((acc * 2 + 4) / 8);
        s_batt_mv = s_batt_mv ? (s_batt_mv * 3 + mv) / 4 : mv;
        s_batt_t = ::millis();
    }
    return s_batt_mv;
}
int battery_percent() {
    int mv = battery_mv();
    if (mv < 2500) return -1;                     /* no battery connected */
    static const int tbl[][2] = {{4180, 100}, {4100, 92}, {4000, 80}, {3920, 70}, {3850, 60}, {3800, 50},
                                 {3750, 40}, {3710, 30}, {3670, 20}, {3620, 10}, {3500, 3}, {3300, 0}};
    if (mv >= tbl[0][0]) return 100;
    for (int i = 1; i < 12; i++)
        if (mv >= tbl[i][0])
            return tbl[i][1] + (mv - tbl[i][0]) * (tbl[i - 1][1] - tbl[i][1]) / (tbl[i - 1][0] - tbl[i][0]);
    return 0;
}
// No charge-status input exists in this HAL. A USB serial session is not a
// charging measurement; omit the bolt rather than reporting an inferred state.
bool charging() { return false; }

static bool wifi_is_on();
static bool background_busy();
static void audio_prepare_shutdown();

void idle_wait(uint32_t max_ms) {
    /* Light sleep stops the CPU and the APB clock: only safe when nothing runs in the background. Wi-Fi
       (modem sleep keeps the association), a worker job (HTTP, library scan), the amplifier's power-down
       ramp, a recording or a USB headphone stream would all be broken or stalled by it. */
    if (wifi_is_on() || background_busy()) { delay(max_ms > 50 ? 50 : max_ms); return; }
    esp_sleep_enable_timer_wakeup((uint64_t)max_ms * 1000);
    gpio_wakeup_enable((gpio_num_t)TP_PIN_INT, GPIO_INTR_LOW_LEVEL);
    esp_sleep_enable_gpio_wakeup();
    esp_light_sleep_start();
    gpio_wakeup_disable((gpio_num_t)TP_PIN_INT);
    /* disarm both: a still-armed timer would otherwise wake the next (deep) sleep */
    esp_sleep_disable_wakeup_source(ESP_SLEEP_WAKEUP_TIMER);
    esp_sleep_disable_wakeup_source(ESP_SLEEP_WAKEUP_GPIO);
}

void shutdown() {
    s_prefs.putLong64("t_saved", (int64_t)now());
    audio_prepare_shutdown();                   /* fades out and stops playback, keeps the amp off */
    lcd_backlight(0);
    lcd_sleep(true);
    wifi_enable(false);
    for (uint32_t t0 = ::millis(); wifi_radio_busy() && ::millis() - t0 < 9000;) {
        esp_task_wdt_reset(); delay(20);
    }
    delay(120);                                 /* the stop fade and the amplifier's power-down ramp */
    es8311_dac_volume(0x00);
    digitalWrite(AMP_PIN_EN, HIGH);
    /* let the finger lift, or the touch that chose "Shut Down" wakes us at once (INT is low while touched) */
    for (uint32_t t0 = ::millis(); digitalRead(TP_PIN_INT) == LOW && ::millis() - t0 < 3000;) delay(10);
    delay(100);
    /* hold the outputs through deep sleep: amplifier off, backlight off, touch controller out of reset
       (it has to keep scanning to raise INT for the wake-up) */
    ledcDetach(LCD_PIN_BL);
    pinMode(LCD_PIN_BL, OUTPUT);
    digitalWrite(LCD_PIN_BL, LOW);
    digitalWrite(TP_PIN_RST, HIGH);
    gpio_hold_en((gpio_num_t)AMP_PIN_EN);
    gpio_hold_en((gpio_num_t)LCD_PIN_BL);
    gpio_hold_en((gpio_num_t)TP_PIN_RST);
    gpio_deep_sleep_hold_en();
    /* only the touch may wake us: idle_wait()/light sleep may have left other sources armed */
    esp_sleep_disable_wakeup_source(ESP_SLEEP_WAKEUP_ALL);
    esp_sleep_enable_ext0_wakeup((gpio_num_t)TP_PIN_INT, 0);
    rtc_gpio_pullup_en((gpio_num_t)TP_PIN_INT);
    rtc_gpio_pulldown_dis((gpio_num_t)TP_PIN_INT);
    esp_deep_sleep_start();
}
void restart() { ESP.restart(); }

/* ================================================================ settings */
int32_t kv_get_int(const char* k, int32_t def) { return s_prefs.getInt(k, def); }
void kv_set_int(const char* k, int32_t v) { if (!s_prefs.isKey(k) || s_prefs.getInt(k, 0) != v) s_prefs.putInt(k, v); }
std::string kv_get_str(const char* k, const char* def) {
    if (!s_prefs.isKey(k)) return def;
    return std::string(s_prefs.getString(k, def).c_str());
}
void kv_set_str(const char* k, const std::string& v) { s_prefs.putString(k, v.c_str()); }
void kv_erase_all() { s_prefs.clear(); }

/* ================================================================ storage */
const char* fs_root() { return "/sdcard"; }
bool sd_present() { return s_sd; }
uint64_t sd_total_bytes() { return s_sd ? SD_MMC.totalBytes() : 0; }
uint64_t sd_used_bytes() { return s_sd ? SD_MMC.usedBytes() : 0; }

/* ================================================================ audio
 * Threads involved:
 *   UI (loop task)          posts commands (post()) and reads the published atomics below.
 *   "audio" task (core 0)   owns the Audio object, the output route, the amplifier and recording; it feeds
 *                           the decoder's input buffer (Audio::loop()) and runs the transport state machine.
 *   decoder task (core 0)   ESP32-audioI2S's own "PeriodicTask": decodes and calls audio_process_i2s()
 *                           with every output block while holding the library's mutexes.
 * The output DSP (s_dsp) belongs to the decoder task alone. The audio task changes it only through the
 * lock-free request words s_dsp_cfg_req / s_dsp_gain_req, which the hook applies at block boundaries. */
enum class ACmd { PlayFile, PlayUrl, Pause, Resume, Stop, Seek, Volume, Eq, RecStart, RecStop,
                  VoiceStart, VoiceStop };
struct AMsg { ACmd c; std::string s; int32_t v; int route; uint32_t gen; };
static std::mutex s_amtx;
static std::deque<AMsg> s_aq;
static TaskHandle_t s_audio_task = nullptr;
static Audio* s_audio = nullptr;
static TapSound s_tap;
static std::atomic<uint32_t> s_tap_request{0};
static std::atomic<bool> s_tap_active{false};
static std::atomic<int> s_tap_volume{60};
/* published state, written by the audio task */
static std::atomic<bool> a_run{false}, a_pause{false}, a_eof{false};
static std::atomic<uint32_t> a_pos{0}, a_dur{0};
/* The UI's view while commands are still queued: play/stop/pause set an intent immediately, so
   audio_is_running()/audio_is_paused() never flip back to a stale state before the audio task has caught up. */
static std::atomic<uint32_t> s_post_gen{0}, s_done_gen{0};
static std::atomic<bool> ui_run{false}, ui_pause{false};
static std::string a_title;
static std::string a_stream_status;
static std::mutex s_title_mtx;
static int a_volume = 60, a_eq = 0;                /* audio task only */
static std::atomic<bool> s_shutdown{false};

/* ---- output stage: DSP, route (speaker / USB-C headphones), amplifier power, fades */
static dsp::Output s_dsp;                          /* decoder task only (after init) */
static std::atomic<uint32_t> s_dsp_cfg_req{0};     /* bit0 USB route, bit1 44.1 kHz, bits 2.. generation */
static std::atomic<uint32_t> s_dsp_gain_req{0};    /* bits 0-1 start (0 keep, 1 zero, 2 full), 2-8 target/127,
                                                      9-17 fade ms, 18-31 generation */
static uint32_t s_dsp_cfg_gen = 0, s_dsp_gain_gen = 0;   /* producer side (audio task / init) */
static uint32_t h_cfg_seen = 0, h_gain_seen = 0;         /* consumer side (hook) */
static std::atomic<uint32_t> s_last_out_ms{0};     /* last time samples went to the output (hook -> audio task) */
static std::atomic<int> s_route{0};                /* 0 speaker, 1 USB headphones */
static std::atomic<bool> s_route_changed{false};
static std::string s_route_name;
static std::mutex s_route_mtx;
static uint32_t s_usb_gen = 0;                     /* audio task only from here down */
static std::atomic<bool> s_amp{false};             /* amplifier powered (read by idle_wait) */
static bool d_run = false, d_paused = false;       /* decoder state */
enum class After : uint8_t { None, Pause, Stop, Play };
static After s_after = After::None;                /* action pending at the end of a fade-out */
static AMsg s_after_msg;
static bool s_pause_after_play = false;   /* Pause posted while a new track was fading in */                           /* the Play command waiting for the fade-out */
static uint32_t s_fade_deadline = 0;               /* millis() when the fade-out has reached the DAC */
static int32_t s_seek_ms = -1;                     /* seek applied at the fade deadline */
static int32_t s_seek_paused_ms = -1;              /* seek requested while paused: applied on resume */

static void dsp_configure(bool usb, uint32_t fs) {
    s_dsp_cfg_gen++;
    s_dsp_cfg_req.store((s_dsp_cfg_gen << 2) | (fs == 44100 ? 2u : 0u) | (usb ? 1u : 0u), std::memory_order_release);
}
/* start: -1 keep the current level, else jump to 0 / 1 first; then fade to target over ms */
static void dsp_gain(int start, float target, int ms) {
    if (target < 0) target = 0;
    if (target > 1) target = 1;
    if (ms < 0) ms = 0;
    if (ms > 511) ms = 511;
    s_dsp_gain_gen = s_dsp_gain_gen % 16383 + 1;
    uint32_t st = start < 0 ? 0 : (start == 0 ? 1 : 2);
    uint32_t w = st | ((uint32_t)(target * 127 + 0.5f) << 2) | ((uint32_t)ms << 9) | (s_dsp_gain_gen << 18);
    s_dsp_gain_req.store(w, std::memory_order_release);
}
static void dsp_apply_requests() {
    uint32_t c = s_dsp_cfg_req.load(std::memory_order_acquire);
    if (c != h_cfg_seen) {
        h_cfg_seen = c;
        s_dsp.configure(c & 1 ? dsp::Route::Headphones : dsp::Route::Speaker, c & 2 ? 44100.0f : 48000.0f);
    }
    uint32_t g = s_dsp_gain_req.load(std::memory_order_acquire);
    if (g != h_gain_seen) {
        h_gain_seen = g;
        uint32_t st = g & 3;
        if (st) s_dsp.set_gain_now(st == 1 ? 0.0f : 1.0f);
        s_dsp.fade_to(((g >> 2) & 0x7F) / 127.0f, (float)((g >> 9) & 0x1FF));
    }
}

static void amp_power(bool on) {
    if (on == s_amp) return;
    if (on) {
        digitalWrite(AMP_PIN_EN, LOW);
        vTaskDelay(pdMS_TO_TICKS(30));             /* SC8002B bypass settles; DAC is still at -95 dB */
        es8311_dac_volume(ES8311_DAC_0DB);         /* soft-ramped up by the codec */
    } else {
        es8311_dac_volume(0x00);                   /* soft-ramped down (~60 ms) ... */
        vTaskDelay(pdMS_TO_TICKS(80));
        digitalWrite(AMP_PIN_EN, HIGH);            /* ... then the amp sleeps: silent, no hiss */
    }
    s_amp = on;
}

/* Called on the decoder task with the final stereo block (after volume and tone), while the library holds
   its decoding mutexes: it must never block for long (Audio::stopSong()/pauseResume() wait on them). */
void audio_process_i2s_hook(int32_t* buf, int16_t frames, bool* cont) {
    dsp_apply_requests();
    s_dsp.process(buf, frames);
    s_tap.mix(buf,frames,(s_dsp_cfg_req.load() & 2)?44100:48000);
    s_tap_active=s_tap.active();
    s_last_out_ms.store(::millis(), std::memory_order_relaxed);
    if (s_dsp.route() == dsp::Route::Headphones) {
        if (usbaudio::connected()) {
            *cont = false;                         /* not to the DAC */
            /* A full device buffer paces the decoder, so a block legitimately takes frames/rate to
               queue (a FLAC block is ~96 ms); allow that plus 20 ms of slack. A stalled device costs
               that much once and then the block is dropped, well inside the library's mutex timeouts. */
            uint32_t rate = usbaudio::sample_rate();
            int budget = (int)((uint32_t)frames * 1000 / (rate ? rate : 48000)) + 20;
            usbaudio::write(buf, frames, budget);
        } else {
            /* headphones just went away (the route switch follows within a millisecond): let I2S pace
               the decoder, silently (amp off, DAC muted) */
            memset(buf, 0, (size_t)frames * 2 * sizeof(int32_t));
        }
    }
}

static void publish_state() {
    a_run = (d_run && s_after != After::Stop) || s_after == After::Play;
    a_pause = d_run && s_after != After::Play && (d_paused || s_after == After::Pause);
}

static void set_route(bool usb) {
    /* each route remembers its own volume (headphones start quieter); applied first, before any sample
       can reach the new output, so a speaker-level volume never hits someone's ears */
    a_volume = kv_get_int(usb ? "vol_hp" : "vol", usb ? 40 : 60);
    s_tap_volume=std::clamp(a_volume,0,100);
    if (!usb && d_run && !d_paused && s_audio) {
        /* headphones pulled out while playing: pause at once, like every iPod (nothing may reach the
           speaker); pauseResume() returns only once no block is in flight */
        s_audio->pauseResume();
        d_paused = true;
        if (s_after == After::Pause || s_after == After::None) { s_after = After::None; s_fade_deadline = 0; }
        if (s_seek_ms >= 0) { s_seek_paused_ms = s_seek_ms; s_seek_ms = -1; }
    }
    if (s_audio) s_audio->setVolume(a_volume, 1);
    if (usb) {
        amp_power(false);
        dsp_configure(true, usbaudio::sample_rate());
        if (s_audio) s_audio->setOutputSampleRate(usbaudio::sample_rate() == 44100 ? Audio::SR_44100 : Audio::SR_48000);
    } else {
        dsp_configure(false, 48000);
        if (s_audio) s_audio->setOutputSampleRate(Audio::SR_48000);
    }
    {
        std::lock_guard<std::mutex> l(s_route_mtx);
        s_route_name = usb ? usbaudio::product() : std::string("Speaker");
    }
    s_route = usb ? 1 : 0;
    s_route_changed = true;
    publish_state();
}

/* recording state */
static std::atomic<bool> r_active{false};
static std::atomic<uint32_t> r_ms{0};
static std::atomic<int> r_level{0};
static i2s_chan_handle_t r_rx = nullptr;
static memo_wav::Writer r_writer;
static uint32_t r_last_data=0, r_checkpoint_ms=0;
static std::atomic<RecState> r_state{RecState::Idle};
static std::mutex r_error_mutex;
static std::string r_error;
static void recording_error(const std::string& error) {
    { std::lock_guard<std::mutex> lock(r_error_mutex);r_error=error; }
    Serial.printf("[memo] %s\n",error.c_str());r_state=RecState::Failed;
}
static const uint32_t REC_RATE = 16000;

/* call state: the UI's intent, so voice_active() is true from voice_start() until the call is
   really gone (including a teardown the audio task did by itself on a dead link) */
static std::atomic<bool> v_on{false};

static void post(ACmd c, const std::string& s = "", int32_t v = 0) {
    AMsg m;
    m.c = c;
    m.s = s;
    m.v = v;
    m.route = s_route;
    {
        std::lock_guard<std::mutex> l(s_amtx);
        uint32_t gen = s_post_gen.load() + 1;
        m.gen = gen;
        s_aq.push_back(std::move(m));
        s_post_gen = gen;
    }
    if (s_audio_task) xTaskNotifyGive(s_audio_task);
}

static void audio_cb(Audio::msg_t m) {
    if (m.e == Audio::evt_eof) a_eof = true;
    if (m.e == Audio::evt_streamtitle && m.msg) {
        std::lock_guard<std::mutex> l(s_title_mtx);
        a_title = m.msg;
        a_stream_status = "Playing";
    }
    if (m.e == Audio::evt_name || m.e == Audio::evt_lasthost || m.e == Audio::evt_bitrate) {
        std::lock_guard<std::mutex> l(s_title_mtx);
        a_stream_status = "Connected";
    }
    if ((m.e == Audio::evt_info || m.e == Audio::evt_log) && m.msg) {
        std::string msg = m.msg;
        std::string low = msg;
        for (char& ch : low) ch = (char)tolower((unsigned char)ch);
        const bool useful = low.find("error") != std::string::npos || low.find("fail") != std::string::npos ||
                            low.find("ssl") != std::string::npos || low.find("tls") != std::string::npos ||
                            low.find("connect") != std::string::npos || low.find("timeout") != std::string::npos ||
                            low.find("slow stream") != std::string::npos || low.find("http") != std::string::npos;
        if (useful) {
            if (msg.size() > 120) msg.resize(120);
            std::lock_guard<std::mutex> l(s_title_mtx);
            a_stream_status = msg;
        }
        Serial.printf("[audio] %s\n", m.msg);
    }
}

static void apply_eq(int p) {
    static const float g[][3] = {{0, 0, 0}, {6, 0, -1}, {-6, 0, 0}, {0, 0, 6}, {0, 0, -6}, {-2, 4, -1}, {5, -1, 4},
                                 {4, -1, 3}, {-1, 3, 1}, {3, -1, 2}, {3, 0, 3}, {-3, 4, 0}, {2, 1, 2}, {4, 2, -2}};
    if (p < 0 || p >= (int)(sizeof g / sizeof g[0])) p = 0;
    if (s_audio) s_audio->setTone(g[p][0], g[p][1], g[p][2]);
}

static void create_player() {
    s_audio = new Audio(I2S_NUM_0);
    Audio::audio_info_callback = audio_cb;
    s_audio->setPinout(I2S_PIN_BCLK, I2S_PIN_WS, I2S_PIN_DOUT, I2S_PIN_MCLK);   /* starts the decoder task */
    s_audio->setOutputSampleRate(s_route == 1 && usbaudio::sample_rate() == 44100 ? Audio::SR_44100 : Audio::SR_48000);
    s_audio->setVolumeSteps(100);
    s_audio->setVolume(a_volume, 1);
    s_audio->setConnectionTimeout(8000, 12000);
    apply_eq(a_eq);
    /* The library starts its decoder task at priority 2, below this feeder task (5), the USB host and
       the network worker. Decoding + output DSP + USB conversion is the real-time path: run it above the
       feeder (it sleeps a tick every cycle and blocks on I2S / USB, so nothing below starves). */
    if (TaskHandle_t t = xTaskGetHandle("PeriodicTask")) vTaskPrioritySet(t, 6);
}

static void transport_reset() {
    s_after = After::None;
    s_fade_deadline = 0;
    s_seek_ms = s_seek_paused_ms = -1;
}

static void rec_end(std::string failure = "");
static bool rec_begin(const std::string& path) {
    // Stop may have been tapped while this command was still queued.
    if(r_state!=RecState::Starting){if(r_state==RecState::Saving)r_state=RecState::Idle;return false;}
    if(voice::active() || v_on){recording_error("End the call before recording.");return false;}
    amp_power(false);transport_reset();
    if(s_audio){s_audio->stopSong();delete s_audio;s_audio=nullptr;}
    s_tap_request=0;s_tap.request(0,0);s_tap_active=false;
    d_run=false;d_paused=false;publish_state();
    bool opened=false,enabled=false;
    auto fail=[&](const std::string& error) {
        if(r_rx){if(enabled)i2s_channel_disable(r_rx);i2s_del_channel(r_rx);r_rx=nullptr;}
        if(opened)r_writer.finish(false);
        r_active=false;r_level=0;recording_error(error);return false;
    };
    if(!es8311_prepare_recording())return fail("Microphone codec did not respond. Restart and check the microphone/I2C connection.");
    if(!r_writer.begin(path))return fail(r_writer.error());
    opened=true;
    i2s_chan_config_t cc=I2S_CHANNEL_DEFAULT_CONFIG(I2S_NUM_0,I2S_ROLE_MASTER);
    cc.dma_desc_num=8;cc.dma_frame_num=256; // 128 ms capture headroom, 16 KiB DMA.
    esp_err_t err=i2s_new_channel(&cc,nullptr,&r_rx);
    if(err!=ESP_OK){r_rx=nullptr;return fail(std::string("Microphone I2S allocation failed: ")+esp_err_to_name(err));}
    i2s_std_config_t sc={};sc.clk_cfg=I2S_STD_CLK_DEFAULT_CONFIG(REC_RATE);
    sc.clk_cfg.mclk_multiple=I2S_MCLK_MULTIPLE_256;
    sc.slot_cfg=I2S_STD_PHILIPS_SLOT_DEFAULT_CONFIG(I2S_DATA_BIT_WIDTH_32BIT,I2S_SLOT_MODE_STEREO);
    sc.gpio_cfg.mclk=(gpio_num_t)I2S_PIN_MCLK;sc.gpio_cfg.bclk=(gpio_num_t)I2S_PIN_BCLK;
    sc.gpio_cfg.ws=(gpio_num_t)I2S_PIN_WS;sc.gpio_cfg.dout=I2S_GPIO_UNUSED;sc.gpio_cfg.din=(gpio_num_t)I2S_PIN_DIN;
    err=i2s_channel_init_std_mode(r_rx,&sc);
    if(err!=ESP_OK)return fail(std::string("Microphone I2S configuration failed: ")+esp_err_to_name(err));
    err=i2s_channel_enable(r_rx);
    if(err!=ESP_OK)return fail(std::string("Microphone I2S start failed: ")+esp_err_to_name(err));
    enabled=true;r_last_data=::millis();r_checkpoint_ms=0;r_ms=0;r_level=0;r_active=true;
    Serial.printf("[memo] capture enabled: %lu Hz, LEFT 32-bit slot, %s\n",(unsigned long)REC_RATE,path.c_str());
    return true; // UI remains Starting until actual PCM is received and written.
}
static void rec_service() {
    static int32_t input[512];static int16_t pcm[256];size_t got=0;
    esp_err_t err=i2s_channel_read(r_rx,input,sizeof input,&got,20);
    if(err!=ESP_OK && err!=ESP_ERR_TIMEOUT){rec_end(std::string("Microphone read failed: ")+esp_err_to_name(err));return;}
    if(!got){if(uint32_t(::millis()-r_last_data)>2000)rec_end("Microphone delivered no audio samples (I2S timeout).");else vTaskDelay(1);return;}
    if(got%8){rec_end("Microphone returned an incomplete I2S frame.");return;}
    r_last_data=::millis();size_t frames=got/8;
    r_level=memo_wav::convert_left(input,pcm,frames);
    if(!r_writer.append(pcm,frames)){rec_end(r_writer.error());return;}
    r_ms=r_writer.milliseconds();
    if(r_state==RecState::Starting)r_state=RecState::Recording;
    if(r_ms-r_checkpoint_ms>=1000){
        if(!r_writer.checkpoint()){rec_end(r_writer.error());return;}
        r_checkpoint_ms=r_ms;
    }
}
static void rec_end(std::string failure) {
    if(!r_active){if(r_state==RecState::Saving)r_state=RecState::Idle;return;}
    r_state=RecState::Saving;r_active=false;
    if(r_rx){i2s_channel_disable(r_rx);i2s_del_channel(r_rx);r_rx=nullptr;}
    bool saved=r_writer.finish(failure.empty());r_ms=r_writer.milliseconds();r_level=0;
    std::string error=failure.empty()?r_writer.error():failure;
    // Publish the storage result without recreating the decoder/I2S driver.
    // do_play() recreates it when playback is requested. Saving a WAV must
    // not depend on unrelated playback initialization succeeding.
    if(saved){r_state=RecState::Saved;Serial.printf("[memo] saved %lu bytes / %lu ms\n",(unsigned long)r_writer.bytes(),(unsigned long)r_ms.load());}
    else recording_error(error.empty()?"Recording could not be saved.":error);
}

/* ---- two-way voice (nanoLink §5)
 * A call needs I2S_NUM_0 in both directions, so the decoder has to go first — the same trade the
 * voice-memo recorder makes, and undone the same way. What was playing is restored by the UI
 * (player::push_state() / pop_state()) once the decoder is back. */
static void voice_begin_now() {
    if (voice::active()) return;
    if (r_active) rec_end();                       /* a recording and a call cannot share the codec */
    transport_reset();
    amp_power(false);                              /* ramp the DAC down while the old clock still runs */
    if (s_audio) { s_audio->stopSong(); delete s_audio; s_audio = nullptr; }   /* frees I2S_NUM_0 */
    s_tap_request=0;s_tap.request(0,0);s_tap_active=false;
    d_run = false; d_paused = false;
    a_pos = 0; a_dur = 0;
    publish_state();
    if (!voice::begin()) { v_on = false; create_player(); return; }
    amp_power(true);                               /* speakerphone: the amplifier stays on for the call */
}

static void voice_end_now() {
    if (!voice::active()) { v_on = false; if (!s_audio) create_player(); return; }
    amp_power(false);                              /* the codec still has its clock: the ramp is heard */
    voice::end();
    v_on = false;
    create_player();
    publish_state();
}

/* ---- transport */
static void do_play(const AMsg& m) {
    if (r_active) rec_end();
    transport_reset();
    a_eof = false;
    if (!s_audio) create_player();
    dsp_gain(0, 1, 15);                            /* new track: starts silent, 15 ms fade-in, no click */
    bool ok;
    if (m.c == ACmd::PlayFile) {
        std::string p = m.s;
        if (p.rfind("/sdcard", 0) == 0) p = p.substr(7);
        ok = s_audio->connecttoFS(SD_MMC, p.c_str(), m.v > 0 ? m.v / 1000 : -1);
    } else {
        { std::lock_guard<std::mutex> l(s_title_mtx); a_title.clear(); a_stream_status = "Connecting"; }
        /* HTTPS radio streams can be opened immediately after Wi-Fi connects, before SNTP has
         * supplied a certificate-valid wall clock.  poll() starts SNTP on the UI task; give that
         * first sync a short window here rather than reporting a dead station on first tap. */
        if (m.s.rfind("https://", 0) == 0 && time(nullptr) <= 1700000000) {
            uint32_t t0 = ::millis();
            while (WiFi.status() == WL_CONNECTED && time(nullptr) <= 1700000000 && ::millis() - t0 < 9000u) delay(50);
        }
        /* The initial radio HTTP/TLS handshake shares the same scarce internal networking
         * structures as Weather/News/Web. Serialize only connecttohost(); streaming continues
         * normally after it returns and does not hold the transport lock. */
        {
            std::unique_lock<std::mutex> net_lock(s_http_transport_mutex, std::defer_lock);
            ok = request_budget::acquire(net_lock, [] { return ::millis(); }, [](uint32_t ms) { delay(ms); }, 1500);
            if (ok) ok = s_audio->connecttohost(m.s.c_str());
        }
        {
            std::lock_guard<std::mutex> l(s_title_mtx);
            if (!ok) a_stream_status = "Connection failed";
            else if (a_stream_status.empty() || a_stream_status == "Connecting") a_stream_status = "Connected";
        }
    }
    d_run = ok; d_paused = false;
    a_pos = ok && m.c == ACmd::PlayFile ? (uint32_t)m.v : 0;
    a_dur = 0;
}

static void do_stop_now() {
    transport_reset();
    if (s_audio) s_audio->stopSong();
    d_run = false; d_paused = false;
    dsp_gain(1, 1, 0);
}

static void fade_then(After a, int ms) {
    dsp_gain(-1, 0, ms);
    s_after = a;
    s_fade_deadline = ::millis() + ms + 15;        /* + the block already on its way to the DAC */
    if (!s_fade_deadline) s_fade_deadline = 1;
}

static void handle(const AMsg& m) {
    if (voice::active()) {
        /* a call owns the codec: everything that would touch the decoder or the recorder is dropped */
        switch (m.c) {
        case ACmd::VoiceStart: case ACmd::VoiceStop: case ACmd::Volume: case ACmd::Eq: break;
        default: if(m.c==ACmd::RecStart)recording_error("End the call before recording."); return;
        }
    }
    const bool audible = d_run && !d_paused;
    switch (m.c) {
    case ACmd::PlayFile:
    case ACmd::PlayUrl:
        if (audible && s_audio) {                  /* fade the current track out first */
            s_after_msg = m;
            s_seek_ms = -1;
            if (s_after == After::None) fade_then(After::Play, 15);
            else s_after = After::Play;            /* already fading out (pause / stop / seek) */
        } else do_play(m);
        break;
    case ACmd::Pause:                              /* 60 ms fade, then pause: no click */
        if (audible && s_after == After::None) fade_then(After::Pause, 60);   /* a pending seek still happens first */
        else if (s_after == After::Play) s_pause_after_play = true;           /* pause the track that is starting */
        break;
    case ACmd::Resume:
        s_pause_after_play = false;
        if (s_after == After::Pause) {             /* still fading out: fade back in */
            s_after = After::None;
            if (s_seek_ms < 0) { s_fade_deadline = 0; dsp_gain(-1, 1, 40); }
        } else if (d_run && d_paused && s_audio) {
            dsp_gain(0, 1, 40);
            s_audio->pauseResume();
            d_paused = false;
            if (s_seek_paused_ms >= 0) { s_audio->setAudioPlayTime((uint16_t)(s_seek_paused_ms / 1000)); s_seek_paused_ms = -1; }
        }
        break;
    case ACmd::Stop:
        if (audible && s_audio) {
            if (s_after == After::None) fade_then(After::Stop, 40);
            else s_after = After::Stop;
            s_seek_ms = -1;
        } else do_stop_now();
        break;
    case ACmd::Seek:                               /* ~30 ms fade-out, seek, fade back in: no click */
        if (!d_run || !s_audio) break;
        if (d_paused) { s_seek_paused_ms = m.v; break; }
        if (s_after == After::Stop || s_after == After::Play) break;
        s_seek_ms = m.v;
        if (!s_fade_deadline) fade_then(After::None, 30);
        break;
    case ACmd::Volume:
        if (m.route != s_route) break;             /* meant for the output that was just unplugged */
        a_volume = m.v;
        if (s_audio) s_audio->setVolume(m.v, 1);
        break;
    case ACmd::Eq: a_eq = m.v; apply_eq(m.v); break;
    case ACmd::RecStart: if (!r_active) rec_begin(m.s); break;
    case ACmd::RecStop: rec_end(); break;
    case ACmd::VoiceStart: voice_begin_now(); break;
    case ACmd::VoiceStop: voice_end_now(); break;
    }
}

static void transport_service() {
    if (!s_fade_deadline || (int32_t)(::millis() - s_fade_deadline) < 0) return;
    s_fade_deadline = 0;
    After a = s_after;
    s_after = After::None;
    if (a == After::Play) {
        AMsg m = std::move(s_after_msg);
        do_play(m);
        if (s_pause_after_play) {                  /* a pause arrived while the old track faded out */
            s_pause_after_play = false;
            if (d_run && s_audio && !d_paused) { s_audio->pauseResume(); d_paused = true; }
        }
        return;
    }
    if (a == After::Stop) { do_stop_now(); return; }
    if (!s_audio || !d_run) { transport_reset(); return; }
    if (s_seek_ms >= 0) { s_audio->setAudioPlayTime((uint16_t)(s_seek_ms / 1000)); s_seek_ms = -1; }
    if (a == After::Pause) {
        /* the track may have ended during the fade: then there is nothing to pause */
        if (!d_paused && s_audio->isRunning()) { s_audio->pauseResume(); d_paused = true; }
        else if (!s_audio->isRunning()) { d_run = false; d_paused = false; transport_reset(); }
    }
    else dsp_gain(0, 1, 20);                       /* seek done: fade back in */
}

int16_t audio_idle_samples(int32_t*,int16_t frames){return s_tap.active()?frames:0;}

static void output_service() {
    uint32_t g = usbaudio::generation();
    if (g != s_usb_gen) { s_usb_gen = g; set_route(usbaudio::connected()); }
    transport_service();
    uint32_t now = ::millis();
    bool want = !s_shutdown && s_route == 0 &&
                (s_tap_active || (d_run && !d_paused) || now - s_last_out_ms.load(std::memory_order_relaxed) < 2500);
    amp_power(want);
}

static void audio_task(void*) {
    create_player();
    for (;;) {
        for (;;) {
            AMsg m;
            {
                std::lock_guard<std::mutex> l(s_amtx);
                if (s_aq.empty()) break;
                m = std::move(s_aq.front());
                s_aq.pop_front();
            }
            handle(m);
            publish_state();
            s_done_gen = m.gen;
        }
        if (voice::active()) {
            /* the voice task owns the codec and the socket; nothing to do here but watch for a call
               that died without the UI noticing */
            if (voice::want_teardown()) voice_end_now();
            else ulTaskNotifyTake(pdTRUE, pdMS_TO_TICKS(50));
            continue;
        }
        if (r_active) { rec_service(); continue; }
        auto tap=s_tap_request.exchange(0);
        if(tap && !s_shutdown && !s_audio)create_player();
        if(tap && !s_shutdown && s_audio){
            if(s_route==0)amp_power(true);
            s_tap.request((tap>>1)&7,(tap>>8)&127);s_tap_active=true;
        }
        output_service();
        if (s_audio) {
            s_audio->loop();
            if (d_run && !d_paused && !s_audio->isRunning() && s_after == After::None) { d_run = false; transport_reset(); }
            publish_state();
            if (d_run && s_seek_ms < 0 && s_seek_paused_ms < 0 && s_after == After::None &&
                s_done_gen.load() == s_post_gen.load()) {
                a_pos = s_audio->getAudioCurrentTime() * 1000;
                a_dur = s_audio->getAudioFileDuration() * 1000;
            }
        }
        /* playing: feed the decoder every tick. Idle: sleep until a command arrives (or 20 ms, for the
           USB route / amplifier housekeeping) instead of waking 1000 times a second. */
        bool busy = (d_run && !d_paused) || s_fade_deadline || s_amp;
        ulTaskNotifyTake(pdTRUE, busy ? 1 : pdMS_TO_TICKS(20));
    }
}

static void audio_prepare_shutdown() {
    s_shutdown = true;
    if(rec_busy())rec_stop();
    if (v_on.load() || voice::active()) { v_on = false; post(ACmd::VoiceStop); }
    post(ACmd::Stop);
}

/* ---- UI side */
static bool ui_pending() { return s_done_gen.load() != s_post_gen.load(); }
bool audio_is_running() { return ui_pending() ? ui_run.load() : a_run.load(); }
bool audio_is_paused() { return ui_pending() ? ui_pause.load() : a_pause.load(); }
static void ui_intent(bool run, bool pause) { ui_run = run; ui_pause = pause; }

bool audio_play_file(const char* p, uint32_t start_ms) {
    ui_intent(true, false);
    a_pos = start_ms; a_dur = 0;
    post(ACmd::PlayFile, p, (int32_t)start_ms);
    return true;
}
bool audio_play_url(const char* u) {
    ui_intent(true, false);
    a_pos = 0; a_dur = 0;
    post(ACmd::PlayUrl, u);
    return true;
}
void audio_pause(bool p) {
    bool run = audio_is_running();
    ui_intent(run, run && p);
    post(p ? ACmd::Pause : ACmd::Resume);
}
void audio_stop() { ui_intent(false, false); post(ACmd::Stop); }
uint32_t audio_pos_ms() { return a_pos; }
uint32_t audio_dur_ms() { return a_dur; }
void audio_seek(uint32_t ms) {
    ui_intent(audio_is_running(), audio_is_paused());
    a_pos = ms;
    post(ACmd::Seek, "", (int32_t)ms);
}
void audio_set_volume(int pct) { s_tap_volume=std::clamp(pct,0,100);if(pct<=0){s_tap_request=0;s_tap.request(0,0);} ui_intent(audio_is_running(), audio_is_paused()); post(ACmd::Volume, "", pct); }
void audio_set_eq(int p) { ui_intent(audio_is_running(), audio_is_paused()); post(ACmd::Eq, "", p); }
bool audio_take_eof() { bool e = a_eof.exchange(false); return e; }
std::string audio_stream_title() { std::lock_guard<std::mutex> l(s_title_mtx); return a_title; }
std::string audio_stream_status() { std::lock_guard<std::mutex> l(s_title_mtx); return a_stream_status; }
void ui_sound(int kind) {
    if(!s_audio_task || s_shutdown || v_on || voice::active() || rec_busy() || !kv_get_int("tap_sounds",1))return;
    int volume=std::min<int>(s_tap_volume,kv_get_int("vol_limit",100));if(volume<=0)return;
    s_tap_request=1u|(unsigned(std::clamp(kind,0,7))<<1)|(unsigned(volume)<<8);xTaskNotifyGive(s_audio_task);
}
int audio_route() { return s_route; }
std::string audio_route_name() { std::lock_guard<std::mutex> l(s_route_mtx); return s_route_name.empty() ? "Speaker" : s_route_name; }
bool audio_take_route_change() { return s_route_changed.exchange(false); }

RecState rec_state(){return r_state.load();}
std::string rec_error(){std::lock_guard<std::mutex> lock(r_error_mutex);return r_error;}
bool rec_busy(){auto state=rec_state();return state==RecState::Starting || state==RecState::Recording || state==RecState::Saving;}
bool rec_start(const char* path) {
    if(rec_busy())return false;
    {std::lock_guard<std::mutex> lock(r_error_mutex);r_error.clear();}
    if(!s_audio_task || s_shutdown){recording_error("Audio service is unavailable.");return false;}
    if(v_on || voice::active()){recording_error("End the call before recording.");return false;}
    if(!sd_present() || !path || !*path){recording_error("Insert a writable microSD card.");return false;}
    r_ms=0;r_level=0;r_state=RecState::Starting;
    ui_intent(false,false);post(ACmd::RecStart,path);return true;
}
void rec_stop(){
    auto state=r_state.load();
    while(state==RecState::Starting || state==RecState::Recording){
        if(r_state.compare_exchange_weak(state,RecState::Saving)){post(ACmd::RecStop);return;}
    }
}
bool rec_active(){return r_state==RecState::Recording;}
uint32_t rec_ms(){return r_ms;}
int rec_level(){return r_level;}

/* ---- two-way voice.  voice_start() only hands the call to the audio task: the TCP connection and the
   HELLO handshake happen on the voice task, and voice_stats().connected reports the result. */
bool voice_start(const std::string& host, int port, const std::string& user, const std::string& token,
                 const std::string& call_id) {
    if (host.empty() || call_id.empty() || port <= 0) return false;
    if (v_on.load() || voice::active()) return false;
    voice::configure(host, port, user, token, call_id);
    voice::set_mute(false);
    v_on = true;
    ui_intent(false, false);                       /* a call replaces playback, like a recording does */
    post(ACmd::VoiceStart);
    return true;
}
void voice_stop() {
    if (!v_on.load() && !voice::active()) return;
    v_on = false;
    ui_intent(false, false);
    post(ACmd::VoiceStop);
}
bool voice_active() { return v_on.load() || voice::active(); }
VoiceStats voice_stats() {
    voice::Stats v = voice::stats();
    VoiceStats s;
    s.rx_frames = v.rx_frames;
    s.tx_frames = v.tx_frames;
    s.lost = v.lost;
    s.jitter_ms = v.jitter_ms;
    s.level_in = v.level_in;
    s.level_out = v.level_out;
    s.connected = v.connected;
    return s;
}
void voice_set_mute(bool m) { voice::set_mute(m); }
bool voice_muted() { return voice::muted(); }

/* Radio ownership is in wifi_manager.cpp. */
static bool wifi_is_on() { return wifi_radio_busy(); }
static std::atomic<bool> s_sntp_started{false};
static void on_sntp_sync(struct timeval*) { s_time_ok = true; }
static void ensure_sntp_started() {
    if (WiFi.status() != WL_CONNECTED) return;
    bool expected = false;
    if (!s_sntp_started.compare_exchange_strong(expected, true)) return;
    sntp_set_time_sync_notification_cb(on_sntp_sync);
    const char* tz = getenv("TZ");
    const std::string zone = tz ? tz : "CST6";
    configTzTime(zone.c_str(), "time.cloudflare.com", "time.google.com", "pool.ntp.org");
    Serial.println("[time] SNTP started");
}

/* ================================================================ async + HTTP
 * One worker task runs jobs in order.  v1.0.2 used a counting semaphore whose
 * maximum count was 0x7fffffff.  On the ESP32-S3 that could fail allocation and
 * later xSemaphoreGive(NULL), producing the observed xQueueGenericSend(pxQueue)
 * boot assertion.  Direct-to-task notifications are allocation-free after the
 * worker task exists and are exactly the wake-up primitive this single consumer
 * needs. */
struct Job { std::function<void()> fn, done; };
static std::mutex s_job_mtx;
static std::deque<Job> s_jobq;
static TaskHandle_t s_worker_task = nullptr;
static StaticTask_t s_worker_storage;
static StackType_t s_worker_stack[12288 / sizeof(StackType_t)];
static std::atomic<int> s_jobs_busy{0};            /* queued + running */
static std::mutex s_done_mtx;
static std::deque<std::function<void()>> s_done;

static void worker_task(void*) {
    for (;;) {
        ulTaskNotifyTake(pdTRUE, portMAX_DELAY);
        for (;;) {
            Job j;
            {
                std::lock_guard<std::mutex> l(s_job_mtx);
                if (s_jobq.empty()) break;
                j = std::move(s_jobq.front());
                s_jobq.pop_front();
            }
            if (j.fn) j.fn();
            if (j.done) { std::lock_guard<std::mutex> l(s_done_mtx); s_done.push_back(std::move(j.done)); }
            s_jobs_busy--;
        }
    }
}

static void jobs_init() {
    if (s_worker_task) return;
    s_worker_task = xTaskCreateStaticPinnedToCore(worker_task, "net", sizeof(s_worker_stack),
                                                nullptr, 2, s_worker_stack, &s_worker_storage, 0);
    if (s_worker_task) {
        Serial.println("[boot] async worker ready");
    } else {
        Serial.println("[boot] async worker unavailable; background requests will fail safely");
    }
}

void run_async(std::function<void()> fn, std::function<void()> done) {
    if (!s_worker_task) jobs_init();
    if (!s_worker_task) {
        // Never execute HTTP or SD jobs on LVGL's thread. Complete as failure.
        if (done) { std::lock_guard<std::mutex> l(s_done_mtx); s_done.push_back(std::move(done)); }
        return;
    }
    s_jobs_busy++;
    {
        std::lock_guard<std::mutex> l(s_job_mtx);
        s_jobq.push_back(Job{std::move(fn), std::move(done)});
    }
    xTaskNotifyGive(s_worker_task);
}

static bool background_busy() {
    if (s_jobs_busy.load() > 0 || s_amp || rec_busy() || voice::active() || usbaudio::connected()) return true;
    std::lock_guard<std::mutex> l(s_done_mtx);
    return !s_done.empty();                         /* results waiting for the UI */
}

/* HTTP transport used by Weather, Stocks, Maps, Newsstand and Web.
 *
 * v1.1.6 deliberately follows redirects itself. Arduino-ESP32 HTTPClient::setURL()
 * refuses redirects that change protocol (http <-> https), so relying on the built-in
 * redirect engine made perfectly valid public endpoints appear offline. Recreating the
 * client for every hop also guarantees the correct TLS/plain transport is used.
 *
 * Network failures are recorded in a single human-readable diagnostic string and printed
 * with DNS, HTTP status and heap information. This makes "Can't connect" actionable on the
 * physical FNK0104B instead of hiding the actual layer that failed. */
static std::mutex s_neterr_mtx;
static std::string s_neterr;
static void net_error(const std::string& e) {
    std::lock_guard<std::mutex> l(s_neterr_mtx);
    s_neterr = e;
    if (!e.empty()) Serial.printf("[net] %s\n", e.c_str());
}
std::string net_last_error() {
    std::lock_guard<std::mutex> l(s_neterr_mtx);
    return s_neterr;
}
static void net_clear_error() { std::lock_guard<std::mutex> l(s_neterr_mtx); s_neterr.clear(); }

struct HttpUrl {
    bool https = false;
    std::string scheme, host, authority, path;
    uint16_t port = 0;
};
static bool parse_http_url(const std::string& url, HttpUrl& u) {
    const size_t sep = url.find("://");
    if (sep == std::string::npos) return false;
    u.scheme = url.substr(0, sep);
    if (u.scheme != "http" && u.scheme != "https") return false;
    u.https = u.scheme == "https";
    u.port = u.https ? 443 : 80;
    const size_t auth0 = sep + 3;
    size_t slash = url.find_first_of("/?#", auth0);
    if (slash == std::string::npos) slash = url.size();
    u.authority = url.substr(auth0, slash - auth0);
    if (u.authority.empty()) return false;
    std::string hp = u.authority;
    if (!hp.empty() && hp.front() == '[') {                // bracketed IPv6 literal
        const size_t close = hp.find(']');
        if (close == std::string::npos) return false;
        u.host = hp.substr(1, close - 1);
        if (close + 1 < hp.size() && hp[close + 1] == ':') {
            int p = atoi(hp.c_str() + close + 2); if (p <= 0 || p > 65535) return false; u.port = (uint16_t)p;
        }
    } else {
        const size_t colon = hp.rfind(':');
        if (colon != std::string::npos && hp.find(':') == colon) {
            int p = atoi(hp.c_str() + colon + 1);
            if (p > 0 && p <= 65535) { u.host = hp.substr(0, colon); u.port = (uint16_t)p; }
            else u.host = hp;
        } else u.host = hp;
    }
    if (u.host.empty()) return false;
    u.path = slash < url.size() ? url.substr(slash) : "/";
    if (u.path.empty()) u.path = "/";
    return true;
}
static std::string redirect_url(const std::string& base, const std::string& location) {
    if (location.rfind("http://", 0) == 0 || location.rfind("https://", 0) == 0) return location;
    HttpUrl b; if (!parse_http_url(base, b)) return "";
    if (location.rfind("//", 0) == 0) return b.scheme + ":" + location;
    const std::string origin = b.scheme + "://" + b.authority;
    std::string base_path = b.path;
    size_t frag = base_path.find('#'); if (frag != std::string::npos) base_path.resize(frag);
    if (!location.empty() && location[0] == '#') {
        size_t old_frag = base.find('#');
        return (old_frag == std::string::npos ? base : base.substr(0, old_frag)) + location;
    }
    if (!location.empty() && location[0] == '?') {
        size_t q = base_path.find('?'); if (q != std::string::npos) base_path.resize(q);
        return origin + base_path + location;
    }
    if (!location.empty() && location[0] == '/') return origin + location;
    size_t q = base_path.find('?'); if (q != std::string::npos) base_path.resize(q);
    size_t slash = base_path.rfind('/');
    std::string dir = slash == std::string::npos ? "/" : base_path.substr(0, slash + 1);
    return origin + dir + location;
}
static void install_public_dns() {
    ip_addr_t a{}, b{};
    IP_ADDR4(&a, 1, 1, 1, 1); IP_ADDR4(&b, 8, 8, 8, 8);
    dns_setserver(0, &a); dns_setserver(1, &b);
}
static bool resolve_for_request(const std::string& host, IPAddress& ip) {
    if (Network.hostByName(host.c_str(), ip)==1) return true;
    Serial.printf("[net] DNS miss for %s; applying 1.1.1.1 / 8.8.8.8\n", host.c_str());
    install_public_dns();
    delay(120);
    return Network.hostByName(host.c_str(), ip)==1;
}
static std::string http_error_text(int code) {
    if (code >= 100) return "HTTP " + std::to_string(code);
    String e = HTTPClient::errorToString(code);
    return std::string(e.c_str());
}
static void http_setup(HTTPClient& http, const char* ua, int timeout_ms) {
    http.useHTTP10(false);                         /* HTTP/1.1 + writeToStream chunk decoder */
    http.setUserAgent(ua ? ua : "MaskosisPhoneN9/1.1.7 (ESP32-S3)");
    http.setFollowRedirects(HTTPC_DISABLE_FOLLOW_REDIRECTS); /* cross-protocol redirects handled below */
    http.setRedirectLimit(0);
    http.setReuse(false);
    http.setConnectTimeout(10000);
    http.setTimeout(timeout_ms);
    http.addHeader("Accept", "*/*");
    http.setAcceptEncoding("identity");             /* avoid duplicate/unsupported compressed bodies */
}

/* Certificate validation needs a plausible wall clock. The UI starts SNTP as soon as Wi-Fi is up;
 * network jobs may race that first sync, so HTTPS requests wait briefly instead of failing instantly.
 * A build/NVS timestamp is only a TLS bootstrap hint; it never marks the UI clock as user-valid. */
static bool wait_for_tls_clock(uint32_t budget_ms = 9000) {
    if (time(nullptr) > 1700000000) return true;
    ensure_sntp_started();
    uint32_t t0 = ::millis();
    while (WiFi.status() == WL_CONNECTED && time(nullptr) <= 1700000000 && ::millis() - t0 < budget_ms) delay(50);
    if (time(nullptr) > 1700000000) return true;
    net_error("TLS clock unavailable after NTP wait");
    return false;
}

class BoundedStringSink final : public Stream {
public:
    BoundedStringSink(std::string& out, size_t cap, request_budget::Budget budget) : out_(out), cap_(cap), budget_(budget) { out_.clear(); }
    size_t write(uint8_t b) override { return write(&b, 1); }
    size_t write(const uint8_t* p, size_t n) override {
        if (budget_.expired(::millis())) return 0;
        const size_t room = out_.size() < cap_ ? cap_ - out_.size() : 0;
        const size_t take = n < room ? n : room;
        if (take) out_.append((const char*)p, take);
        if (take != n) truncated_ = true;
        return take;
    }
    int available() override { return 0; }
    int read() override { return -1; }
    int peek() override { return -1; }
    void flush() override {}
    bool truncated() const { return truncated_; }
private:
    std::string& out_; size_t cap_; request_budget::Budget budget_; bool truncated_ = false;
};
class PsramBodySink final : public Stream {
public:
    PsramBodySink(HttpBuffer& out, request_budget::Budget budget) : out_(out), budget_(budget) {}
    size_t write(uint8_t b) override { return write(&b, 1); }
    size_t write(const uint8_t* p, size_t n) override {
        if (budget_.expired(::millis()) || !out_.data || out_.capacity == 0) return 0;
        const size_t cap = out_.capacity - 1;
        const size_t room = out_.size < cap ? cap - out_.size : 0;
        const size_t take = n < room ? n : room;
        if (take) { memcpy(out_.data + out_.size, p, take); out_.size += take; out_.data[out_.size] = 0; }
        if (take != n) out_.truncated = true;
        /* Stop as soon as the reader cap is reached. Returning a short write makes HTTPClient
         * abort the remainder of an oversized page/feed instead of draining megabytes while the
         * UI appears stuck on Loading. http_get_buffer() explicitly treats this bounded abort as
         * a successful truncated preview when we retained useful bytes. */
        return take;
    }
    int available() override { return 0; }
    int read() override { return -1; }
    int peek() override { return -1; }
    void flush() override {}
private:
    HttpBuffer& out_; request_budget::Budget budget_;
};

class FileSink final : public Stream {
public:
    FileSink(FILE* f, uint32_t total, std::function<void(uint32_t,uint32_t)> cb)
        : f_(f), total_(total), cb_(std::move(cb)) {}
    size_t write(uint8_t b) override { return write(&b, 1); }
    size_t write(const uint8_t* p, size_t n) override {
        if (!ok_ || !f_) return 0;
        size_t w = fwrite(p, 1, n, f_); got_ += (uint32_t)w;
        if (cb_) cb_(got_, total_); if (w != n) ok_ = false; return w;
    }
    int available() override { return 0; }
    int read() override { return -1; }
    int peek() override { return -1; }
    void flush() override { if (f_) fflush(f_); }
    bool ok() const { return ok_; } uint32_t got() const { return got_; }
private:
    FILE* f_ = nullptr; uint32_t total_ = 0, got_ = 0;
    std::function<void(uint32_t,uint32_t)> cb_; bool ok_ = true;
};

static bool is_redirect(int code) { return code == 301 || code == 302 || code == 303 || code == 307 || code == 308; }

/* Free a retained response buffer before a new TLS handshake. std::string::clear()
 * keeps capacity, which can unnecessarily hold a previous HTTP page while mbedTLS
 * is trying to obtain its peak handshake blocks. swap() actually releases it. */
static void release_http_body(std::string& body) {
    if (body.capacity() > 1024) { std::string empty; body.swap(empty); }
    else body.clear();
}

bool http_get(const std::string& url, std::string& body, size_t max_bytes, int* status, const char* ua) {
    std::unique_lock<std::mutex> transport_lock(s_http_transport_mutex, std::defer_lock);
    if (!request_budget::acquire(transport_lock, [] { return ::millis(); }, [](uint32_t ms) { delay(ms); }, 5000)) {
        release_http_body(body); if (status) *status = 0; net_error("Network busy. Try again."); return false;
    }
    const request_budget::Budget budget{::millis(), 25000};
    release_http_body(body); if (status) *status = 0; net_clear_error();
    if (WiFi.status() != WL_CONNECTED) { net_error("Wi-Fi is not connected"); return false; }
    if (!max_bytes) { net_error("HTTP response limit is zero"); return false; }
    std::string current = url;
    for (int hop = 0; hop < 6; ++hop) {
        if (budget.expired(::millis())) { net_error("Request time limit reached"); return false; }
        HttpUrl u;
        if (!parse_http_url(current, u)) { net_error("Unsupported URL: " + current); return false; }
        IPAddress ip;
        if (!resolve_for_request(u.host, ip)) { net_error("DNS failed for " + u.host); return false; }
        if (u.https && !wait_for_tls_clock()) return false;
        Serial.printf("[net] GET hop=%d %s -> %s heap=%u largest=%u psram=%u\n", hop + 1, current.c_str(), ip.toString().c_str(),
                      (unsigned)heap_caps_get_free_size(MALLOC_CAP_INTERNAL),
                      (unsigned)heap_caps_get_largest_free_block(MALLOC_CAP_INTERNAL),
                      (unsigned)heap_caps_get_free_size(MALLOC_CAP_SPIRAM));
        int code = 0;
        for (int attempt = 0; attempt < 2; ++attempt) {
            if (budget.expired(::millis())) { net_error("Request time limit reached"); return false; }
            if (u.https) release_http_body(body); else body.clear();
            n9tls::Client sec; NetworkClient plain; HTTPClient http;
            if (u.https) {
                sec.configureTrust();
                sec.setHandshakeTimeout(12); sec.setConnectionTimeout(12000); sec.setTimeout(15000);
            }
            if (!(u.https ? http.begin(sec, current.c_str()) : http.begin(plain, current.c_str()))) {
                net_error("HTTP begin failed for " + u.host);
                if (attempt == 0) { delay(250); continue; }
                return false;
            }
            http_setup(http, ua, 15000);
            const char* hdrs[] = {"Location", "Content-Type"}; http.collectHeaders(hdrs, 2);
            code = http.GET(); if (status) *status = code;
            if (is_redirect(code)) {
                std::string loc = http.header("Location").c_str(); http.end();
                std::string next = redirect_url(current, loc);
                if (loc.empty() || next.empty() || next == current) { net_error("Invalid HTTP redirect"); return false; }
                Serial.printf("[net] redirect %d: %s -> %s\n", code, current.c_str(), next.c_str());
                current = std::move(next); code = -9999; break;
            }
            bool transfer_ok = false;
            if (code > 0) {
                const int announced = http.getSize();
                /* Regular JSON/small-text callers use std::string (internal heap). Never reserve a
                 * huge advertised body here; Web and News use http_get_buffer() in PSRAM. */
                if (announced > 0 && announced <= 12 * 1024) body.reserve(std::min<size_t>((size_t)announced, max_bytes));
                BoundedStringSink sink(body, max_bytes, budget);
                const int n = http.writeToStream(&sink);
                transfer_ok = n >= 0 || (sink.truncated() && !body.empty());
                if (sink.truncated()) Serial.printf("[net] response capped at %u bytes\n", (unsigned)max_bytes);
            }
            std::string detail;
            if (code <= 0) {
                detail = http_error_text(code);
                if (u.https) {
                    char eb[160] = {}; int te = sec.lastError(eb, sizeof eb);
                    if (te) detail += std::string("; TLS ") + eb;
                }
            }
            http.end();
            if (code >= 200 && code < 300 && transfer_ok) {
                net_clear_error();
                Serial.printf("[net] HTTP %d ok bytes=%u\n", code, (unsigned)body.size());
                return true;
            }
            const bool retry = attempt == 0 && (code <= 0 || code == 408 || code >= 500);
            if (code > 0) detail = "HTTP " + std::to_string(code);
            if (!transfer_ok && code >= 200 && code < 300) detail = "Response body transfer failed";
            net_error(detail.empty() ? "HTTP request failed" : detail);
            if (!retry) break;
            delay(350);
        }
        if (code == -9999) continue;               // redirect: new URL, new transport
        return false;
    }
    net_error("Too many HTTP redirects");
    return false;
}

void http_buffer_free(HttpBuffer& body) {
    if (body.data) heap_caps_free(body.data);
    body.data = nullptr; body.size = body.capacity = 0; body.truncated = false;
}

bool http_get_buffer(const std::string& url, HttpBuffer& body, size_t max_bytes, int* status, const char* ua) {
    std::unique_lock<std::mutex> transport_lock(s_http_transport_mutex, std::defer_lock);
    if (!request_budget::acquire(transport_lock, [] { return ::millis(); }, [](uint32_t ms) { delay(ms); }, 5000)) {
        http_buffer_free(body); if (status) *status = 0; net_error("Network busy. Try again."); return false;
    }
    const request_budget::Budget budget{::millis(), 25000};
    http_buffer_free(body); if (status) *status = 0; net_clear_error();
    if (WiFi.status() != WL_CONNECTED) { net_error("Wi-Fi is not connected"); return false; }
    if (!max_bytes) { net_error("HTTP response limit is zero"); return false; }

    /* Large reader payloads belong in PSRAM.  Allocate the cap once before the request so the
     * response never asks std::string/new for a 50-250 KB contiguous internal-DRAM block. */
    body.data = (char*)heap_caps_malloc(max_bytes + 1, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
    if (!body.data) {
        net_error("Not enough PSRAM for page/feed buffer");
        return false;
    }
    body.capacity = max_bytes + 1; body.data[0] = 0;

    std::string current = url;
    for (int hop = 0; hop < 6; ++hop) {
        if (budget.expired(::millis())) { http_buffer_free(body); net_error("Request time limit reached"); return false; }
        HttpUrl u;
        if (!parse_http_url(current, u)) { net_error("Unsupported URL: " + current); http_buffer_free(body); return false; }
        IPAddress ip;
        if (!resolve_for_request(u.host, ip)) { net_error("DNS failed for " + u.host); http_buffer_free(body); return false; }
        if (u.https && !wait_for_tls_clock()) { http_buffer_free(body); return false; }
        Serial.printf("[net] GET-large hop=%d %s -> %s internal=%u largest=%u psram=%u cap=%u\n",
                      hop + 1, current.c_str(), ip.toString().c_str(),
                      (unsigned)heap_caps_get_free_size(MALLOC_CAP_INTERNAL),
                      (unsigned)heap_caps_get_largest_free_block(MALLOC_CAP_INTERNAL),
                      (unsigned)heap_caps_get_free_size(MALLOC_CAP_SPIRAM), (unsigned)max_bytes);
        int code = 0;
        for (int attempt = 0; attempt < 2; ++attempt) {
            if (budget.expired(::millis())) { http_buffer_free(body); net_error("Request time limit reached"); return false; }
            body.size = 0; body.truncated = false; body.data[0] = 0;
            n9tls::Client sec; NetworkClient plain; HTTPClient http;
            if (u.https) {
                sec.configureTrust();
                sec.setHandshakeTimeout(12); sec.setConnectionTimeout(12000); sec.setTimeout(15000);
            }
            if (!(u.https ? http.begin(sec, current.c_str()) : http.begin(plain, current.c_str()))) {
                net_error("HTTP begin failed for " + u.host);
                if (attempt == 0) { delay(250); continue; }
                http_buffer_free(body); return false;
            }
            http_setup(http, ua, 15000);
            const char* hdrs[] = {"Location", "Content-Type"}; http.collectHeaders(hdrs, 2);
            code = http.GET(); if (status) *status = code;
            if (is_redirect(code)) {
                std::string loc = http.header("Location").c_str(); http.end();
                std::string next = redirect_url(current, loc);
                if (loc.empty() || next.empty() || next == current) { net_error("Invalid HTTP redirect"); http_buffer_free(body); return false; }
                Serial.printf("[net] redirect %d: %s -> %s\n", code, current.c_str(), next.c_str());
                current = std::move(next); code = -9999; break;
            }
            bool transfer_ok = false;
            if (code > 0) {
                PsramBodySink sink(body, budget);
                const int n = http.writeToStream(&sink);
                transfer_ok = (n >= 0 && body.size > 0) || (body.truncated && body.size > 0);
                if (body.truncated) Serial.printf("[net] large response capped at %u bytes\n", (unsigned)max_bytes);
            }
            std::string detail;
            if (code <= 0) {
                detail = http_error_text(code);
                if (u.https) {
                    char eb[160] = {}; int te = sec.lastError(eb, sizeof eb);
                    if (te) detail += std::string("; TLS ") + eb;
                }
            }
            http.end();
            if (code >= 200 && code < 300 && transfer_ok) {
                net_clear_error();
                Serial.printf("[net] HTTP %d large ok bytes=%u%s\n", code, (unsigned)body.size, body.truncated ? " truncated" : "");
                return true;
            }
            const bool retry = attempt == 0 && (code <= 0 || code == 408 || code >= 500);
            if (code > 0) detail = "HTTP " + std::to_string(code);
            if (!transfer_ok && code >= 200 && code < 300) detail = "Response body transfer failed";
            net_error(detail.empty() ? "HTTP request failed" : detail);
            if (!retry) break;
            delay(350);
        }
        if (code == -9999) continue;
        http_buffer_free(body); return false;
    }
    net_error("Too many HTTP redirects");
    http_buffer_free(body); return false;
}

bool http_download(const std::string& url, const std::string& path, std::function<void(uint32_t, uint32_t)> progress) {
    std::lock_guard<std::mutex> transport_lock(s_http_transport_mutex);
    if (WiFi.status() != WL_CONNECTED) { net_error("Wi-Fi is not connected"); return false; }
    std::string current = url; net_clear_error();
    for (int hop = 0; hop < 6; ++hop) {
        HttpUrl u; if (!parse_http_url(current, u)) { net_error("Unsupported URL: " + current); return false; }
        IPAddress ip; if (!resolve_for_request(u.host, ip)) { net_error("DNS failed for " + u.host); return false; }
        if (u.https && !wait_for_tls_clock()) return false;
        n9tls::Client sec; NetworkClient plain; HTTPClient http;
        if (u.https) { sec.configureTrust(); sec.setHandshakeTimeout(12); sec.setConnectionTimeout(12000); sec.setTimeout(20000); }
        if (!(u.https ? http.begin(sec, current.c_str()) : http.begin(plain, current.c_str()))) { net_error("HTTP begin failed for " + u.host); return false; }
        http_setup(http, nullptr, 20000); const char* hdrs[] = {"Location"}; http.collectHeaders(hdrs, 1);
        int code = http.GET();
        if (is_redirect(code)) {
            std::string loc = http.header("Location").c_str(); http.end();
            std::string next = redirect_url(current, loc);
            if (loc.empty() || next.empty() || next == current) { net_error("Invalid download redirect"); return false; }
            current = std::move(next); continue;
        }
        if (code < 200 || code >= 300) {
            std::string e = code <= 0 ? http_error_text(code) : "HTTP " + std::to_string(code);
            if (code <= 0 && u.https) { char eb[160] = {}; int te = sec.lastError(eb, sizeof eb); if (te) e += std::string("; TLS ") + eb; }
            http.end(); net_error(e); return false;
        }
        FILE* f = fopen(path.c_str(), "wb"); if (!f) { http.end(); net_error("Can't create download file"); return false; }
        const int announced = http.getSize(); FileSink sink(f, announced > 0 ? (uint32_t)announced : 0, std::move(progress));
        const int n = http.writeToStream(&sink); bool ok = n >= 0 && sink.ok();
        if (fclose(f) != 0) ok = false; http.end();
        if (announced >= 0 && sink.got() != (uint32_t)announced) ok = false;
        if (!sink.got()) ok = false;
        if (!ok) { remove(path.c_str()); net_error("Download body transfer failed"); return false; }
        net_clear_error(); return true;
    }
    net_error("Too many download redirects"); return false;
}

std::string net_diagnose() {
    if (WiFi.status() != WL_CONNECTED) return "Wi-Fi is not connected";
    char head[192];
    snprintf(head, sizeof head, "IP %s  GW %s  DNS %s / %s",
             WiFi.localIP().toString().c_str(), WiFi.gatewayIP().toString().c_str(),
             WiFi.dnsIP(0).toString().c_str(), WiFi.dnsIP(1).toString().c_str());
    Serial.printf("[net-test] %s\n", head);

    // First prove that packets can leave the LAN without involving DNS or TLS.
    NetworkClient route;
    IPAddress cf(1, 1, 1, 1);
    if (!route.connect(cf, 80, 3500)) {
        net_error("No Internet route: TCP to 1.1.1.1:80 failed");
        return std::string(head) + "\nRoute FAILED: " + net_last_error();
    }
    route.stop();

    IPAddress resolved;
    if (!resolve_for_request("example.com", resolved)) {
        net_error("Internet route works, but DNS failed for example.com");
        return std::string(head) + "\nRoute OK; DNS FAILED";
    }

    std::string body; int st = 0;
    if (!http_get("http://example.com/", body, 24 * 1024, &st, "MaskosisPhoneN9/1.1.7 NetworkTest"))
        return std::string(head) + "\nRoute/DNS OK; HTTP FAILED: " + net_last_error();
    release_http_body(body); st = 0;
    nano_tls_alloc_reset_stats();
    if (!http_get("https://example.com/", body, 24 * 1024, &st, "MaskosisPhoneN9/1.1.7 NetworkTest")) {
        char mem[256];
        snprintf(mem, sizeof mem,
                 "  internal=%u KB largest=%u KB psram=%u KB tlsPSRAM=%u KB/%u allocs fallback=%u failed=%u",
                 (unsigned)(heap_caps_get_free_size(MALLOC_CAP_INTERNAL) / 1024),
                 (unsigned)(heap_caps_get_largest_free_block(MALLOC_CAP_INTERNAL) / 1024),
                 (unsigned)(heap_caps_get_free_size(MALLOC_CAP_SPIRAM) / 1024),
                 (unsigned)(nano_tls_psram_alloc_bytes() / 1024),
                 (unsigned)nano_tls_psram_alloc_count(),
                 (unsigned)nano_tls_internal_fallback_count(),
                 (unsigned)nano_tls_failed_alloc_count());
        return std::string(head) + "\nRoute/DNS/HTTP OK; HTTPS FAILED: " + net_last_error() + mem;
    }

    Serial.printf("[net-test] TLS PSRAM allocator: %u bytes in %u allocs, fallback=%u failed=%u\n",
                  (unsigned)nano_tls_psram_alloc_bytes(), (unsigned)nano_tls_psram_alloc_count(),
                  (unsigned)nano_tls_internal_fallback_count(), (unsigned)nano_tls_failed_alloc_count());
    net_clear_error();
    char ok[256];
    snprintf(ok, sizeof ok, "%s\nRoute OK  DNS %s  HTTP/HTTPS OK", head, resolved.toString().c_str());
    Serial.printf("[net-test] PASS %s\n", ok);
    return ok;
}

/* ---- sockets for Mail (IMAP / SMTP), worker thread only.
 * Non-TLS connections are opened as a NetworkClientSecure in "plain start" mode so STARTTLS can upgrade
 * them in place. While still plain, I/O goes straight to the (non-blocking) socket: the library's
 * plain-start available()/connected() are not usable (available() reports readiness, not a byte count,
 * and connected() blocks for the whole socket timeout). */
struct Sock { n9tls::Client* c; bool plain; std::string buf; };
static std::map<int, Sock> s_socks;
static int s_next_sock = 1;
static const int kSockTimeoutMs = 15000;

int sock_open(const std::string& host, int port, bool tls) {
    if (WiFi.status() != WL_CONNECTED) return -1;
    auto* c = new n9tls::Client();
    c->configureTrust();
    if (!tls) c->setPlainStart();
    c->setHandshakeTimeout(kSockTimeoutMs / 1000);          /* seconds */
    c->setConnectionTimeout(kSockTimeoutMs);                /* connect + socket send/receive, in ms */
    c->setTimeout(kSockTimeoutMs);                          /* Stream timeout, in ms */
    if (!c->connect(host.c_str(), port, kSockTimeoutMs)) { delete c; return -1; }
    int h = s_next_sock++;
    s_socks[h] = {c, !tls, ""};
    return h;
}

/* >0 bytes read, 0 nothing available yet, -1 closed or failed */
static int sock_read_some(Sock& s, char* b, size_t n) {
    if (s.plain) {
        int fd = s.c->fd();
        if (fd < 0) return -1;
        int r = lwip_recv(fd, b, n, MSG_DONTWAIT);
        if (r > 0) return r;
        if (r == 0) return -1;                              /* orderly close */
        return (errno == EAGAIN || errno == EWOULDBLOCK) ? 0 : -1;
    }
    int av = s.c->available();
    if (av > 0) {
        int r = s.c->read((uint8_t*)b, (size_t)av > n ? n : (size_t)av);
        return r > 0 ? r : (s.c->connected() ? 0 : -1);
    }
    return s.c->connected() ? 0 : -1;
}

bool sock_write(int h, const std::string& d) {
    auto it = s_socks.find(h);
    if (it == s_socks.end()) return false;
    Sock& s = it->second;
    if (!s.plain) {
        if (!s.c->connected()) return false;
        return s.c->write((const uint8_t*)d.data(), d.size()) == d.size();
    }
    int fd = s.c->fd();
    size_t off = 0;
    uint32_t t0 = ::millis();
    while (off < d.size()) {
        if (fd < 0) return false;
        int r = lwip_send(fd, d.data() + off, d.size() - off, MSG_DONTWAIT);
        if (r > 0) { off += r; t0 = ::millis(); continue; }
        if (r < 0 && errno != EAGAIN && errno != EWOULDBLOCK) return false;
        if (::millis() - t0 > (uint32_t)kSockTimeoutMs) return false;
        delay(2);
    }
    return true;
}

bool sock_readline(int h, std::string& line, int timeout_ms) {
    auto it = s_socks.find(h);
    if (it == s_socks.end()) return false;
    Sock& s = it->second;
    uint32_t t0 = ::millis();
    for (;;) {
        size_t nl = s.buf.find('\n');
        if (nl != std::string::npos) {
            line = s.buf.substr(0, nl);
            if (!line.empty() && line.back() == '\r') line.pop_back();
            s.buf.erase(0, nl + 1);
            return true;
        }
        if (s.buf.size() > 1024 * 1024) return false;       /* no line end in sight: protocol error */
        char b[512];
        int n = sock_read_some(s, b, sizeof b);
        if (n > 0) { s.buf.append(b, n); t0 = ::millis(); continue; }   /* timeout counts from the last data */
        if (n < 0 || ::millis() - t0 > (uint32_t)timeout_ms) return false;
        delay(2);
    }
}

/* Binary-safe read, for nanoLink's [type][length][payload] framing (sock_readline() splits on '\n'
 * and would eat payload bytes). Anything sock_readline() read past its last line is handed back first. */
int sock_read(int h, char* buf, size_t max, int timeout_ms) {
    auto it = s_socks.find(h);
    if (it == s_socks.end()) return -1;
    Sock& s = it->second;
    if (max == 0) return 0;
    if (!s.buf.empty()) {
        size_t n = s.buf.size() < max ? s.buf.size() : max;
        memcpy(buf, s.buf.data(), n);
        s.buf.erase(0, n);
        return (int)n;
    }
    uint32_t t0 = ::millis();
    for (;;) {
        int n = sock_read_some(s, buf, max);
        if (n > 0) return n;
        if (n < 0) return -1;                               /* closed or failed */
        if (::millis() - t0 >= (uint32_t)(timeout_ms < 0 ? 0 : timeout_ms)) return 0;
        delay(2);
    }
}

bool sock_starttls(int h) {
    auto it = s_socks.find(h);
    if (it == s_socks.end()) return false;
    Sock& s = it->second;
    if (!s.plain) return true;
    s.buf.clear();                                          /* nothing sent before the handshake may be trusted */
    if (!s.c->startTLS()) return false;                     /* certificate / handshake failure: closed */
    s.plain = false;
    return true;
}

void sock_close(int h) {
    auto it = s_socks.find(h);
    if (it == s_socks.end()) return;
    it->second.c->stop();
    delete it->second.c;
    s_socks.erase(it);
}

/* ---- firmware update from the microSD card ----
 * Release packages include update.bin.sha256.  This is an integrity check (it
 * detects truncation/corruption); production signing / Secure Boot key
 * provisioning remains a manufacturing gate and is intentionally not faked here. */
static bool ota_verify_sha256(FILE* f, const std::string& path, std::string& error) {
    std::string hp = path + ".sha256";
    FILE* hf = fopen(hp.c_str(), "r");
    if (!hf) { error = "Missing update.bin.sha256 integrity file."; return false; }
    char expected[65] = {0};
    if (fread(expected, 1, 64, hf) != 64) { fclose(hf); error = "The update integrity file is invalid."; return false; }
    fclose(hf);
    for (int i = 0; i < 64; i++) {
        if (!isxdigit((unsigned char)expected[i])) { error = "The update integrity file is invalid."; return false; }
        expected[i] = (char)tolower((unsigned char)expected[i]);
    }

    mbedtls_sha256_context ctx;
    mbedtls_sha256_init(&ctx);
    mbedtls_sha256_starts(&ctx, 0);
    uint8_t buf[4096], digest[32];
    rewind(f);
    for (;;) {
        size_t n = fread(buf, 1, sizeof buf, f);
        if (n) mbedtls_sha256_update(&ctx, buf, n);
        if (n < sizeof buf) { if (ferror(f)) { mbedtls_sha256_free(&ctx); error = "Couldn't read the update."; return false; } break; }
    }
    mbedtls_sha256_finish(&ctx, digest);
    mbedtls_sha256_free(&ctx);
    char actual[65];
    for (int i = 0; i < 32; i++) snprintf(actual + i * 2, 3, "%02x", digest[i]);
    actual[64] = 0;
    rewind(f);
    if (strncmp(actual, expected, 64) != 0) { error = "Update integrity check failed."; return false; }
    return true;
}

bool ota_from_file(const std::string& path, std::function<void(int)> progress, std::string& error) {
    FILE* f = fopen(path.c_str(), "rb");
    if (!f) { error = "No update file found."; return false; }
    fseek(f, 0, SEEK_END);
    long size = ftell(f);
    fseek(f, 0, SEEK_SET);
    if (size <= 0) { fclose(f); error = "The update file is empty."; return false; }
    if (!ota_verify_sha256(f, path, error)) { fclose(f); return false; }
    if (!Update.begin(size, U_FLASH)) { fclose(f); error = "Not enough space for the update."; return false; }
    static uint8_t buf[4096];
    long done = 0;
    int last = -1;
    while (done < size) {
        size_t n = fread(buf, 1, sizeof buf, f);
        if (!n || Update.write(buf, n) != n) { fclose(f); Update.abort(); error = "Couldn't write the update."; return false; }
        done += n;
        int pct = (int)(done * 100 / size);
        if (pct != last && progress) { progress(pct); last = pct; }
    }
    fclose(f);
    if (!Update.end(true)) { error = "The update file isn't valid for this device."; return false; }
    rename(path.c_str(), (path + ".installed").c_str());
    rename((path + ".sha256").c_str(), (path + ".sha256.installed").c_str());
    return true;
}

void poll() {
    static uint32_t last_time_check = 0;
    if (::millis() - last_time_check >= 1000) {
        last_time_check = ::millis();
        const bool automatic = kv_get_int("auto_time", 1) != 0;
        if (!automatic && s_sntp_started.exchange(false)) esp_sntp_stop();
        if (automatic && wifi_state() == 3) ensure_sntp_started();
    }
    const uint32_t callbacks_started = ::millis();
    for (unsigned count = 0; count < 2; ++count) {
        std::function<void()> d;
        {
            std::lock_guard<std::mutex> l(s_done_mtx);
            if (s_done.empty()) break;
            d = std::move(s_done.front());
            s_done.pop_front();
        }
        d();
        if (::millis() - callbacks_started >= 3) break;
    }
    static uint32_t last_save = 0;
    if (::millis() - last_save > 600000) {       /* persist wall clock every 10 minutes */
        last_save = ::millis();
        if (time_valid()) s_prefs.putLong64("t_saved", (int64_t)now());
    }
}

/* started from main after the UI is up (the worker already runs: see init()) */
void start_tasks() {
    jobs_init();
    if (!s_audio_task) {
        TaskHandle_t h = nullptr;
        if (xTaskCreatePinnedToCore(audio_task, "audio", 12288, nullptr, 5, &h, 0) == pdPASS) {
            s_audio_task = h;
            Serial.println("[boot] audio task ready");
        } else {
            Serial.println("[boot] audio task allocation FAILED; media controls remain available but audio is disabled");
        }
    }
    usbaudio::begin();
    if (kv_get_int("wifi_on", 0)) wifi_enable(true);
}

} // namespace hal
