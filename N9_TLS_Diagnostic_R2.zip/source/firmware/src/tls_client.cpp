#include "tls_client.h"
#include <esp_crt_bundle.h>
#include <esp32_cert_bundle.h>
#include <mbedtls/x509.h>
#include <ctime>
#include <mutex>

// Exported by the pinned ESP-IDF 5.5 bundle implementation. The diagnostic
// callback delegates the trust decision to it without changing any flags.
extern "C" int esp_crt_verify_callback(void* context, mbedtls_x509_crt* certificate,
                                      int depth, uint32_t* flags);

namespace n9tls {
namespace {
int verify_with_diagnostics(void* context, mbedtls_x509_crt* certificate,
                            int depth, uint32_t* flags) {
    const uint32_t incoming = *flags;
    const int result = esp_crt_verify_callback(context, certificate, depth, flags);
    char issuer[192] = {};
    char subject[192] = {};
    mbedtls_x509_dn_gets(issuer, sizeof issuer, &certificate->issuer);
    mbedtls_x509_dn_gets(subject, sizeof subject, &certificate->subject);
    Serial.printf("[tls-verify] depth=%d before=0x%08lx after=0x%08lx callback=%d\n"
                  "[tls-verify] issuer=%s\n[tls-verify] subject=%s\n",
                  depth, static_cast<unsigned long>(incoming),
                  static_cast<unsigned long>(*flags), result, issuer, subject);
    if (result != 0 || *flags != 0) {
        Serial.printf("[tls-verify] failed epochUTC=%lld\n",
                      static_cast<long long>(std::time(nullptr)));
    }
    return result;
}
}

esp_err_t attach_with_diagnostics(void* config) {
    const esp_err_t result = esp_crt_bundle_attach(config);
    if (result != ESP_OK) {
        Serial.printf("[tls-verify] bundle attachment failed=%d\n", result);
        return result;
    }
    if (config != nullptr) {
        mbedtls_ssl_conf_verify(static_cast<mbedtls_ssl_config*>(config),
                               verify_with_diagnostics, nullptr);
    }
    return result;
}

unsigned root_count(){
    // IDF 5.5 uses a little-endian uint32 offset table. The first offset is
    // the table size in bytes, with one four-byte entry per certificate.
    uint32_t first=uint32_t(x509_crt_bundle[0])|(uint32_t(x509_crt_bundle[1])<<8)|
                   (uint32_t(x509_crt_bundle[2])<<16)|(uint32_t(x509_crt_bundle[3])<<24);
    return first%4==0 && first<x509_crt_bundle_len ? first/4 : 0;
}
bool initialize(){
    static std::once_flag once;static bool ok=false;
    std::call_once(once,[]{
        // Register the bundle once. Replacing the global bundle during another
        // connection's handshake invalidates that connection's certificate data.
        ok=x509_crt_bundle_len>16000 && root_count()>=100 &&
           esp_crt_bundle_set(x509_crt_bundle,x509_crt_bundle_len)==ESP_OK;
        Serial.printf("[tls] roots=%u bytes=%u status=%s\n",root_count(),unsigned(x509_crt_bundle_len),ok?"ready":"FAILED");
    });return ok;
}
}
