#pragma once
#include <NetworkClientSecure.h>
namespace n9tls {
bool initialize();
unsigned root_count();
esp_err_t attach_with_diagnostics(void* config);
class Client final : public NetworkClientSecure {
public:
    bool configureTrust() {
        if (!initialize()) return false;
        _use_insecure = false;
        _use_ca_bundle = true;
        attach_ssl_certificate_bundle(sslclient.get(), true);
        sslclient->bundle_attach_cb = attach_with_diagnostics;
        return true;
    }
};
}
