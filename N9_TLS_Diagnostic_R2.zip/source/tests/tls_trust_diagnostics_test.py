#!/usr/bin/env python3
"""Check actual TLS diagnostic delegation without simulating certificate trust."""
from pathlib import Path
import subprocess
import tempfile

root = Path(__file__).resolve().parents[1]
stubs = root / "tests/tls_diagnostics_stubs"
with tempfile.TemporaryDirectory(prefix="n9-tls-diagnostics-") as directory:
    binary = Path(directory) / "tls-diagnostics-test"
    subprocess.run([
        "g++", "-std=c++17", "-fsanitize=address,undefined", "-pthread",
        "-I" + str(stubs), "-I" + str(root / "firmware/src"),
        str(stubs / "main.cpp"), str(root / "firmware/src/tls_client.cpp"),
        "-o", str(binary),
    ], check=True)
    subprocess.run([str(binary)], check=True)
    subprocess.run([str(binary), "initialization-fails"], check=True)
