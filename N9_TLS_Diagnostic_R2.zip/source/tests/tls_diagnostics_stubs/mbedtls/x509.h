#pragma once
#include "NetworkClientSecure.h"
int mbedtls_x509_dn_gets(char* out, size_t size, const mbedtls_x509_name* name);
