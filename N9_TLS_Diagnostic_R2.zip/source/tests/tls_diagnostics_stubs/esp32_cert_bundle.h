#pragma once
// Structural fixture for the registration precondition, not a CA trust store.
// First offset 400 bytes encodes 100 little-endian table entries.
static const unsigned char x509_crt_bundle[17000] = {0x90, 0x01, 0x00, 0x00};
static const unsigned int x509_crt_bundle_len = sizeof(x509_crt_bundle);
