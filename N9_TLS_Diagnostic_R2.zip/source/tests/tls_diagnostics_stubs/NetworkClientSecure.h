#pragma once
#include <cstddef>
#include <cstdint>
#include <memory>
#include <string>
using esp_err_t = int;
inline constexpr esp_err_t ESP_OK = 0;
struct mbedtls_x509_name { const char* text; };
struct mbedtls_x509_crt {
    mbedtls_x509_name issuer;
    mbedtls_x509_name subject;
};
using verify_callback = int (*)(void*, mbedtls_x509_crt*, int, uint32_t*);
struct mbedtls_ssl_config {
    verify_callback verify = nullptr;
    void* context = nullptr;
};
struct sslclient_context {
    esp_err_t (*bundle_attach_cb)(void*) = nullptr;
};
struct SerialStub {
    std::string output;
    void printf(const char* format, ...);
};
extern SerialStub Serial;
void attach_ssl_certificate_bundle(sslclient_context* client, bool attach);
class NetworkClientSecure {
protected:
    bool _use_insecure = true;
    bool _use_ca_bundle = false;
    std::shared_ptr<sslclient_context> sslclient = std::make_shared<sslclient_context>();
public:
    sslclient_context* test_context() { return sslclient.get(); }
    bool test_insecure() const { return _use_insecure; }
    bool test_bundle_enabled() const { return _use_ca_bundle; }
};
void mbedtls_ssl_conf_verify(mbedtls_ssl_config*, verify_callback, void*);
