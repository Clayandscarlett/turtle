#include "tls_client.h"
#include "esp_crt_bundle.h"
#include <cassert>
#include <cstdarg>
#include <cstdio>

SerialStub Serial;
static int set_calls = 0;
static int attach_calls = 0;
static int register_calls = 0;
static int delegate_calls = 0;
static esp_err_t set_result = ESP_OK;
static esp_err_t attach_result = ESP_OK;
static uint32_t delegated_flags = 0;
static int delegated_result = 0;
static void* expected_context = nullptr;
static mbedtls_x509_crt* expected_certificate = nullptr;
static int expected_depth = 0;
static uint32_t expected_incoming = 0;

void SerialStub::printf(const char* format, ...) {
    char buffer[1024];
    va_list arguments;
    va_start(arguments, format);
    int count = vsnprintf(buffer, sizeof buffer, format, arguments);
    va_end(arguments);
    assert(count >= 0 && count < int(sizeof buffer));
    output.append(buffer, size_t(count));
}
void attach_ssl_certificate_bundle(sslclient_context* client, bool attach) {
    client->bundle_attach_cb = attach ? esp_crt_bundle_attach : nullptr;
}
esp_err_t esp_crt_bundle_set(const uint8_t* bundle, size_t size) {
    assert(bundle != nullptr && size == 17000);
    ++set_calls;
    return set_result;
}
esp_err_t esp_crt_bundle_attach(void*) {
    ++attach_calls;
    return attach_result;
}
void mbedtls_ssl_conf_verify(mbedtls_ssl_config* config, verify_callback callback, void* context) {
    ++register_calls;
    config->verify = callback;
    config->context = context;
}
int mbedtls_x509_dn_gets(char* output, size_t size, const mbedtls_x509_name* name) {
    return snprintf(output, size, "%s", name->text);
}
extern "C" int esp_crt_verify_callback(void* context, mbedtls_x509_crt* certificate,
                                      int depth, uint32_t* flags) {
    ++delegate_calls;
    assert(context == expected_context && certificate == expected_certificate);
    assert(depth == expected_depth && *flags == expected_incoming);
    *flags = delegated_flags;
    return delegated_result;
}

int main(int argc, char**) {
    if (argc > 1) {
        set_result = 0x102;
        n9tls::Client client;
        assert(!client.configureTrust());
        assert(client.test_insecure() && !client.test_bundle_enabled());
        assert(client.test_context()->bundle_attach_cb == nullptr);
        set_result = ESP_OK;
        assert(!client.configureTrust() && set_calls == 1);
        puts("PASS: failed root initialization never enables trust or attaches a callback");
        return 0;
    }
    assert(n9tls::root_count() == 100);
    n9tls::Client first;
    n9tls::Client second;
    assert(first.configureTrust() && second.configureTrust() && set_calls == 1);
    assert(!first.test_insecure() && first.test_bundle_enabled());
    assert(first.test_context()->bundle_attach_cb == n9tls::attach_with_diagnostics);

    mbedtls_ssl_config config;
    assert(first.test_context()->bundle_attach_cb(&config) == ESP_OK);
    assert(attach_calls == 1 && register_calls == 1);
    assert(config.verify != nullptr && config.context == nullptr);
    mbedtls_x509_crt certificate{{"CN=Test root"}, {"CN=example.com"}};
    expected_certificate = &certificate;

    struct Case { uint32_t before; uint32_t after; int result; };
    const Case cases[] = {
        {0, 0, 0},                     // Already trusted chain.
        {8, 0, 0},                     // SDK bundle accepts otherwise-untrusted link.
        {1, 1, 0},                     // Expired/date-invalid flags remain rejected.
        {0x200, 0x200, 0},             // Future-date flag stays unchanged.
        {0x10008, 0x10008, 0},         // Unsupported key/trust flags stay unchanged.
        {8, 8, -0x2700},               // Missing root callback result is unchanged.
        {8, 8, -0x3000},               // Fatal bundle failure is unchanged.
        {0, 0, -0x3880},               // Callback failure without flags is unchanged.
    };
    int depth = 0;
    for (const auto& item : cases) {
        Serial.output.clear();
        uint32_t flags = item.before;
        expected_incoming = item.before;
        delegated_flags = item.after;
        delegated_result = item.result;
        expected_depth = depth++;
        int count_before = delegate_calls;
        assert(config.verify(nullptr, &certificate, expected_depth, &flags) == item.result);
        assert(flags == item.after && delegate_calls == count_before + 1);
        assert(Serial.output.find("issuer=CN=Test root") != std::string::npos);
        assert(Serial.output.find("subject=CN=example.com") != std::string::npos);
        bool failed = item.result != 0 || item.after != 0;
        assert((Serial.output.find("failed epochUTC=") != std::string::npos) == failed);
    }

    // Do not alter or replace the installed verifier if SDK attachment fails.
    attach_result = 0x102;
    verify_callback previous = config.verify;
    int registered_before = register_calls;
    assert(first.test_context()->bundle_attach_cb(&config) == attach_result);
    assert(config.verify == previous && register_calls == registered_before);
    // Null-config registration remains a supported SDK bundle operation.
    attach_result = ESP_OK;
    assert(n9tls::attach_with_diagnostics(nullptr) == ESP_OK);
    assert(register_calls == registered_before);
    puts("PASS: SDK callback and flags preserved across eight trust outcomes; secure client, once-only roots, failed attachment and null config checked");
}
