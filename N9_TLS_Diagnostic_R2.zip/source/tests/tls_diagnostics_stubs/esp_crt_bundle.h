#pragma once
#include "NetworkClientSecure.h"
esp_err_t esp_crt_bundle_attach(void* config);
esp_err_t esp_crt_bundle_set(const uint8_t* bundle, size_t size);
