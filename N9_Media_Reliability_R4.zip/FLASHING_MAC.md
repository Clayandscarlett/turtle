# Flash N9 media reliability R4 on your Mac

For Freenove FNK0104B, ESP32-S3 N16R8 only. Extract the entire ZIP first. The `bin`, `tools`, and launcher files must stay together.

1. Connect the board using a USB data cable. Close any serial monitor.
2. In Terminal, type `cd ` (with a space), drag the extracted folder into Terminal, and press Return.
3. Check Python with `python3 --version`. With Python 3.10 or later, install the flash tool once:

   ```bash
   python3 -m venv .flash-env
   .flash-env/bin/python -m pip install esptool==5.1.0
   ```

4. Check the download and find your USB port:

   ```bash
   .flash-env/bin/python tools/flash_prebuilt.py --verify-only
   .flash-env/bin/python -m serial.tools.list_ports
   ```

5. Close any serial monitor and disconnect other USB serial boards. The installer selects the single connected USB serial device:

   ```bash
   .flash-env/bin/python tools/flash_prebuilt.py
   ```

   If more than one USB serial device is found, the installer stops. Disconnect the others or pass `--port` followed by the phone’s actual `/dev/cu.usb…` path. It does not prompt for a port. The script verifies all four image hashes, writes the defined firmware ranges, and requests a full watchdog reset afterward. It does not erase the entire flash or the microSD card. This preserves settings when upgrading the existing N9 partition layout.

If it cannot connect, first retry with the device running normally: native USB may enter download mode automatically. For manual download mode, hold BOOT during an actual reset or power-on, then release it. Holding BOOT is a download-mode strap only during reset. While this N9 firmware is running, holding BOOT for at least three seconds and then releasing it requests a normal restart; it does not select download mode. On a battery-powered board, unplugging USB may leave it powered. Since your RESET button is inside the case, do not rely on USB unplugging as a reset.

If the screen stays black after a successful write, release BOOT and try a watchdog reset through the available USB port:

```bash
.flash-env/bin/python -m esptool --chip esp32s3 --port /dev/cu.usbmodem1101 --before no-reset --after watchdog-reset flash-id
```

## Check Voice Memos

Insert a writable microSD card, open Voice Memos, tap Record, and speak for five seconds. The timer advances from captured samples and the meter responds to input. Tap Stop; wait for “Memo Saved.” Tap Memos, then the recording to hear it. Files are in `/Voice Memos/` on the card. The recording app works offline.

If an error appears, note its exact wording; the app now distinguishes codec, I2S and card failures. A USB serial log also prints lines beginning `[memo]`. A completely silent recording still needs an on-device microphone and connection check.

Dashboard tap sounds can be adjusted in Settings > Sound. Internet checks remain in Settings > Wi-Fi > Test Internet.
