/*
 * nanoOS — an iPod nano (7th generation) style OS for the Freenove FNK0104B.
 * Landscape Aero Home, native portrait apps, touch navigation.
 */
#include <Arduino.h>
#include "lvgl.h"
#include "lcd.h"
#include "board.h"
#include "touch.h"
#include "hal.h"
#include "os/system.h"
#include "os/theme.h"
#include "svc/power_policy.h"
#include <atomic>
#include <esp_task_wdt.h>

/* LVGL rendering, the UI's JSON / HTML parsing and deep app call chains need more than the default 8 KB */
SET_LOOP_TASK_STACK_SIZE(16 * 1024);

void nano_register_apps();
namespace hal { void start_tasks(); }

static void touch_cb(lv_indev_t*, lv_indev_data_t* d) {
    static int16_t lx = 0, ly = 0;
    int16_t x = lx, y = ly;
    bool pressed = touch_read(x, y);
    if (pressed) { lx = x; ly = y; } else { x = lx; y = ly; }
    os::input_filter(pressed, x, y);
    d->point.x = x;
    d->point.y = y;
    d->state = pressed ? LV_INDEV_STATE_PRESSED : LV_INDEV_STATE_RELEASED;
}

static uint32_t tick_cb() { return millis(); }

/* ------------------------------------------------------------------ sealed-case recovery key
 * GPIO0 is the FNK0104B BOOT key.  During reset/power-on it keeps its normal
 * ESP32-S3 ROM-download meaning.  Once nanoOS is running we reuse it as the
 * accessible Sleep/Wake key.  The poller is deliberately a separate FreeRTOS
 * task so a wedged LVGL/Wi-Fi UI cannot take the only physical recovery input
 * away from a sealed device.
 *
 * Short press/release  -> lock/sleep or wake (executed later on the LVGL task)
 * Hold >= 3.0 s        -> emergency restart, even if the UI task is blocked
 *
 * For the emergency restart we wait for GPIO0 to be RELEASED before resetting.
 * GPIO0 low at reset is the ESP32-S3 ROM download strap; waiting for release
 * guarantees a normal flash boot rather than accidentally parking in ROM mode. */
static std::atomic<uint8_t> s_boot_ui_request{0};
static TaskHandle_t s_boot_key_task = nullptr;
static bool s_ui_wdt_added = false;
static bool s_ui_ready = false;

static constexpr uint32_t BOOT_DEBOUNCE_MS = 35;
static constexpr uint32_t BOOT_RESTART_MS  = 3000;
static constexpr uint32_t UI_WDT_MS        = 10000;

static void boot_key_worker(void*) {
    pinMode(BOOT_KEY_PIN, INPUT_PULLUP);
    bool down = false;
    bool restart_armed = false;
    uint32_t down_at = 0;

    for (;;) {
        const bool pressed = digitalRead(BOOT_KEY_PIN) == LOW;

        if (pressed && !down) {
            vTaskDelay(pdMS_TO_TICKS(BOOT_DEBOUNCE_MS));
            if (digitalRead(BOOT_KEY_PIN) == LOW) {
                down = true;
                restart_armed = false;
                down_at = ::millis();
            }
        } else if (down && pressed) {
            if (!restart_armed && (::millis() - down_at >= BOOT_RESTART_MS)) {
                restart_armed = true;
                /* Do not touch LVGL here: this task must remain usable when LVGL is the thing that froze. */
                Serial.println("[recovery] BOOT long-hold: release key to restart");
            }
        } else if (down && !pressed) {
            const uint32_t held = ::millis() - down_at;
            down = false;
            if (restart_armed || held >= BOOT_RESTART_MS) {
                Serial.println("[recovery] emergency restart");
                Serial.flush();
                vTaskDelay(pdMS_TO_TICKS(60));
                ESP.restart();
            } else if (held >= BOOT_DEBOUNCE_MS) {
                /* The UI operation itself is consumed by loop(), where LVGL calls are legal. */
                s_boot_ui_request.store(1, std::memory_order_release);
            }
        }

        vTaskDelay(pdMS_TO_TICKS(20));
    }
}

static void recovery_key_init() {
    pinMode(BOOT_KEY_PIN, INPUT_PULLUP);
    if (!s_boot_key_task) {
        BaseType_t ok = xTaskCreatePinnedToCore(boot_key_worker, "boot-key", 3072, nullptr, 3, &s_boot_key_task, 1);
        if (ok != pdPASS) s_boot_key_task = nullptr;
    }
    Serial.printf("[recovery] BOOT key task=%s\n", s_boot_key_task ? "ok" : "FAIL");
}

static void recovery_watchdog_init() {
    /* Watch the Arduino/LVGL loop task itself.  If a callback blocks the UI for
       ten seconds, trigger the ESP-IDF panic path so the sealed device reboots.
       Do not subscribe idle tasks here: nanoOS has legitimate background audio,
       USB and Wi-Fi work that should not become false-positive recovery events. */
    const esp_task_wdt_config_t cfg = {
        .timeout_ms = UI_WDT_MS,
        .idle_core_mask = 0,
        .trigger_panic = true,
    };
    esp_err_t e = esp_task_wdt_reconfigure(&cfg);
    if (e == ESP_ERR_INVALID_STATE) e = esp_task_wdt_init(&cfg);
    if (e == ESP_OK || e == ESP_ERR_INVALID_STATE) {
        esp_err_t st = esp_task_wdt_status(nullptr);
        if (st == ESP_ERR_NOT_FOUND) st = esp_task_wdt_add(nullptr);
        s_ui_wdt_added = (st == ESP_OK);
    }
    Serial.printf("[recovery] UI watchdog=%s (%lu ms)\n",
                  s_ui_wdt_added ? "armed" : "not armed", (unsigned long)UI_WDT_MS);
}

void setup() {
    Serial.begin(115200);
    /* Native USB CDC can enumerate after setup() has already started.  Give a connected
       monitor a short window to attach so early-boot faults are not silent. */
    const uint32_t serial_wait_at = ::millis();
    while (!Serial && ::millis() - serial_wait_at < 1200u) delay(10);
    Serial.printf("[boot] nanoOS %s\n", hal::fw_version());
    /* Start the only accessible physical recovery path BEFORE optional storage,
       codec, display, touch, network or application initialization. */
    recovery_key_init();
    /* Arm the setup/UI task watchdog before any peripheral work.  A wedged SD/I2C
       driver can now self-recover even before LVGL exists. */
    recovery_watchdog_init();
    hal::init();
    lv_init();
    lv_tick_set_cb(tick_cb);
    touch_init();
    /* display safe mode: a finger on the glass at power-on returns to the vendor-validated link rate */
    int16_t tx, ty;
    if (touch_read(tx, ty) && hal::kv_get_int("lcd_fast", 0)) hal::kv_set_int("lcd_fast", 0);
    lv_display_t* disp = lcd_init(hal::kv_get_int("lcd_fast", 0) ? LCD_SPI_HZ_FAST : LCD_SPI_HZ_STD);
    if (!disp) { Serial.println("[boot] display unavailable; hold BOOT to restart"); return; }
    th::init(disp);
    lv_indev_t* in = lv_indev_create();
    lv_indev_set_type(in, LV_INDEV_TYPE_POINTER);
    lv_indev_set_read_cb(in, touch_cb);
    lv_indev_set_display(in, disp);
    lv_timer_set_period(lv_indev_get_read_timer(in), 8);
    nano_register_apps();
    os::init();
    lv_refr_now(disp);
    hal::start_tasks();
    s_ui_ready = true;
    Serial.println("[boot] UI ready");
}

void loop() {
    if (!s_ui_ready) { if (s_ui_wdt_added) esp_task_wdt_reset(); delay(20); return; }
    if (s_boot_ui_request.exchange(0, std::memory_order_acq_rel)) {
        if (os::asleep()) os::wake_now();
        else os::sleep_now();
    }

    uint32_t wait = lv_timer_handler();
    os::loop();

    /* Feed only after LVGL + os::loop both returned.  A frozen callback therefore
       cannot keep the watchdog alive merely because the scheduler is still running. */
    if (s_ui_wdt_added) esp_task_wdt_reset();
    // Respect LVGL deadlines without waking an idle UI 200 times per second.
    delay(power_policy::ui_delay(wait));
}
