#include "tls_client.h"
#include "trusted_roots.h"
#include <mbedtls/x509.h>
#include <chrono>
#include <ctime>
#include <mutex>

namespace n9tls {
namespace {
mbedtls_x509_crt s_ca_chain;
// This SDK disables MBEDTLS_THREADING_C. RSA/EC root-key contexts can update
// their arithmetic caches during verification, so serialize initial handshakes.
// Recursive locking handles Arduino's virtual overload-to-overload dispatch.
std::recursive_timed_mutex s_ca_handshake_mutex;
template<typename Operation>
int guarded_handshake(sslclient_context* context, Operation operation) {
    std::unique_lock<std::recursive_timed_mutex> lock(s_ca_handshake_mutex, std::defer_lock);
    if (!lock.try_lock_for(std::chrono::milliseconds(5000))) {
        context->last_error = MBEDTLS_ERR_SSL_TIMEOUT;
        Serial.printf("[tls] handshake busy: timed out waiting for verifier\n");
        return 0;
    }
    return operation();
}
int verify_with_diagnostics(void*, mbedtls_x509_crt* certificate,
                            int depth, uint32_t* flags) {
    // Standard mbedTLS chain verification has already produced these flags.
    // Observe them only: returning zero allows VERIFY_REQUIRED to reject any
    // nonzero flag normally, without replacing it with a generic fatal error.
    char issuer[192] = {};
    char subject[192] = {};
    mbedtls_x509_dn_gets(issuer, sizeof issuer, &certificate->issuer);
    mbedtls_x509_dn_gets(subject, sizeof subject, &certificate->subject);
    Serial.printf("[tls-verify] verifier=full-ca-chain depth=%d flags=0x%08lx\n"
                  "[tls-verify] issuer=%s\n[tls-verify] subject=%s\n",
                  depth, static_cast<unsigned long>(*flags), issuer, subject);
    if (*flags != 0) {
        Serial.printf("[tls-verify] failed epochUTC=%lld\n",
                      static_cast<long long>(std::time(nullptr)));
    }
    return 0;
}
}

esp_err_t attach_with_diagnostics(void* config) {
    // Arduino tests callback errors with result < 0. Return a negative mbedTLS
    // error on cache failure so it cannot proceed with an empty trust chain.
    if (!initialize()) return MBEDTLS_ERR_X509_BAD_INPUT_DATA;
    if (config != nullptr) {
        auto* ssl_config = static_cast<mbedtls_ssl_config*>(config);
        mbedtls_ssl_conf_authmode(ssl_config, MBEDTLS_SSL_VERIFY_REQUIRED);
#if defined(MBEDTLS_SSL_RENEGOTIATION)
        // Renegotiation from read/write would touch cached root keys outside
        // the initial-handshake guard; these Internet clients do not need it.
        mbedtls_ssl_conf_renegotiation(ssl_config, MBEDTLS_SSL_RENEGOTIATION_DISABLED);
#endif
        mbedtls_ssl_conf_ca_chain(ssl_config, &s_ca_chain, nullptr);
        mbedtls_ssl_conf_verify(ssl_config, verify_with_diagnostics, nullptr);
    }
    return ESP_OK;
}

unsigned root_count(){
    return static_cast<unsigned>(trusted_root_count);
}
bool initialize(){
    static std::once_flag once;static bool ok=false;
    std::call_once(once,[]{
        static_assert(trusted_root_count == 121, "Keep the released root trust set unchanged");
        static_assert(sizeof trusted_roots / sizeof trusted_roots[0] == trusted_root_count);
        mbedtls_x509_crt_init(&s_ca_chain);
        int result = 0;
        unsigned parsed = 0;
        for (const auto& root : trusted_roots) {
            if (!root.length || root.offset > sizeof trusted_root_der ||
                root.length > sizeof trusted_root_der - root.offset) {
                result = MBEDTLS_ERR_X509_BAD_INPUT_DATA;
                break;
            }
            result = mbedtls_x509_crt_parse_der_nocopy(
                &s_ca_chain, trusted_root_der + root.offset, root.length);
            if (result != 0) break;
            ++parsed;
        }
        unsigned nodes = 0;
        for (const auto* root = &s_ca_chain; root; root = root->next) {
            if (root->version != 0) ++nodes;
        }
        ok = result == 0 && parsed == trusted_root_count && nodes == trusted_root_count;
        if (!ok) mbedtls_x509_crt_free(&s_ca_chain);
        Serial.printf("[tls] verifier=full-ca-chain roots=%u parsed=%u bytes=%u status=%s error=%d\n",
                      root_count(), parsed, unsigned(sizeof trusted_root_der), ok?"ready":"FAILED", result);
    });return ok;
}

int Client::connect(IPAddress ip, uint16_t port) {
    return guarded_handshake(sslclient.get(), [&] { return NetworkClientSecure::connect(ip, port); });
}
int Client::connect(IPAddress ip, uint16_t port, int32_t timeout) {
    return guarded_handshake(sslclient.get(), [&] { return NetworkClientSecure::connect(ip, port, timeout); });
}
int Client::connect(const char* host, uint16_t port) {
    return guarded_handshake(sslclient.get(), [&] { return NetworkClientSecure::connect(host, port); });
}
int Client::connect(const char* host, uint16_t port, int32_t timeout) {
    return guarded_handshake(sslclient.get(), [&] { return NetworkClientSecure::connect(host, port, timeout); });
}
int Client::startTLS() {
    return guarded_handshake(sslclient.get(), [&] { return NetworkClientSecure::startTLS(); });
}
}
