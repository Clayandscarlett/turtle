#pragma once
#include <NetworkClientSecure.h>
namespace n9tls {
bool initialize();
unsigned root_count();
esp_err_t attach_with_diagnostics(void* config);
class Client final : public NetworkClientSecure {
public:
    bool configureTrust() {
        if (!initialize()) return false;
        _use_insecure = false;
        _use_ca_bundle = true;
        sslclient->bundle_attach_cb = attach_with_diagnostics;
        return true;
    }
    void stop() override {
        NetworkClientSecure::stop();
        sslclient->socket = -1;
        // Arduino's stop_ssl_socket() clears bundle_attach_cb even though the
        // client still remembers _use_ca_bundle. Restore it for reconnection.
        if (_use_ca_bundle) sslclient->bundle_attach_cb = attach_with_diagnostics;
    }
    int connect(IPAddress ip, uint16_t port) override;
    int connect(IPAddress ip, uint16_t port, int32_t timeout) override;
    int connect(const char* host, uint16_t port) override;
    int connect(const char* host, uint16_t port, int32_t timeout) override;
    int startTLS();
};
}
