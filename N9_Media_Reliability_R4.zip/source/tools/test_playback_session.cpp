/* Behavioral tests for the real player + session coordinator. The HAL is fake,
 * filesystem operations are real, and link wrappers inject storage faults.
 * Compile with the command in tests/playback_session_test.py. */
#include <cassert>
#include <cerrno>
#include <cstdio>
#include <deque>
#include <filesystem>
#include <fstream>
#include <map>
#include <utility>
#include "../ui/svc/player.cpp"

#ifdef NANO_TARGET_ESP32
size_t n9_test_psram_free = 8 * 1024 * 1024;
size_t n9_test_psram_largest = 8 * 1024 * 1024;
size_t n9_test_psram_allocations = 0;
#endif

namespace {
std::string root;
std::map<std::string, std::string> kv;
std::vector<lib::Track> media;
std::function<void()> tick_callback;
std::function<void(const std::vector<int>&)> reindex_callback;
struct Job { std::function<void()> work, done; };
std::deque<Job> jobs;
uint32_t clock_ms = 1, position = 0, duration_ms = 0;
bool running = false, paused = false, scanning = false, eof = false;
bool fail_write = false, fail_close = false, fail_sync = false;
bool fail_checkpoint = false;
int fail_rename = 0, file_writes = 0, checkpoint_writes = 0, checks = 0;
std::string last_file;
#define CHECK(x) do { if (!(x)) { std::fprintf(stderr, "FAIL line %d: %s\n", __LINE__, #x); std::abort(); } ++checks; } while (0)
void drain_one() {
    CHECK(!jobs.empty());
    auto job = std::move(jobs.front()); jobs.pop_front();
    if (job.work) job.work();
    if (job.done) job.done();
}
void drain() { int budget = 100; while (!jobs.empty() && --budget) drain_one(); CHECK(budget > 0); }
void reset_runtime() {
    // A power cut drops all outstanding jobs and volatile state, keeping SD/NVS.
    jobs.clear(); tick_callback = {}; reindex_callback = {};
    running = paused = eof = scanning = false; position = duration_ms = 0; last_file.clear();
    using namespace player;
    s_order.clear(); s_queue.clear(); s_idx = -1; s_shuffle = s_qshuf = false; s_repeat = R_OFF;
    s_version = 0; s_stream = s_file = s_loaded = s_cued = false; s_last_save = s_pending = 0;
    s_title.clear(); s_artist.clear(); s_album.clear(); s_url.clear(); s_path.clear();
    s_rng.seed(12345); s_saved.clear(); s_token = 0;
    s_session_identity = s_committed_identity = 0; s_committed_slot = -1;
    s_session_busy = s_restore_pending = false; s_session_retry_at = 0;
    s_session_pending.reset(); s_boot_snapshot.reset(); s_local_checkpoint = {}; s_boot_checkpoint = {};
    s_checkpoint_text.clear(); s_legacy_path.clear(); s_legacy_position = 0;
}
void clear_card() {
    reset_runtime(); kv.clear(); media.clear();
    std::filesystem::remove_all(root); std::filesystem::create_directories(root);
    fail_write = fail_close = fail_sync = fail_checkpoint = false; fail_rename = 0; clock_ms = 1;
}
void library(std::initializer_list<const char*> names) {
    media.clear();
    for (const auto* name : names) {
        lib::Track t; t.path = root + "/Music/" + name + ".mp3";
        t.title = name; t.album = "Album"; t.artist = "Artist"; t.dur_ms = 120000;
        media.push_back(std::move(t));
    }
}
void boot() { reset_runtime(); player::init(); }
std::vector<std::string> queue_paths() {
    std::vector<std::string> out;
    for (int id : player::queue()) { CHECK(lib::get(id)); out.push_back(lib::get(id)->path); }
    return out;
}
playback_session::Checkpoint checkpoint() {
    playback_session::Checkpoint out; CHECK(playback_session::decode_checkpoint(kv["np_session"], out)); return out;
}
void write_text(const std::string& path, const std::string& data) { std::ofstream(path, std::ios::binary) << data; }
}

extern "C" size_t __real_fwrite(const void*, size_t, size_t, FILE*);
extern "C" int __real_fclose(FILE*);
extern "C" int __real_fsync(int);
extern "C" int __real_rename(const char*, const char*);
extern "C" size_t __wrap_fwrite(const void* p, size_t size, size_t count, FILE* f) {
    ++file_writes;
    if (fail_write) { errno = ENOSPC; return 0; }
    return __real_fwrite(p, size, count, f);
}
extern "C" int __wrap_fclose(FILE* f) {
    int result = __real_fclose(f);
    if (fail_close) { errno = EIO; return EOF; }
    return result;
}
extern "C" int __wrap_fsync(int fd) {
    if (fail_sync) { errno = EIO; return -1; }
    return __real_fsync(fd);
}
extern "C" int __wrap_rename(const char* a, const char* b) {
    if (fail_rename) { --fail_rename; errno = EACCES; return -1; }
    return __real_rename(a, b);
}

namespace hal {
uint32_t millis() { return clock_ms; }
const char* fs_root() { return root.c_str(); }
int32_t kv_get_int(const char* key, int32_t def) { auto i = kv.find(key); return i == kv.end() ? def : std::stoi(i->second); }
void kv_set_int(const char* key, int32_t value) { kv[key] = std::to_string(value); }
std::string kv_get_str(const char* key, const char* def) { auto i = kv.find(key); return i == kv.end() ? def : i->second; }
void kv_set_str(const char* key, const std::string& value) {
    if (std::string(key) == "np_session") { ++checkpoint_writes; if (fail_checkpoint) return; }
    kv[key] = value;
}
bool audio_play_file(const char* path, uint32_t at) {
    last_file = path; running = true; paused = false; position = at;
    const auto* t = lib::get(lib::find_path(path)); duration_ms = t ? t->dur_ms : 0; return true;
}
bool audio_play_url(const char*) { running = true; paused = false; position = duration_ms = 0; return true; }
bool audio_is_running() { return running; }
bool audio_is_paused() { return paused; }
void audio_pause(bool value) { paused = value; }
void audio_stop() { running = paused = false; position = duration_ms = 0; }
uint32_t audio_pos_ms() { return position; }
uint32_t audio_dur_ms() { return duration_ms; }
void audio_seek(uint32_t at) { position = at; }
void audio_set_eq(int) {}
bool audio_take_eof() { return std::exchange(eof, false); }
std::string audio_stream_title() { return {}; }
void run_async(std::function<void()> work, std::function<void()> done) { jobs.push_back({std::move(work), std::move(done)}); }
}
namespace os {
void set_now_playing_state(bool, bool) {}
void on_tick(std::function<void()> callback) { tick_callback = std::move(callback); }
}
namespace lib {
const Track* get(int id) { return id >= 0 && id < int(media.size()) ? &media[id] : nullptr; }
int find_path(const std::string& path) { for (size_t i = 0; i < media.size(); ++i) if (media[i].path == path) return int(i); return -1; }
void set_bookmark(int id, uint32_t at) { if (get(id)) media[id].bookmark_ms = at; }
void mark_played(int id) { if (get(id)) ++media[id].plays; }
bool scanning() { return ::scanning; }
void on_reindex(std::function<void(const std::vector<int>&)> cb) { reindex_callback = std::move(cb); }
std::vector<int> songs_of_album(const std::string& album, const std::string& artist) {
    std::vector<int> out;
    for (size_t i = 0; i < media.size(); ++i) if (media[i].album == album && (artist.empty() || media[i].shown_artist() == artist)) out.push_back(int(i));
    return out;
}
std::vector<int> shows(Kind, const std::string& album) { return songs_of_album(album, ""); }
}

int main(int argc, char** argv) {
    CHECK(argc == 2); root = argv[1];
    // Exact custom playlist/shuffle sequence and duplicate occurrence survive a reboot.
    clear_card(); library({"A", "B", "C", "D"}); player::init();
    player::play({3, 0, 2, 0, 1}, 3, true); drain();
    player::set_shuffle(true); player::set_repeat(player::R_ALL); player::jump(3); player::seek(45678); player::pause(); drain();
    auto paths = queue_paths(); int saved_index = player::index(); auto saved_order = player::s_order;
    CHECK(checkpoint().position_ms == 45678); CHECK(checkpoint().paused);
    CHECK(!jobs.size()); boot();
    CHECK(queue_paths() == paths); CHECK(player::s_order == saved_order); CHECK(player::index() == saved_index);
    CHECK(player::shuffle() && player::queue_shuffled() && player::repeat() == player::R_ALL);
    CHECK(player::active() && !player::playing() && player::pos() == 45678);
    player::resume(); CHECK(player::playing() && position == 45678); CHECK(last_file == paths[saved_index]);
    player::set_shuffle(false); drain(); CHECK(player::queue() == saved_order);

    // Index/position/repeat/pause saves never rewrite queue files or enqueue SD jobs.
    int writes = file_writes;
    for (int i = 0; i < 20; ++i) {
        player::jump(i % 5); player::seek(1000 + i); player::pause(); player::resume();
        position = 2000 + i; clock_ms += 15001; tick_callback();
    }
    CHECK(file_writes == writes && jobs.empty());

    // Path mapping survives renumbering and deletion before a repeated current item.
    clear_card(); library({"A", "B", "C", "D"}); player::init();
    player::play({0, 1, 0, 2, 3}, 2); player::seek(33000); player::pause(); drain();
    library({"D", "C", "A"}); boot();
    CHECK((player::queue() == std::vector<int>{2, 2, 1, 0})); CHECK(player::index() == 1 && player::pos() == 33000); drain();
    // Removing the current item selects its successor at zero, paused.
    library({"D", "C"}); boot();
    CHECK((player::queue() == std::vector<int>{1, 0})); CHECK(player::index() == 0 && player::pos() == 0 && !player::playing()); drain();
    library({}); boot(); CHECK(!player::active());

    // Replaced/shortened files cannot resume beyond EOF, and explicit zero beats a stale bookmark.
    clear_card(); library({"A"}); media[0].kind = lib::K_AUDIOBOOK; player::init();
    player::play({0}, 0); player::seek(99000); player::pause(); drain(); media[0].dur_ms = 10000;
    boot(); CHECK(player::pos() == 9999); player::resume(); CHECK(position == 9999);
    player::seek(0); player::pause(); media[0].bookmark_ms = 6000; boot();
    CHECK(player::pos() == 0); player::resume(); CHECK(position == 0);
    player::seek(UINT32_MAX); CHECK(player::pos() == 9999);
    media[0].bookmark_ms = UINT32_MAX; player::play({0}, 0); CHECK(player::pos() == 0); drain();
    player::seek(8765); player::stop(); boot(); CHECK(player::pos() == 8765 && !player::playing());

    // A delayed worker sees only one queued write and the newest coalesced queue.
    clear_card(); library({"A", "B", "C", "D"}); player::init();
    player::play({0, 1}, 0); player::play({1, 2}, 1); player::play({3, 0}, 1); player::seek(12345); player::pause();
    CHECK(jobs.size() == 1 && kv["np_session"].empty());
    drain_one(); CHECK(kv["np_session"].empty() && jobs.size() == 1);
    drain(); boot(); CHECK((player::queue() == std::vector<int>{3, 0}) && player::index() == 1 && player::pos() == 12345);

    // A queued snapshot is not committed until its completion, including a power cut between write and callback.
    player::play({1, 2}, 1); CHECK(jobs.size() == 1);
    auto uncommitted = std::move(jobs.front()); jobs.pop_front(); uncommitted.work();
    boot(); CHECK((player::queue() == std::vector<int>{3, 0}) && player::pos() == 12345);

    // Storage failures never invalidate the last committed slot/checkpoint.
    for (int fault = 0; fault < 5; ++fault) {
        clear_card(); library({"A", "B", "C"}); player::init();
        player::play({0, 2}, 1); player::seek(23456); player::pause(); drain();
        std::string previous = kv["np_session"];
        player::play({1, 0}, 0); player::seek(7777); player::pause();
        fail_write = fault == 0; fail_close = fault == 1; fail_sync = fault == 2; fail_rename = fault == 3 ? 2 : 0;
        fail_checkpoint = fault == 4;
        drain(); CHECK(kv["np_session"] == previous);
        fail_write = fail_close = fail_sync = fail_checkpoint = false; fail_rename = 0;
        boot(); CHECK((player::queue() == std::vector<int>{0, 2}) && player::pos() == 23456);
    }
    // FAT rename-over-existing fallback remains safe when replacing an inactive slot.
    player::play({1, 0}, 0); drain(); player::play({2, 1}, 1); fail_rename = 1; drain();
    boot(); CHECK((player::queue() == std::vector<int>{2, 1}) && player::index() == 1);

    // A temporary video/alarm/memo cannot overwrite the local-library session.
    player::seek(34567); player::pause(); auto local = queue_paths();
    uint32_t token = player::push_state(); player::play_file("Alarm", root + "/alarm.wav"); drain();
    boot(); CHECK(queue_paths() == local && player::pos() == 34567);
    token = player::push_state(); player::play_file("Video", root + "/soundtrack.mp3"); player::pop_state(token); drain();
    boot(); CHECK(queue_paths() == local && player::pos() == 34567);

    // Initial cache miss waits for scan; fresh user playback cancels the deferred restore.
    reset_runtime(); auto real_media = media; media.clear(); scanning = true; player::init(); CHECK(player::s_restore_pending);
    media = real_media; scanning = false; reindex_callback({}); CHECK(player::active() && player::pos() == 34567);
    reset_runtime(); media.clear(); scanning = true; player::init();
    media = real_media; player::play({0}, 0); scanning = false; reindex_callback({0, 1, 2}); tick_callback(); drain();
    CHECK((player::queue() == std::vector<int>{0}) && player::pos() == 0);
    // Cancelled restore still protects its committed slot until the new commit succeeds.
    auto prior_paths = queue_paths();
    reset_runtime(); media.clear(); scanning = true; player::init(); media = real_media;
    player::play({2, 1}, 0); CHECK(jobs.size() == 1);
    uncommitted = std::move(jobs.front()); jobs.pop_front(); uncommitted.work();
    boot(); CHECK(queue_paths() == prior_paths);

    // A live rescan keeps the precise duplicate occurrence after IDs change.
    clear_card(); library({"A", "B", "C", "D"}); player::init();
    player::play({0, 1, 0, 2, 3}, 2); player::seek(9876); player::pause(); drain();
    library({"D", "C", "A"}); reindex_callback({2, -1, 1, 0}); drain();
    CHECK((player::queue() == std::vector<int>{2, 2, 1, 0}) && player::index() == 1 && player::pos() == 9876);
    boot(); CHECK((player::queue() == std::vector<int>{2, 2, 1, 0}) && player::index() == 1 && player::pos() == 9876);

    // Legacy migration is one-time. Corrupt new-format state must fail closed.
    clear_card(); library({"A", "B"}); kv["np_path"] = media[1].path; kv["np_pos"] = "7654";
    player::init(); CHECK(player::pos() == 7654 && player::index() == 1); drain(); CHECK(!kv["np_session"].empty());
    kv["np_path"] = media[0].path; kv["np_pos"] = "999"; boot(); CHECK(player::current() == 1 && player::pos() == 7654);
    std::string good_checkpoint = kv["np_session"]; kv["np_session"][12] = 'z'; boot(); CHECK(!player::active());
    kv["np_session"] = good_checkpoint; auto selected = checkpoint();
    write_text(player::session_path(selected.slot), "truncated"); boot(); CHECK(!player::active());
    // Oversized file is rejected before allocating/reading its declared contents.
    write_text(player::session_path(selected.slot), std::string(playback_session::max_file_bytes + 1, 'x'));
    boot(); CHECK(!player::active());
    // A valid but unrelated snapshot cannot borrow a checkpoint for another queue.
    playback_session::Snapshot unrelated; unrelated.order = unrelated.queue = {"/Music/A.mp3"};
    CHECK(playback_session::seal(unrelated)); CHECK(playback_session::write_inactive(player::session_path(selected.slot), unrelated));
    boot(); CHECK(!player::active());
    // A legal library can be larger than the persisted-session cap: fail closed, not a stale queue.
    clear_card(); library({"A"}); player::init();
    player::play(std::vector<int>(playback_session::max_entries + 1, 0), 0);
    CHECK(player::active() && jobs.empty()); boot(); CHECK(!player::active());
#ifdef NANO_TARGET_ESP32
    // Exercise the production scoped allocator/preflight, with a host heap-caps shim.
    clear_card(); library({"A", "B", "C"}); player::init();
    player::play({0, 1}, 1); player::seek(1234); player::pause(); drain();
    const std::string durable = kv["np_session"];
    n9_test_psram_free = 64 * 1024; n9_test_psram_largest = 32 * 1024;
    player::play({2}, 0); CHECK(jobs.empty() && kv["np_session"] == durable);
    n9_test_psram_free = n9_test_psram_largest = 8 * 1024 * 1024;
    boot(); CHECK((player::queue() == std::vector<int>{0, 1}) && player::pos() == 1234);
    CHECK(n9_test_psram_allocations > 0);
#endif

    std::filesystem::remove_all(root);
    std::printf("Playback sessions: %d behavioral checks passed\n", checks);
}
