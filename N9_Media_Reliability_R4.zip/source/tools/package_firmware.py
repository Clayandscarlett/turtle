#!/usr/bin/env python3
"""Export flash images after a PlatformIO build. Works with cores that do not emit firmware.factory.bin."""
from pathlib import Path
import hashlib, json, os, sys
root=Path(__file__).resolve().parents[1]
built=root/'firmware/.pio/build/fnk0104b'
app_path=built/'firmware.bin'
if not app_path.is_file(): raise SystemExit('Missing firmware.bin; PlatformIO build did not produce an application image.')
app=app_path.read_bytes()
if len(app)>0x600000: raise SystemExit('Application exceeds the 6 MB OTA slot.')
out=root/'bin'; out.mkdir(exist_ok=True)
items=[]
def emit(offset,name,path):
    if not path or not path.is_file(): return False
    data=path.read_bytes()
    if not data: return False
    (out/name).write_bytes(data)
    items.append({'offset':offset,'file':name,'size':len(data),'sha256':hashlib.sha256(data).hexdigest()})
    return True

# PlatformIO emits these directly on current cores.
emit('0x0','bootloader.bin',built/'bootloader.bin')
emit('0x8000','partitions.bin',built/'partitions.bin')
# boot_app0 is framework-supplied rather than build-generated on Arduino-ESP32 3.3.7.
home=Path.home()
pio_core=Path(os.environ.get('PLATFORMIO_CORE_DIR',str(home/'.platformio')))
boot_candidates=[
    built/'boot_app0.bin',
    pio_core/'packages/framework-arduinoespressif32/tools/partitions/boot_app0.bin',
]
for c in boot_candidates:
    if emit('0xe000','boot_app0.bin',c): break
emit('0x10000','update.bin',app_path)
if len(items)!=4: raise SystemExit('Missing required boot image; refusing incomplete flash package.')

boot=(out/'bootloader.bin').read_bytes()
if boot[0]!=0xE9 or boot[2]>3: raise SystemExit('Invalid ESP32 boot image header.')
flash_mode=['qio','qout','dio','dout'][boot[2]]
(out/'release.json').write_text(json.dumps({'version':'1.1.9-media-reliability-r4','board':'Freenove FNK0104B N16R8','chip':'esp32s3',
    'flash_mode':flash_mode,'flash_freq':'80m','flash_size':'16MB','images':items},indent=2)+'\n')
app_sha=hashlib.sha256(app).hexdigest()
(out/'update.bin.sha256').write_text(app_sha+'\n')
print(f'Packaged {len(items)} firmware image(s) and SHA-256 manifest: {out}')
