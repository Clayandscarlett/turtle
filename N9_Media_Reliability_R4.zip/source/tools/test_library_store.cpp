// Exercise the actual legacy library/stat store and loaders, including FAT
// rename behavior and failures after a real temporary file has been written.
#include <cassert>
#include <cstdarg>
#include <cstdio>
#include <filesystem>
#include <fstream>
#include <map>
#include <string>
#include "../ui/svc/library.cpp"

namespace fs = std::filesystem;
static std::string test_root, target, temporary;
static std::map<FILE*, std::string> open_paths;
enum class Fault { None, Open, Write, ErrorFlag, Flush, Sync, Close, RemoveBackup, RetainRename, CommitRename, Read, ReadClose, RemoveInvalid };
static Fault fault = Fault::None;
static bool fired = false, read_failed = false;
static int writes_before_failure = 0;
static int temporary_fd = -1;
static unsigned cases = 0;

namespace hal {
const char* fs_root() { return test_root.c_str(); }
time_t now() { return 1700000000; }
void run_async(std::function<void()> work, std::function<void()> done) { work(); if (done) done(); }
}

static bool fail(Fault wanted) {
    if (fault != wanted || fired) return false;
    fired = true; errno = EIO; return true;
}
static bool is_temporary(FILE* f) { auto i = open_paths.find(f); return i != open_paths.end() && i->second == temporary; }
static bool is_primary(FILE* f) { auto i = open_paths.find(f); return i != open_paths.end() && i->second == target; }
extern "C" FILE* __real_fopen(const char*, const char*);
extern "C" FILE* __wrap_fopen(const char* path, const char* mode) {
    if (path == temporary && mode[0] == 'w' && fail(Fault::Open)) return nullptr;
    FILE* f = __real_fopen(path, mode);
    if (f) { open_paths[f] = path; if (path == temporary) temporary_fd = fileno(f); }
    return f;
}
extern "C" int __wrap_fprintf(FILE* f, const char* format, ...) {
    if (is_temporary(f) && fault == Fault::Write && !fired) {
        if (writes_before_failure-- == 0 && fail(Fault::Write)) { errno = ENOSPC; return -1; }
    }
    va_list args; va_start(args, format); int result = vfprintf(f, format, args); va_end(args); return result;
}
extern "C" int __real_ferror(FILE*);
extern "C" int __wrap_ferror(FILE* f) {
    if ((is_temporary(f) && fail(Fault::ErrorFlag)) || (is_primary(f) && read_failed)) return 1;
    return __real_ferror(f);
}
extern "C" int __real_fflush(FILE*);
extern "C" int __wrap_fflush(FILE* f) { int result = __real_fflush(f); return is_temporary(f) && fail(Fault::Flush) ? EOF : result; }
extern "C" int __real_fsync(int);
extern "C" int __wrap_fsync(int fd) { return fd == temporary_fd && fail(Fault::Sync) ? -1 : __real_fsync(fd); }
extern "C" int __real_fclose(FILE*);
extern "C" int __wrap_fclose(FILE* f) {
    const bool reject = (is_temporary(f) && fail(Fault::Close)) || (is_primary(f) && fail(Fault::ReadClose));
    open_paths.erase(f); int result = __real_fclose(f); return reject ? EOF : result;
}
extern "C" char* __real_fgets(char*, int, FILE*);
extern "C" char* __wrap_fgets(char* text, int size, FILE* f) {
    if (is_primary(f) && fail(Fault::Read)) { read_failed = true; return nullptr; }
    return __real_fgets(text, size, f);
}
extern "C" int __real_remove(const char*);
extern "C" int __wrap_remove(const char* path) {
    if ((path == target + ".bak" && fail(Fault::RemoveBackup)) || (path == target && fail(Fault::RemoveInvalid))) return -1;
    return __real_remove(path);
}
extern "C" int __real_rename(const char*, const char*);
extern "C" int __wrap_rename(const char* from, const char* to) {
    if ((from == target && to == target + ".bak" && fail(Fault::RetainRename)) ||
        (from == temporary && to == target && fail(Fault::CommitRename))) return -1;
    // FAT-style rename cannot replace an existing destination.
    if (access(to, F_OK) == 0) { errno = EEXIST; return -1; }
    return __real_rename(from, to);
}

static void clear_fault() { fault = Fault::None; fired = false; read_failed = false; temporary_fd = -1; }
static lib::Track track(const char* leaf, const char* title) {
    lib::Track t; t.path = test_root + "/Podcasts/Show/" + leaf; t.title = title;
    t.artist = "A\\B\tC\nD"; t.album = "Show"; t.kind = lib::K_PODCAST;
    t.size = 81234; t.mtime = 1700000001; t.dur_ms = 7654321; t.added = 1700000010; return t;
}
static std::vector<lib::Track> old_tracks() { return {track("one.mp3", "Previous one"), track("two.mp3", "Previous two")}; }
static std::vector<lib::Track> new_tracks() { return {track("one.mp3", "New one"), track("two.mp3", "New two")}; }
static void old_stats() {
    lib::s_stats.clear(); lib::s_stats["/Podcasts/Show/one.mp3"] = {11, 4, 123456};
    lib::s_stats["/Podcasts/Show/two.mp3"] = {9, 5, 999999};
}
static void new_stats() {
    lib::s_stats.clear(); lib::s_stats["/Podcasts/Show/one.mp3"] = {12, 3, 234567};
    lib::s_stats["/Podcasts/Show/two.mp3"] = {10, 2, 888888};
}
static void seed(bool stats, const std::string& name) {
    clear_fault(); test_root = name; target = test_root + (stats ? "/.nanoos/stats.txt" : "/.nanoos/library.db");
    temporary = test_root + (stats ? "/.nanoos/stats.tmp" : "/.nanoos/library.tmp");
    fs::remove_all(test_root); fs::create_directories(test_root);
    lib::s_db_store = {}; lib::s_stats_store = {}; lib::s_stats.clear();
    // Two successful saves create both primary and backup using the production transaction.
    old_stats(); assert(lib::save_stats()); assert(lib::save_db(old_tracks()));
    assert(lib::save_stats()); assert(lib::save_db(old_tracks()));
    assert(fs::exists(target) && fs::exists(target + ".bak"));
}
static bool save_new(bool stats) { if (stats) { new_stats(); return lib::save_stats(); } return lib::save_db(new_tracks()); }
static void assert_loaded(bool stats, bool newer) {
    clear_fault();
    if (stats) {
        lib::s_stats.clear(); lib::load_stats(); assert(lib::s_stats.size() == 2);
        const auto& a = lib::s_stats.at("/Podcasts/Show/one.mp3");
        const auto& b = lib::s_stats.at("/Podcasts/Show/two.mp3");
        assert(a.plays == (newer ? 12u : 11u) && a.rating == (newer ? 3 : 4) && a.bookmark == (newer ? 234567u : 123456u));
        assert(b.plays == (newer ? 10u : 9u) && b.rating == (newer ? 2 : 5) && b.bookmark == (newer ? 888888u : 999999u));
    } else {
        std::vector<lib::Track> v; lib::load_db(v); assert(v.size() == 2);
        assert(v[0].title == (newer ? "New one" : "Previous one") && v[1].title == (newer ? "New two" : "Previous two"));
        assert(v[0].artist == "A\\B\tC\nD" && v[0].dur_ms == 7654321 && v[0].kind == lib::K_PODCAST);
    }
}
static void overwrite(const std::string& path, const std::string& bytes) { std::ofstream f(path, std::ios::binary | std::ios::trunc); f << bytes; assert(f.good()); }
int main(int argc, char** argv) {
    assert(argc == 2); const std::string base = argv[1];
    const Fault failures[] = {Fault::Open, Fault::Write, Fault::ErrorFlag, Fault::Flush, Fault::Sync, Fault::Close, Fault::RemoveBackup, Fault::RetainRename, Fault::CommitRename};
    for (bool stats : {false, true}) {
        for (Fault f : failures) {
            seed(stats, base + "/fault-" + std::to_string(cases)); fault = f; writes_before_failure = 1;
            assert(!save_new(stats)); assert(fired); assert((stats ? lib::s_stats_store : lib::s_db_store).failed);
            assert_loaded(stats, false); assert(save_new(stats)); assert_loaded(stats, true); ++cases;
        }
        for (Fault f : {Fault::Read, Fault::ReadClose}) {
            seed(stats, base + "/read-" + std::to_string(cases)); fault = f;
            if (stats) { lib::s_stats.clear(); lib::load_stats(); assert(lib::s_stats.size() == 2 && lib::s_stats.at("/Podcasts/Show/one.mp3").bookmark == 123456); }
            else { std::vector<lib::Track> v; lib::load_db(v); assert(v.size() == 2 && v[0].title == "Previous one"); }
            assert(fired && (stats ? lib::s_stats_store : lib::s_db_store).backup_valid);
            clear_fault(); assert(save_new(stats)); assert_loaded(stats, true); ++cases;
        }
        // Interrupted rotation: a complete backup and an uncommitted temporary.
        seed(stats, base + "/interrupted-" + std::to_string(cases)); fs::remove(target);
        overwrite(temporary, stats ? "/Podcasts/Show/one.mp3\t77\t1\t777777\n" : "NANOLIB3\n");
        assert_loaded(stats, false); assert(save_new(stats)); assert_loaded(stats, true); ++cases;
        // A malformed primary must not leak partial rows into recovered data.
        for (const std::string& bad : {std::string("incomplete"), std::string("NANOLIB3\ntruncated"), std::string(128 * 1024 + 1, 'x') + "\n"}) {
            seed(stats, base + "/malformed-" + std::to_string(cases)); overwrite(target, bad);
            assert_loaded(stats, false); assert(save_new(stats)); assert_loaded(stats, true); ++cases;
        }
        seed(stats, base + "/partial-dataset-" + std::to_string(cases)); assert(save_new(stats));
        { std::ofstream f(target, std::ios::binary | std::ios::app); f << "truncated final row"; assert(f.good()); }
        assert_loaded(stats, false); assert(save_new(stats)); assert_loaded(stats, true); ++cases;
        // Removing a known-invalid primary must also preserve the good backup on failure.
        seed(stats, base + "/invalid-remove-" + std::to_string(cases)); overwrite(target, "damaged");
        assert_loaded(stats, false); fault = Fault::RemoveInvalid;
        assert(!save_new(stats)); assert(fired); assert_loaded(stats, false); ++cases;
        // A staging file can never replace the only committed copy during startup.
        seed(stats, base + "/no-committed-" + std::to_string(cases)); fs::copy_file(target, temporary, fs::copy_options::overwrite_existing);
        fs::remove(target); fs::remove(target + ".bak");
        if (stats) { lib::s_stats.clear(); lib::load_stats(); assert(lib::s_stats.empty()); }
        else { std::vector<lib::Track> v; lib::load_db(v); assert(v.empty()); }
        ++cases;
    }
    assert(open_paths.empty());
    printf("PASS: %u actual library/stat save, recovery, FAT rename and injected I/O failure cases; bookmarks, ratings and play counts survive reload\n", cases);
}
