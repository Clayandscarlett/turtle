# N9 public trust anchors

These files reproduce the firmware's existing public CA identities as full DER
certificates for standard mbedTLS verification. They add **no trust anchors**.

`mozilla-public-roots.pem` is the unmodified public Mozilla-root extraction from
certifi commit `9d0a8f1f3a0d6b2e38d5773db7afe1a37e4527b6`, downloaded from:

https://raw.githubusercontent.com/certifi/python-certifi/9d0a8f1f3a0d6b2e38d5773db7afe1a37e4527b6/certifi/cacert.pem

Its SHA-256 is
`9cc2a774b5198dcff14d9be1e66091f538975d867ce029a96bce15a55dfd730f`.
Certifi's upstream license is preserved in `LICENSE.certifi`.

`trust-anchor-reference.bin` is the exact compressed subject/public-key bundle
already shipped with N9. It originated from ESP32CertBundle commit
`c5e16b497a877b2627ebcce99fc283ca36ffaa04`, generated September 25, 2026 using
curl's Mozilla root extraction. Its SHA-256 is
`2af490c0dbd133a23e122f8eb834bf0f083fbcd9e906f4449f60b7e32f926a56`.
It contains 121 roots in the ESP-IDF 5.5 offset-table format.

The upstream PEM has exactly the same 121 unique DER-subject/SPKI pairs. The
generator rejects additions, omissions, duplicate anchors, replacement keys,
invalid CA constraints, invalid self-signatures, or malformed reference offsets.
The individual certificate fingerprints and offsets are recorded in
`trusted_roots_manifest.json`. No certificate from the cloud environment's local
system or Python trust stores is used; those stores can contain private proxy CAs.

Reproduce or check output offline from the project root, with Python and
`cryptography >= 41` installed:

```sh
python3 tools/build_trusted_roots.py
python3 tools/build_trusted_roots.py --check
python3 tests/trusted_roots_generation_test.py
```

The generated `firmware/src/trusted_roots.h` stores 129,143 DER bytes in immutable
flash, with an offset/length table for `mbedtls_x509_crt_parse_der_nocopy`. Inline
constexpr arrays provide one backing object across C++ translation units. Its
lifetime is the entire firmware run. Parsing and validation of these certificates
occur through normal mbedTLS code; this file does not bypass server validation.

Three existing roots have historical SHA-1 self-signatures. The generator checks
their signatures directly because newer cryptography wrappers restrict SHA-1.
This does not grant weak signatures to server certificates or change the TLS
verifier's policy. Future trust updates require deliberately changing the pinned
reference and provenance; simply replacing the PEM is rejected.
