#!/usr/bin/env python3
"""Reproduce full DER roots without changing N9's existing trust anchors.

This command is offline: it reads the pinned upstream PEM and the original
compressed bundle kept in tools/certs. Use --check to validate committed output.
Requires cryptography >= 41. Existing root self-signatures may use SHA-1; that
does not change the TLS verifier's policy for server certificates.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import pathlib
import struct
import warnings

from cryptography import x509
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ec, ed25519, ed448, rsa


ROOT = pathlib.Path(__file__).resolve().parents[1]
CERTS = ROOT / "tools" / "certs"
SOURCE_COMMIT = "9d0a8f1f3a0d6b2e38d5773db7afe1a37e4527b6"
SOURCE_URL = (
    "https://raw.githubusercontent.com/certifi/python-certifi/"
    + SOURCE_COMMIT + "/certifi/cacert.pem"
)
SOURCE_SHA256 = "9cc2a774b5198dcff14d9be1e66091f538975d867ce029a96bce15a55dfd730f"
REFERENCE_SHA256 = "2af490c0dbd133a23e122f8eb834bf0f083fbcd9e906f4449f60b7e32f926a56"
EXPECTED_ROOTS = 121

# Mozilla includes a historical root with a non-positive serial number.
# Preserve the exact existing anchor; never accept additional roots implicitly.
warnings.filterwarnings("ignore", message="Parsed a serial number which wasn't positive.*")


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def parse_reference(data: bytes) -> list[tuple[bytes, bytes]]:
    """Validate IDF 5.5's complete offset table and return subject/SPKI pairs."""
    if len(data) < 8:
        raise ValueError("Reference bundle is truncated")
    first, = struct.unpack_from("<I", data)
    if not first or first % 4 or first >= len(data):
        raise ValueError("Invalid reference offset table")
    count = first // 4
    if count != EXPECTED_ROOTS:
        raise ValueError(f"Expected {EXPECTED_ROOTS} existing anchors, got {count}")
    offsets = struct.unpack_from(f"<{count}I", data)
    pairs = []
    expected_offset = first
    for index, offset in enumerate(offsets):
        if offset != expected_offset or offset + 4 > len(data):
            raise ValueError(f"Invalid reference entry offset {index}")
        name_length, key_length = struct.unpack_from("<HH", data, offset)
        end = offset + 4 + name_length + key_length
        if not name_length or not key_length or end > len(data):
            raise ValueError(f"Invalid reference entry lengths {index}")
        name = data[offset + 4:offset + 4 + name_length]
        key = data[offset + 4 + name_length:end]
        pairs.append((name, key))
        expected_offset = end
    if expected_offset != len(data):
        raise ValueError("Unexpected trailing reference data")
    if len(set(name for name, _ in pairs)) != count:
        raise ValueError("Duplicate reference subject")
    if [name for name, _ in pairs] != sorted(name for name, _ in pairs):
        raise ValueError("Reference subjects are not sorted")
    return pairs


def verify_root(cert: x509.Certificate) -> None:
    """Verify CA constraints and every existing root's real self-signature."""
    if cert.subject != cert.issuer:
        raise ValueError(f"Root is not self-issued: {cert.subject.rfc4514_string()}")
    if not cert.extensions.get_extension_for_class(x509.BasicConstraints).value.ca:
        raise ValueError("Trust anchor does not have CA BasicConstraints")
    try:
        usage = cert.extensions.get_extension_for_class(x509.KeyUsage).value
        if not usage.key_cert_sign:
            raise ValueError("Trust anchor forbids certificate signing")
    except x509.ExtensionNotFound:
        pass
    key = cert.public_key()
    if isinstance(key, rsa.RSAPublicKey):
        key.verify(cert.signature, cert.tbs_certificate_bytes,
                   cert.signature_algorithm_parameters, cert.signature_hash_algorithm)
    elif isinstance(key, ec.EllipticCurvePublicKey):
        key.verify(cert.signature, cert.tbs_certificate_bytes,
                   ec.ECDSA(cert.signature_hash_algorithm))
    elif isinstance(key, (ed25519.Ed25519PublicKey, ed448.Ed448PublicKey)):
        key.verify(cert.signature, cert.tbs_certificate_bytes)
    else:
        raise ValueError("Unsupported trust anchor public key")


def load_trusted_roots(pem: bytes, reference: bytes) -> list[x509.Certificate]:
    reference_pairs = parse_reference(reference)
    certificates = x509.load_pem_x509_certificates(pem)
    by_pair = {}
    for cert in certificates:
        pair = (cert.subject.public_bytes(), cert.public_key().public_bytes(
            serialization.Encoding.DER, serialization.PublicFormat.SubjectPublicKeyInfo))
        if pair in by_pair:
            raise ValueError("Duplicate source trust anchor")
        verify_root(cert)
        by_pair[pair] = cert
    # Exact equality is intentional: a refresh may neither add a CA nor replace
    # a key under an existing subject. Both require a separately reviewed change.
    if set(by_pair) != set(reference_pairs):
        missing = len(set(reference_pairs) - set(by_pair))
        extra = len(set(by_pair) - set(reference_pairs))
        raise ValueError(f"Trust anchor identity mismatch: missing={missing} extra={extra}")
    return [by_pair[pair] for pair in reference_pairs]


def render(certificates: list[x509.Certificate]) -> tuple[bytes, bytes]:
    blob = bytearray()
    spans = []
    manifest_roots = []
    for cert in certificates:
        der = cert.public_bytes(serialization.Encoding.DER)
        spans.append((len(blob), len(der)))
        blob.extend(der)
        manifest_roots.append({
            "subject": cert.subject.rfc4514_string(),
            "certificate_sha256": cert.fingerprint(hashes.SHA256()).hex(),
            "subject_der_sha256": digest(cert.subject.public_bytes()),
            "spki_sha256": digest(cert.public_key().public_bytes(
                serialization.Encoding.DER, serialization.PublicFormat.SubjectPublicKeyInfo)),
            "offset": spans[-1][0], "length": len(der),
        })
    lines = [
        "// Generated by tools/build_trusted_roots.py; do not edit.",
        "// Full DER encodings of the EXACT 121 existing compressed trust anchors.",
        f"// Source SHA-256: {SOURCE_SHA256}",
        "#pragma once", "#include <cstddef>", "#include <cstdint>",
        "namespace n9tls {",
        "struct TrustedRootDer { uint32_t offset; uint32_t length; };",
        "inline constexpr unsigned char trusted_root_der[] = {",
    ]
    for offset in range(0, len(blob), 16):
        lines.append("    " + ", ".join(f"0x{b:02x}" for b in blob[offset:offset + 16]) + ",")
    lines.extend(["};", "inline constexpr TrustedRootDer trusted_roots[] = {"])
    lines.extend(f"    {{{offset}u, {length}u}}," for offset, length in spans)
    lines.extend([
        "};", f"inline constexpr size_t trusted_root_count = {len(spans)};",
        "static_assert(sizeof(trusted_roots) / sizeof(trusted_roots[0]) == trusted_root_count);",
        f"static_assert(sizeof(trusted_root_der) == {len(blob)}u);",
        "} // namespace n9tls", "",
    ])
    header = "\n".join(lines).encode()
    metadata = {
        "format": 1, "purpose": "full DER representation of unchanged N9 public trust anchors",
        "source_repository": "https://github.com/certifi/python-certifi",
        "source_commit": SOURCE_COMMIT, "source_url": SOURCE_URL,
        "source_pem_sha256": SOURCE_SHA256, "source_license": "MPL-2.0",
        "reference_bundle_source": "tanakamasayuki/ESP32CertBundle@c5e16b497a877b2627ebcce99fc283ca36ffaa04",
        "reference_bundle_date": "2026-09-25", "reference_bundle_sha256": REFERENCE_SHA256,
        "reference_bundle_format": "ESP-IDF 5.5 little-endian subject/SPKI offset table",
        "root_count": len(spans), "der_bytes": len(blob), "der_sha256": digest(blob),
        "generated_header_sha256": digest(header), "roots": manifest_roots,
    }
    return header, (json.dumps(metadata, indent=2, ensure_ascii=False) + "\n").encode()


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--check", action="store_true", help="Verify output without writing files")
    args = parser.parse_args()
    pem = (CERTS / "mozilla-public-roots.pem").read_bytes()
    reference = (CERTS / "trust-anchor-reference.bin").read_bytes()
    if digest(pem) != SOURCE_SHA256:
        raise SystemExit("Pinned upstream PEM checksum mismatch")
    if digest(reference) != REFERENCE_SHA256:
        raise SystemExit("Existing anchor reference checksum mismatch")
    certificates = load_trusted_roots(pem, reference)
    header, metadata = render(certificates)
    for destination, contents in (
        (ROOT / "firmware" / "src" / "trusted_roots.h", header),
        (CERTS / "trusted_roots_manifest.json", metadata),
    ):
        if args.check:
            if not destination.exists() or destination.read_bytes() != contents:
                raise SystemExit(f"Generated output differs: {destination}")
        else:
            destination.write_bytes(contents)
    print(f"Verified {len(certificates)} CA self-signatures and exact existing anchor identities; "
          f"{'checked' if args.check else 'generated'} reproducible full DER roots")


if __name__ == "__main__":
    main()
