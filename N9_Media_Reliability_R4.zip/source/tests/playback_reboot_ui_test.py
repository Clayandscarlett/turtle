#!/usr/bin/env python3
"""Restart the real UI process and verify its exact persisted playlist via controls.

Uses disposable simulator media. Audio is simulated; this is not a physical
power-cycle or speaker test. Leak checking is disabled, matching the UI runner.
"""
import argparse
import os
from pathlib import Path
import runpy
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parents[1]


def run(simulator, output):
    card = output / "card"
    fixture = runpy.run_path(str(ROOT / "tests/media_reindex_test.py"))["fixture"]
    fixture(card)
    scenarios = {
        "save": "launch music\nclick-media-label Playlists\nwait 300\n"
                "click-media-label Favorites\nwait 300\nclick-media-label Track03\n"
                "wait 1000\nexpect-current-path Music/Track03.wav\nhome\n"
                "tap 194 65\nwait 300\nexpect-playing 0\n",
        "restore": "wait 1200\nexpect-current-path Music/Track03.wav\nexpect-playing 0\n"
                   "tap 226 65\nwait 300\nexpect-current-path Music/Track01.wav\n"
                   "expect-playing 0\ntap 194 65\nwait 300\nexpect-playing 1\n"
                   "tap 226 65\nwait 300\nexpect-current-path Music/Track03.wav\n",
    }
    env = dict(os.environ, NANO_SDROOT=str(card), ASAN_OPTIONS="detect_leaks=0:halt_on_error=1")
    for name, commands in scenarios.items():
        script = output / (name + ".txt")
        script.write_text(commands)
        result = subprocess.run([str(simulator), str(script), str(output / name)],
                                env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
        (output / (name + ".log")).write_text(result.stdout)
        if result.returncode or "unknown command:" in result.stdout:
            raise SystemExit(name + " FAIL\n" + result.stdout)
        print(name, "PASS", flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sim", required=True, type=Path)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    if args.output:
        args.output.mkdir(parents=True, exist_ok=False)
        run(args.sim.resolve(), args.output.resolve())
    else:
        with tempfile.TemporaryDirectory(prefix="n9-playback-ui-reboot-") as directory:
            run(args.sim.resolve(), Path(directory))
