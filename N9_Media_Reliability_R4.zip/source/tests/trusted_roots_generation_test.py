#!/usr/bin/env python3
"""Exercise public-root identity, integrity and deterministic DER generation."""
import datetime
import importlib.util
import pathlib
import unittest

from cryptography import x509
from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.x509.oid import NameOID


ROOT = pathlib.Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("root_generator", ROOT / "tools" / "build_trusted_roots.py")
generator = importlib.util.module_from_spec(spec)
spec.loader.exec_module(generator)


class TrustedRootsGenerationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.pem = (generator.CERTS / "mozilla-public-roots.pem").read_bytes()
        cls.reference = (generator.CERTS / "trust-anchor-reference.bin").read_bytes()
        cls.certs = x509.load_pem_x509_certificates(cls.pem)

    def test_exact_pinned_source_and_existing_anchor_coverage(self):
        self.assertEqual(generator.digest(self.pem), generator.SOURCE_SHA256)
        self.assertEqual(generator.digest(self.reference), generator.REFERENCE_SHA256)
        roots = generator.load_trusted_roots(self.pem, self.reference)
        self.assertEqual(len(roots), 121)

    def test_committed_outputs_are_reproducible(self):
        roots = generator.load_trusted_roots(self.pem, self.reference)
        header, manifest = generator.render(roots)
        self.assertEqual(header, (ROOT / "firmware" / "src" / "trusted_roots.h").read_bytes())
        self.assertEqual(manifest, (generator.CERTS / "trusted_roots_manifest.json").read_bytes())

    def test_reject_missing_existing_anchor(self):
        pem = b"".join(c.public_bytes(serialization.Encoding.PEM) for c in self.certs[1:])
        with self.assertRaisesRegex(ValueError, "identity mismatch: missing=1 extra=0"):
            generator.load_trusted_roots(pem, self.reference)

    def test_reject_duplicate_anchor(self):
        with self.assertRaisesRegex(ValueError, "Duplicate source trust anchor"):
            generator.load_trusted_roots(
                self.pem + self.certs[0].public_bytes(serialization.Encoding.PEM), self.reference)

    def test_reject_valid_but_unapproved_extra_ca(self):
        key = ec.generate_private_key(ec.SECP256R1())
        name = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, "Unapproved Test CA")])
        now = datetime.datetime.now(datetime.timezone.utc)
        cert = (x509.CertificateBuilder().subject_name(name).issuer_name(name)
                .public_key(key.public_key()).serial_number(123)
                .not_valid_before(now - datetime.timedelta(days=1))
                .not_valid_after(now + datetime.timedelta(days=1))
                .add_extension(x509.BasicConstraints(ca=True, path_length=None), critical=True)
                .sign(key, hashes.SHA256()))
        with self.assertRaisesRegex(ValueError, "identity mismatch: missing=0 extra=1"):
            generator.load_trusted_roots(self.pem + cert.public_bytes(serialization.Encoding.PEM), self.reference)

    def test_reject_existing_subject_with_changed_key(self):
        pairs = generator.parse_reference(self.reference)
        data = bytearray(self.reference)
        name, key = pairs[0]
        key_start = len(pairs) * 4 + 4 + len(name)
        data[key_start + len(key) - 1] ^= 1
        with self.assertRaisesRegex(ValueError, "identity mismatch: missing=1 extra=1"):
            generator.load_trusted_roots(self.pem, bytes(data))

    def test_reject_corrupt_root_self_signature(self):
        encoded = bytearray(self.certs[0].public_bytes(serialization.Encoding.DER))
        encoded[-1] ^= 1
        corrupted = x509.load_der_x509_certificate(bytes(encoded))
        with self.assertRaises(InvalidSignature):
            generator.verify_root(corrupted)

    def test_reject_reference_truncation_and_trailing_data(self):
        for data in (b"", self.reference[:-1], self.reference + b"\x00"):
            with self.subTest(length=len(data)), self.assertRaises(ValueError):
                generator.parse_reference(data)

    def test_reject_reference_offset_corruption(self):
        data = bytearray(self.reference)
        data[4] ^= 1
        with self.assertRaisesRegex(ValueError, "entry offset"):
            generator.parse_reference(bytes(data))


if __name__ == "__main__":
    unittest.main()
