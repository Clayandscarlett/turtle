#!/usr/bin/env python3
"""Fault-test the actual legacy library and listening-stat persistence code."""
from pathlib import Path
import subprocess
import tempfile

root = Path(__file__).resolve().parents[1]
wrapped = ["fopen", "fprintf", "ferror", "fflush", "fsync", "fclose", "fgets", "remove", "rename"]
with tempfile.TemporaryDirectory(prefix="n9-library-store-") as directory:
    binary = Path(directory) / "library-store-test"
    subprocess.run([
        "g++", "-std=c++17", "-Wall", "-Wextra", "-fno-builtin",
        "-fsanitize=address,undefined", "-fno-omit-frame-pointer",
        str(root / "tools/test_library_store.cpp"),
        *["-Wl,--wrap=" + name for name in wrapped], "-o", str(binary),
    ], check=True)
    subprocess.run([str(binary), str(Path(directory) / "card")], check=True)
