#pragma once
#include <cstddef>
#include <cstdint>
#include <memory>
#include <string>
using esp_err_t = int;
inline constexpr esp_err_t ESP_OK = 0;
inline constexpr int MBEDTLS_ERR_X509_BAD_INPUT_DATA = -0x2800;
inline constexpr int MBEDTLS_ERR_SSL_TIMEOUT = -0x6800;
inline constexpr int MBEDTLS_SSL_VERIFY_REQUIRED = 2;
#define MBEDTLS_SSL_RENEGOTIATION 1
inline constexpr int MBEDTLS_SSL_RENEGOTIATION_DISABLED = 0;
struct IPAddress {};
struct mbedtls_x509_name { const char* text = nullptr; };
struct mbedtls_x509_crt {
    mbedtls_x509_name issuer;
    mbedtls_x509_name subject;
    int version = 0;
    mbedtls_x509_crt* next = nullptr;
    const unsigned char* raw = nullptr;
};
using verify_callback = int (*)(void*, mbedtls_x509_crt*, int, uint32_t*);
struct mbedtls_ssl_config {
    verify_callback verify = nullptr;
    void* context = nullptr;
    mbedtls_x509_crt* ca_chain = nullptr;
    int authmode = -1;
    int renegotiation = -1;
};
struct sslclient_context {
    esp_err_t (*bundle_attach_cb)(void*) = nullptr;
    int socket = -1;
    int last_error = 0;
};
struct SerialStub {
    std::string output;
    void printf(const char* format, ...);
};
extern SerialStub Serial;
class NetworkClientSecure {
protected:
    bool _use_insecure = false;
    bool _use_ca_bundle = false;
    std::shared_ptr<sslclient_context> sslclient = std::make_shared<sslclient_context>();
public:
    virtual ~NetworkClientSecure() = default;
    virtual void stop() {
        // Match the pinned SDK bug: stop wipes callback and sets socket to zero.
        *sslclient = {};
        sslclient->socket = 0;
    }
    virtual int connect(IPAddress ip, uint16_t port);
    virtual int connect(IPAddress ip, uint16_t port, int32_t timeout) { return connect(ip, port); }
    virtual int connect(const char* host, uint16_t port);
    virtual int connect(const char* host, uint16_t port, int32_t timeout) { return connect(host, port); }
    int startTLS();
    sslclient_context* test_context() { return sslclient.get(); }
    bool test_insecure() const { return _use_insecure; }
    bool test_bundle_enabled() const { return _use_ca_bundle; }
};
void mbedtls_ssl_conf_verify(mbedtls_ssl_config*, verify_callback, void*);
void mbedtls_ssl_conf_ca_chain(mbedtls_ssl_config*, mbedtls_x509_crt*, void*);
void mbedtls_ssl_conf_authmode(mbedtls_ssl_config*, int);
void mbedtls_ssl_conf_renegotiation(mbedtls_ssl_config*, int);
void mbedtls_x509_crt_init(mbedtls_x509_crt*);
void mbedtls_x509_crt_free(mbedtls_x509_crt*);
int mbedtls_x509_crt_parse_der_nocopy(mbedtls_x509_crt*, const unsigned char*, size_t);
