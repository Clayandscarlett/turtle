#include "tls_client.h"
#include "../../firmware/src/trusted_roots.h"
#include <algorithm>
#include <atomic>
#include <cassert>
#include <chrono>
#include <cstdarg>
#include <cstdio>
#include <cstdlib>
#include <mutex>
#include <thread>

SerialStub Serial;
static int parse_calls = 0;
static int free_calls = 0;
static int fail_parse = -1;
static int register_calls = 0;
static std::mutex serial_mutex;
static std::atomic<int> active_handshakes{0};
static std::atomic<int> maximum_handshakes{0};

void SerialStub::printf(const char* format, ...) {
    char buffer[1024];
    va_list arguments;
    va_start(arguments, format);
    int count = vsnprintf(buffer, sizeof buffer, format, arguments);
    va_end(arguments);
    assert(count >= 0 && count < int(sizeof buffer));
    std::lock_guard<std::mutex> lock(serial_mutex);
    output.append(buffer, size_t(count));
}
void mbedtls_x509_crt_init(mbedtls_x509_crt* chain) { *chain = {}; }
void mbedtls_x509_crt_free(mbedtls_x509_crt* chain) {
    ++free_calls;
    for (auto* node = chain->next; node;) {
        auto* next = node->next;
        delete node;
        node = next;
    }
    *chain = {};
}
int mbedtls_x509_crt_parse_der_nocopy(mbedtls_x509_crt* chain, const unsigned char* bytes, size_t size) {
    const int index = parse_calls++;
    assert(index < int(n9tls::trusted_root_count));
    const auto& expected = n9tls::trusted_roots[index];
    assert(bytes == n9tls::trusted_root_der + expected.offset && size == expected.length);
    if (index == fail_parse) return -0x2180;
    while (chain->version != 0) {
        if (!chain->next) chain->next = new mbedtls_x509_crt{};
        chain = chain->next;
    }
    chain->version = 3;
    chain->raw = bytes;
    return 0;
}
void mbedtls_ssl_conf_verify(mbedtls_ssl_config* config, verify_callback callback, void* context) {
    ++register_calls;
    config->verify = callback;
    config->context = context;
}
void mbedtls_ssl_conf_ca_chain(mbedtls_ssl_config* config, mbedtls_x509_crt* chain, void* crl) {
    assert(crl == nullptr);
    config->ca_chain = chain;
}
void mbedtls_ssl_conf_authmode(mbedtls_ssl_config* config, int mode) { config->authmode = mode; }
void mbedtls_ssl_conf_renegotiation(mbedtls_ssl_config* config, int mode) { config->renegotiation = mode; }
int mbedtls_x509_dn_gets(char* output, size_t size, const mbedtls_x509_name* name) {
    return snprintf(output, size, "%s", name->text);
}
static int fake_handshake(sslclient_context* context) {
    assert(context->bundle_attach_cb == n9tls::attach_with_diagnostics);
    mbedtls_ssl_config config;
    assert(context->bundle_attach_cb(&config) == ESP_OK);
    assert(config.authmode == MBEDTLS_SSL_VERIFY_REQUIRED);
    assert(config.renegotiation == MBEDTLS_SSL_RENEGOTIATION_DISABLED);
    int active = ++active_handshakes;
    int maximum = maximum_handshakes.load();
    while (maximum < active && !maximum_handshakes.compare_exchange_weak(maximum, active)) {}
    std::this_thread::sleep_for(std::chrono::milliseconds(10));
    --active_handshakes;
    return 1;
}
int NetworkClientSecure::connect(IPAddress, uint16_t) { return fake_handshake(sslclient.get()); }
int NetworkClientSecure::connect(const char*, uint16_t) { return fake_handshake(sslclient.get()); }
int NetworkClientSecure::startTLS() { return fake_handshake(sslclient.get()); }

int main(int argc, char** argv) {
    if (argc > 1) {
        fail_parse = std::atoi(argv[1]);
        n9tls::Client client;
        assert(!client.configureTrust());
        assert(!client.test_bundle_enabled());
        assert(client.test_context()->bundle_attach_cb == nullptr);
        assert(parse_calls == fail_parse + 1 && free_calls == 1);
        assert(n9tls::attach_with_diagnostics(nullptr) < 0);
        assert(!client.configureTrust());
        assert(parse_calls == fail_parse + 1 && register_calls == 0);
        return 0;
    }
    assert(n9tls::root_count() == 121);
    n9tls::Client first;
    n9tls::Client second;
    std::thread init_one([&] { assert(first.configureTrust()); });
    std::thread init_two([&] { assert(second.configureTrust()); });
    init_one.join(); init_two.join();
    assert(first.configureTrust() && second.configureTrust() && parse_calls == 121);
    assert(!first.test_insecure() && first.test_bundle_enabled());
    mbedtls_ssl_config config;
    assert(first.test_context()->bundle_attach_cb(&config) == ESP_OK);
    assert(config.authmode == MBEDTLS_SSL_VERIFY_REQUIRED && config.ca_chain != nullptr);
    assert(config.renegotiation == MBEDTLS_SSL_RENEGOTIATION_DISABLED);
    assert(config.verify != nullptr && config.context == nullptr);
    mbedtls_x509_crt certificate{{"CN=Test root"}, {"CN=example.com"}};
    const uint32_t cases[] = {0, 1, 8, 0x200, 0x10008, 0xFFFFFFFF};
    for (uint32_t original : cases) {
        Serial.output.clear();
        uint32_t flags = original;
        assert(config.verify(nullptr, &certificate, 2, &flags) == 0);
        assert(flags == original);
        assert(Serial.output.find("issuer=CN=Test root") != std::string::npos);
        assert(Serial.output.find("subject=CN=example.com") != std::string::npos);
        assert((Serial.output.find("failed epochUTC=") != std::string::npos) == (original != 0));
    }
    NetworkClientSecure* base = &first;
    base->stop();
    assert(first.test_context()->socket == -1);
    assert(first.test_context()->bundle_attach_cb == n9tls::attach_with_diagnostics);
    mbedtls_ssl_config reconnected;
    assert(first.test_context()->bundle_attach_cb(&reconnected) == ESP_OK);
    assert(reconnected.ca_chain == config.ca_chain && parse_calls == 121);
    assert(base->connect("example.com", 443, 1000) == 1);
    assert(base->connect(IPAddress{}, 443, 1000) == 1);
    assert(first.startTLS() == 1);
    std::thread one([&] { assert(first.connect("example.com", 443) == 1); });
    std::thread two([&] { assert(second.connect("example.com", 443) == 1); });
    one.join(); two.join();
    assert(maximum_handshakes == 1);
    assert(parse_calls == 121 && free_calls == 0);
    int registrations_before = register_calls;
    assert(n9tls::attach_with_diagnostics(nullptr) == ESP_OK && register_calls == registrations_before);
    puts("PASS: exact roots parsed once, required verification, untouched rejection flags, reconnect restoration and serialized recursive handshakes");
}
