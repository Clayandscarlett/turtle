#!/usr/bin/env python3
"""Compile actual player/coordinator code with fake HAL and real fault-injected SD I/O."""
from pathlib import Path
import os
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parents[1]
with tempfile.TemporaryDirectory(prefix="n9-session-test-") as directory:
    target = Path(directory) / "playback-session-test"
    flags = ["-std=c++17", "-Wall", "-Wextra", "-Werror", "-Wno-unused-parameter",
             "-Wno-missing-field-initializers", "-g", "-O1",
             "-DLV_CONF_INCLUDE_SIMPLE", "-DLV_LVGL_H_INCLUDE_SIMPLE",
             "-Iui", "-Isim/lvgl"]
    if os.environ.get("ASAN") == "1":
        flags += ["-fsanitize=address,undefined", "-fno-omit-frame-pointer"]
    shim = Path(directory) / "esp_heap_caps.h"
    shim.write_text("""#pragma once
#include <cstddef>
#include <cstdlib>
#define MALLOC_CAP_SPIRAM 1u
#define MALLOC_CAP_8BIT 2u
extern size_t n9_test_psram_free, n9_test_psram_largest, n9_test_psram_allocations;
inline void* heap_caps_malloc(size_t bytes, unsigned caps) {
    if (caps != (MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT)) std::abort();
    ++n9_test_psram_allocations; return std::malloc(bytes);
}
inline void heap_caps_free(void* p) { std::free(p); }
inline size_t heap_caps_get_free_size(unsigned) { return n9_test_psram_free; }
inline size_t heap_caps_get_largest_free_block(unsigned) { return n9_test_psram_largest; }
""")
    for configuration in ([], ["-DNANO_TARGET_ESP32=1", "-fno-exceptions", "-I", directory]):
        subprocess.run([os.environ.get("CXX", "g++"), *flags, *configuration,
                        "tools/test_playback_session.cpp", "ui/svc/playback_session.cpp",
                        "-Wl,--wrap=fwrite", "-Wl,--wrap=fclose", "-Wl,--wrap=fsync", "-Wl,--wrap=rename",
                        "-o", str(target)], cwd=ROOT, check=True)
        subprocess.run([str(target), str(Path(directory) / "card")], cwd=ROOT, check=True)
