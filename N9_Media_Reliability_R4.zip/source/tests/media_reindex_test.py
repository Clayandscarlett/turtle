#!/usr/bin/env python3
"""Drive actual LVGL media views through real SD rescans and numeric-id reuse.

Requires an already built headless simulator; never builds or touches a real card.
Audio transport remains simulated. Assertions concern row identity, navigation,
refresh lifetimes and selected paths, not physical decoding or sound quality.
"""
import argparse
import os
from pathlib import Path
import struct
import subprocess
import tempfile


def chunk(name, data):
    return name + struct.pack("<I", len(data)) + data + (b"\0" if len(data) % 2 else b"")


def wav(path, title, artist="", album="", genre=""):
    path.parent.mkdir(parents=True, exist_ok=True)
    info = b"INFO"
    for name, value in ((b"INAM", title), (b"IART", artist), (b"IPRD", album), (b"IGNR", genre)):
        if value:
            info += chunk(name, value.encode())
    # Valid 60-second mono PCM file, with INFO tags used by production parse_wav.
    body = b"WAVE" + chunk(b"fmt ", struct.pack("<HHIIHH", 1, 1, 1000, 2000, 2, 16))
    body += chunk(b"LIST", info) + chunk(b"data", b"\0" * 120000)
    path.write_bytes(b"RIFF" + struct.pack("<I", len(body)) + body)


def fixture(root, empty=False):
    for directory in ("Music", "Podcasts", "Audiobooks", "Playlists", "Fixtures", ".nanoos"):
        (root / directory).mkdir(parents=True)
    (root / ".nanoos/kv.txt").write_text("lang=en\nautolock=0\n")
    wav(root / "Fixtures/Arrival.wav", "Arrival", "ArtistThree", "AlbumThree", "GenreThree")
    if empty:
        return
    for index in range(40):
        group = "One" if index < 20 else "Two"
        wav(root / "Music" / ("Track%02d.wav" % index), "Track%02d" % index,
            "Artist" + group, "Album" + group, "Genre" + group)
    for index in range(2):
        episode = root / "Podcasts/ShowA" / ("Episode%02d.wav" % index)
        wav(episode, "Episode%02d" % index, "Presenter", "ShowA")
        os.utime(episode, (1700000000 + index, 1700000000 + index))
        wav(root / "Audiobooks/BookA" / ("Chapter%02d.wav" % index),
            "Chapter%02d" % index, "Narrator", "BookA")
    (root / "Playlists/Favorites.m3u").write_text("/Music/Track01.wav\n/Music/Track03.wav\n")


def script(*lines):
    return "\n".join(lines) + "\n"


def music_nested(entry, target=None):
    lines = ["launch music", "click-media-label " + entry, "wait 300"]
    if target:
        lines += ["click-media-label " + target, "wait 300"]
    return lines


def shifted_selection(prefix, reference="Track01", path="Music/Track01.wav"):
    return script(*prefix,
                  "expect-label " + reference,
                  "remember-media-id " + path,
                  "media-remove-before-reference", "rescan-library", "expect-media-reindexed",
                  "click-media-label " + reference,
                  "expect-current-path -",  # old label must never activate a newly reused id
                  "wait 300", "expect-label " + reference,
                  "click-media-label " + reference, "wait 300", "expect-current-path " + path,
                  "back", "expect-label " + reference,
                  "home", "media-copy Fixtures/Arrival.wav Music/Arrival.wav",
                  "rescan-library", "wait 400")  # closed view timers must be gone


SCENARIOS = {
    "music-songs": script(*music_nested("Songs"),
        "expect-label Track00", "remember-media-id Music/Track01.wav",
        "media-remove-before-reference", "rescan-library", "expect-media-reindexed",
        "click-media-label Track01", "expect-current-path -", "wait 300",
        "expect-label Track00", "click-media-label Track01", "wait 300",
        "expect-current-path Music/Track01.wav", "back",
        "scroll-media 21", "expect-label Track20", "click-media-label Track20", "wait 300",
        "expect-current-path Music/Track20.wav",
        # The Songs page is covered by Now Playing: only on_show should refresh it.
        "remember-media-id Music/Track21.wav", "media-remove-before-reference",
        "rescan-library", "expect-media-reindexed", "wait 400", "back",
        "expect-label Track21", "click-media-label Track21", "wait 300",
        "expect-current-path Music/Track21.wav", "home",
        "media-copy Fixtures/Arrival.wav Music/Arrival.wav", "rescan-library", "wait 400"),
    "music-album": shifted_selection(music_nested("Albums", "AlbumOne")),
    "music-artist": shifted_selection(music_nested("Artists", "ArtistOne")),
    "music-genre": shifted_selection(music_nested("Genres", "GenreOne")),
    "music-playlist": shifted_selection(music_nested("Playlists", "Favorites")),
    "music-smart-playlist": shifted_selection(
        ["mark-media-played Music/Track01.wav"] + music_nested("Playlists", "Top 25 Most Played")),
    "music-albums-root": script("media-copy Fixtures/Arrival.wav Music/Arrival.wav", "rescan-library", "wait 300",
        *music_nested("Albums"), "expect-label AlbumThree", "expect-label ArtistThree",
        "media-remove Music/Arrival.wav", "rescan-library", "click-media-label AlbumThree",
        "expect-current-path -", "wait 300", "expect-no-label AlbumThree", "expect-no-label ArtistThree",
        "click-media-label AlbumOne", "wait 300", "click-media-label Track01", "wait 300",
        "expect-current-path Music/Track01.wav", "home", "rescan-library", "wait 400"),
    "podcast-episodes": shifted_selection(
        ["launch podcasts", "click-media-label ShowA", "wait 300"],
        "Episode00", "Podcasts/ShowA/Episode00.wav"),
    "audiobook-chapters": shifted_selection(
        ["launch audiobooks", "click-media-label BookA", "wait 300"],
        "Chapter00", "Audiobooks/BookA/Chapter00.wav"),
    "podcast-root": script("launch podcasts", "expect-label 2", "remember-media-id Podcasts/ShowA/Episode00.wav",
        "media-remove-before-reference", "rescan-library", "expect-media-reindexed",
        "click-media-label ShowA", "expect-no-label Episode00", "wait 300",
        "click-media-label ShowA", "wait 300", "expect-label Episode00",
        # Stats deliberately change without bumping lib::version().
        "mark-media-played Podcasts/ShowA/Episode00.wav", "back", "expect-label 1", "expect-no-label 2",
        "home", "media-copy Fixtures/Arrival.wav Music/Arrival.wav", "rescan-library", "wait 400"),
    "audiobook-root": script("launch audiobooks", "remember-media-id Audiobooks/BookA/Chapter00.wav",
        "media-remove-before-reference", "rescan-library", "expect-media-reindexed",
        "click-media-label BookA", "expect-no-label Chapter00", "wait 300",
        "click-media-label BookA", "wait 300", "expect-label Chapter00", "home", "rescan-library", "wait 400"),
    "removed-all-episodes": script("launch podcasts", "click-media-label ShowA", "wait 300",
        "media-remove Podcasts/ShowA/Episode00.wav", "media-remove Podcasts/ShowA/Episode01.wav", "rescan-library",
        "click-media-label Episode00", "expect-current-path -", "wait 300", "expect-label No Items",
        "expect-no-label Episode00", "back", "expect-label No Podcasts", "home", "rescan-library", "wait 400"),
    "initially-empty-podcasts": script("launch podcasts", "expect-label No Podcasts",
        "media-copy Fixtures/Arrival.wav Podcasts/Arrival.wav", "rescan-library", "wait 400",
        "expect-no-label No Podcasts", "expect-label AlbumThree", "click-media-label AlbumThree", "wait 300",
        "expect-label Arrival", "click-media-label Arrival", "wait 300", "expect-current-path Podcasts/Arrival.wav"),
    "initially-empty-audiobooks": script("launch audiobooks", "expect-label No Audiobooks",
        "media-copy Fixtures/Arrival.wav Audiobooks/Arrival.wav", "rescan-library", "wait 400",
        "expect-no-label No Audiobooks", "expect-label AlbumThree", "click-media-label AlbumThree", "wait 300",
        "expect-label Arrival", "click-media-label Arrival", "wait 300", "expect-current-path Audiobooks/Arrival.wav"),
}


def run(simulator, output):
    for name, commands in SCENARIOS.items():
        directory = output / name
        directory.mkdir(parents=True)
        card = directory / "card"
        fixture(card, name.startswith("initially-empty"))
        commands_file = directory / "scenario.txt"
        commands_file.write_text(commands)
        env = dict(os.environ, NANO_SDROOT=str(card), NANO_SIM_ASYNC_DELAY_MS="0")
        env.setdefault("ASAN_OPTIONS", "detect_leaks=0:halt_on_error=1")
        result = subprocess.run([str(simulator), str(commands_file), str(directory / "shots")],
                                env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
        (directory / "simulator.log").write_text(result.stdout)
        if result.returncode or "unknown command:" in result.stdout:
            raise SystemExit("FAIL %s (exit %s)\n%s" % (name, result.returncode, result.stdout))
        print("PASS", name, flush=True)
    print("%d production UI/rescan scenarios passed." % len(SCENARIOS))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sim", required=True, type=Path)
    parser.add_argument("--output", type=Path, help="New directory for fixtures, scripts and logs")
    args = parser.parse_args()
    simulator = args.sim.resolve()
    if args.output:
        run(simulator, args.output.resolve())
    else:
        with tempfile.TemporaryDirectory(prefix="n9-media-reindex-") as directory:
            run(simulator, Path(directory))
