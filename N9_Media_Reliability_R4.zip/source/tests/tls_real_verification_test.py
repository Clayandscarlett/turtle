#!/usr/bin/env python3
"""Verify production TLS trust with real mbedTLS 3.6.5, not a mocked verifier.

Prepare the matching upstream library once (the device SDK uses 3.6.5):
  git clone --depth 1 --branch mbedtls-3.6.5 --recurse-submodules \
      --shallow-submodules https://github.com/Mbed-TLS/mbedtls.git /tmp/n9-mbedtls-3.6.5
  make -C /tmp/n9-mbedtls-3.6.5/library -j4
  python -m pip install cryptography
  python tests/tls_real_verification_test.py --mbedtls-source /tmp/n9-mbedtls-3.6.5

Only the Arduino transport shell is stubbed. The production tls_client.cpp,
its complete root certificate cache, and the actual mbedTLS X.509 parser,
signature/chain/hostname/time validation and diagnostic callback all run.
Host execution does not establish ESP32 memory consumption or a successful
handshake on the user's network. Host defaults enable certificate date checks;
the unchanged target SDK disables MBEDTLS_HAVE_TIME_DATE, so expired/future
tests establish host behavior only, not date rejection on the phone.
Ephemeral test keys and trust roots are
written exclusively to a temporary directory, never to firmware.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timedelta, timezone
import os
from pathlib import Path
import subprocess
import tempfile

from cryptography import x509
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ec, rsa
from cryptography.x509.name import _ASN1Type
from cryptography.x509.oid import ExtendedKeyUsageOID, NameOID


def name(common_name: str, encoding: _ASN1Type = _ASN1Type.PrintableString) -> x509.Name:
    return x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, common_name, _type=encoding)])


def create_fixtures(directory: Path) -> None:
    now = datetime.now(timezone.utc)
    # Match the reported SSL.com root's P-384/SHA-384 family, while the
    # issuing and leaf keys exercise P-256/SHA-256.
    root_key = ec.generate_private_key(ec.SECP384R1())
    inter_key = ec.generate_private_key(ec.SECP256R1())
    leaf_key = ec.generate_private_key(ec.SECP256R1())
    root_name = name("N9 Host Test Root NEVER FIRMWARE")
    inter_name = name("N9 Host Test Intermediate")
    serial = 0

    def certificate(subject, issuer, key, signer, *, ca, before=None, after=None):
        nonlocal serial
        serial += 1
        builder = (x509.CertificateBuilder()
                   .subject_name(subject).issuer_name(issuer).public_key(key.public_key())
                   .serial_number(serial)
                   .not_valid_before(before or now - timedelta(days=1))
                   .not_valid_after(after or now + timedelta(days=30))
                   .add_extension(x509.BasicConstraints(ca=ca, path_length=None), critical=True)
                   .add_extension(x509.KeyUsage(digital_signature=True, content_commitment=False,
                                                key_encipherment=False, data_encipherment=False,
                                                key_agreement=False, key_cert_sign=ca, crl_sign=ca,
                                                encipher_only=None, decipher_only=None), critical=True)
                   .add_extension(x509.SubjectKeyIdentifier.from_public_key(key.public_key()), critical=False)
                   .add_extension(x509.AuthorityKeyIdentifier.from_issuer_public_key(signer.public_key()), critical=False))
        if not ca:
            builder = (builder.add_extension(x509.SubjectAlternativeName([x509.DNSName("phone.test")]), critical=False)
                       .add_extension(x509.ExtendedKeyUsage([ExtendedKeyUsageOID.SERVER_AUTH]), critical=False))
        algorithm = hashes.SHA384() if isinstance(signer, ec.EllipticCurvePrivateKey) and signer.key_size >= 384 else hashes.SHA256()
        return builder.sign(signer, algorithm).public_bytes(serialization.Encoding.DER)

    def write(filename, **kwargs):
        value = certificate(**kwargs)
        (directory / filename).write_bytes(value)
        return value

    write("root.der", subject=root_name, issuer=root_name, key=root_key, signer=root_key, ca=True)
    write("intermediate.der", subject=inter_name, issuer=root_name, key=inter_key, signer=root_key, ca=True)
    base_leaf = dict(subject=name("phone.test"), issuer=inter_name, key=leaf_key, signer=inter_key, ca=False)
    leaf = write("leaf.der", **base_leaf)
    (directory / "corrupt-leaf.der").write_bytes(leaf[:-1] + bytes([leaf[-1] ^ 1]))
    write("expired-leaf.der", **base_leaf, before=now - timedelta(days=4), after=now - timedelta(days=2))
    write("future-leaf.der", **base_leaf, before=now + timedelta(days=2), after=now + timedelta(days=4))
    write("normalized-intermediate.der", subject=inter_name,
          issuer=name("N9 Host Test Root NEVER FIRMWARE", _ASN1Type.UTF8String),
          key=inter_key, signer=root_key, ca=True)
    write("normalized-leaf.der", **{**base_leaf,
          "issuer": name("N9 Host Test Intermediate", _ASN1Type.UTF8String)})
    stranger_key = ec.generate_private_key(ec.SECP256R1())
    stranger_name = name("Completely Untrusted Host Test Root")
    write("untrusted-root.der", subject=stranger_name, issuer=stranger_name,
          key=stranger_key, signer=stranger_key, ca=True)
    rsa_key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    rsa_name = name("N9 RSA Host Test Root NEVER FIRMWARE")
    write("rsa-root.der", subject=rsa_name, issuer=rsa_name, key=rsa_key, signer=rsa_key, ca=True)
    write("rsa-intermediate.der", subject=inter_name, issuer=rsa_name, key=inter_key, signer=rsa_key, ca=True)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--mbedtls-source", type=Path,
                        default=Path(os.environ.get("N9_MBEDTLS_SOURCE", "/tmp/n9-mbedtls-3.6.5")))
    arguments = parser.parse_args()
    mb = arguments.mbedtls_source.resolve()
    for relative in ("include/mbedtls/x509_crt.h", "library/libmbedtls.a",
                     "library/libmbedx509.a", "library/libmbedcrypto.a"):
        if not (mb / relative).is_file():
            parser.error(f"missing {mb / relative}; prepare the real 3.6.5 libraries as described above")
    version_header = (mb / "include/mbedtls/build_info.h").read_text()
    if '#define MBEDTLS_VERSION_STRING         "3.6.5"' not in version_header:
        parser.error("the host library source must match device SDK mbedTLS 3.6.5")
    root = Path(__file__).resolve().parents[1]
    stubs = root / "tests/tls_real_stubs"
    with tempfile.TemporaryDirectory(prefix="n9-real-mbedtls-test-") as temporary:
        directory = Path(temporary)
        create_fixtures(directory)
        binary = directory / "real-tls-verification"
        subprocess.run([
            "g++", "-std=c++17", "-g", "-fsanitize=address,undefined", "-pthread",
            "-I" + str(stubs), "-I" + str(root / "firmware/src"), "-I" + str(mb / "include"),
            str(stubs / "main.cpp"), str(root / "firmware/src/tls_client.cpp"),
            str(mb / "library/libmbedtls.a"), str(mb / "library/libmbedx509.a"),
            str(mb / "library/libmbedcrypto.a"), "-o", str(binary),
        ], check=True)
        subprocess.run([str(binary), str(directory)], check=True)


if __name__ == "__main__":
    main()
