#pragma once
// Only the Arduino transport shell is replaced. Every X.509/TLS API and
// certificate structure used by the production file comes from real mbedTLS.
#include <mbedtls/ssl.h>
#include <mbedtls/x509_crt.h>
#include <cstddef>
#include <cstdint>
#include <memory>

using esp_err_t = int;
inline constexpr esp_err_t ESP_OK = 0;
struct IPAddress {};
struct sslclient_context {
    esp_err_t (*bundle_attach_cb)(void*) = nullptr;
    int socket = -1;
    int last_error = 0;
};
struct SerialStub {
    void printf(const char* format, ...);
};
extern SerialStub Serial;
class NetworkClientSecure {
protected:
    bool _use_insecure = true;
    bool _use_ca_bundle = false;
    std::shared_ptr<sslclient_context> sslclient = std::make_shared<sslclient_context>();
public:
    virtual ~NetworkClientSecure() = default;
    virtual void stop() { *sslclient = {}; sslclient->socket = 0; }
    virtual int connect(IPAddress, uint16_t) { return 1; }
    virtual int connect(IPAddress ip, uint16_t port, int32_t) { return connect(ip, port); }
    virtual int connect(const char*, uint16_t) { return 1; }
    virtual int connect(const char* host, uint16_t port, int32_t) { return connect(host, port); }
    int startTLS() { return 1; }
    sslclient_context* test_context() { return sslclient.get(); }
    bool test_insecure() const { return _use_insecure; }
    bool test_bundle_enabled() const { return _use_ca_bundle; }
};
