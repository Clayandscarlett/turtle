#include "tls_client.h"
#include "trusted_roots.h"
#include <mbedtls/version.h>
#include <psa/crypto.h>
#include <algorithm>
#include <cstdarg>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <iterator>
#include <mutex>
#include <stdexcept>
#include <string>
#include <thread>
#include <vector>

SerialStub Serial;
void SerialStub::printf(const char* format, ...) {
    static std::mutex lock;
    std::lock_guard<std::mutex> guard(lock);
    va_list args;
    va_start(args, format);
    vprintf(format, args);
    va_end(args);
}
static void require(bool condition, const char* message) {
    if (!condition) throw std::runtime_error(message);
}
static std::vector<unsigned char> read_der(const std::string& filename) {
    std::ifstream input(filename, std::ios::binary);
    require(input.good(), "cannot open generated fixture");
    return {std::istreambuf_iterator<char>(input), std::istreambuf_iterator<char>()};
}
struct Chain {
    mbedtls_x509_crt value;
    // Nocopy parser views must outlive the certificate chain.
    std::vector<std::vector<unsigned char>> backing;
    Chain() { mbedtls_x509_crt_init(&value); }
    ~Chain() { mbedtls_x509_crt_free(&value); }
    void append(const std::string& filename) {
        backing.push_back(read_der(filename));
        const auto& bytes = backing.back();
        require(mbedtls_x509_crt_parse_der_nocopy(&value, bytes.data(), bytes.size()) == 0,
                "real DER parsing failed");
    }
};
static void verify_case(const char* name, Chain& chain, mbedtls_x509_crt* anchor,
                        const char* hostname, mbedtls_ssl_config& config,
                        uint32_t expected_flags) {
    uint32_t flags = 0;
    const int result = mbedtls_x509_crt_verify(
        &chain.value, anchor, nullptr, hostname, &flags,
        config.MBEDTLS_PRIVATE(f_vrfy), config.MBEDTLS_PRIVATE(p_vrfy));
    std::printf("[real-tls-test] %s result=%d flags=0x%08x\n", name, result, flags);
    if (expected_flags == 0) {
        require(result == 0 && flags == 0, "valid real signed chain was rejected");
    } else {
        require(result == MBEDTLS_ERR_X509_CERT_VERIFY_FAILED,
                "invalid certificate was accepted or returned unexpected failure");
        require((flags & expected_flags) == expected_flags,
                "invalid certificate did not preserve expected verification flags");
    }
}
int main(int argc, char** argv) {
    try {
        require(argc == 2, "expected generated fixtures directory");
        const std::string directory = std::string(argv[1]) + "/";
        require(psa_crypto_init() == PSA_SUCCESS, "real PSA crypto initialization failed");
        char version[32] = {};
        mbedtls_version_get_string_full(version);
        require(std::strcmp(version, "Mbed TLS 3.6.5") == 0,
                "host verifier must match device SDK mbedTLS3.6.5 version");
        std::printf("[real-tls-test] engine=%s (real host implementation; transport is stubbed)\n", version);

        // Exercise the actual once-only firmware cache concurrently.
        std::vector<std::thread> threads;
        for (unsigned i = 0; i != 8; ++i) {
            threads.emplace_back([] { require(n9tls::initialize(), "production root cache failed"); });
        }
        for (auto& thread : threads) thread.join();
        require(n9tls::initialize(), "repeated root-cache initialization failed");
        n9tls::Client client;
        require(client.configureTrust(), "production client trust configuration failed");
        require(!client.test_insecure() && client.test_bundle_enabled(),
                "production client disabled authentication");
        require(client.test_context()->bundle_attach_cb == n9tls::attach_with_diagnostics,
                "production client did not attach full-chain callback");
        client.stop();
        require(client.test_context()->bundle_attach_cb == n9tls::attach_with_diagnostics,
                "production reconnect lost its full-chain callback");
        require(client.test_context()->socket == -1,
                "production stop left a valid-looking socket descriptor");

        mbedtls_ssl_config config;
        mbedtls_ssl_config_init(&config);
        require(mbedtls_ssl_config_defaults(&config, MBEDTLS_SSL_IS_CLIENT,
                MBEDTLS_SSL_TRANSPORT_STREAM, MBEDTLS_SSL_PRESET_DEFAULT) == 0,
                "real SSL configuration failed");
        require(n9tls::attach_with_diagnostics(&config) == ESP_OK, "production CA attachment failed");
        require(config.MBEDTLS_PRIVATE(authmode) == MBEDTLS_SSL_VERIFY_REQUIRED,
                "production SSL config does not require peer verification");
#if defined(MBEDTLS_SSL_RENEGOTIATION)
        require(config.MBEDTLS_PRIVATE(disable_renegotiation) == MBEDTLS_SSL_RENEGOTIATION_DISABLED,
                "production SSL configuration allows unguarded renegotiation");
#endif
        require(config.MBEDTLS_PRIVATE(f_vrfy) != nullptr, "production diagnostic callback missing");
        auto* root = config.MBEDTLS_PRIVATE(ca_chain);
        unsigned roots = 0;
        for (; root; root = root->next, ++roots) {
            require(roots < n9tls::trusted_root_count, "too many parsed trust anchors");
            const auto& span = n9tls::trusted_roots[roots];
            require(root->raw.p == n9tls::trusted_root_der + span.offset,
                    "production trust-root cache copied DER rather than referencing flash backing");
            require(root->raw.len == span.length && root->version != 0,
                    "production trust-root cache contains an invalid DER range");
        }
        require(roots == 121 && roots == n9tls::root_count(), "production trust-anchor count changed");
        std::printf("[real-tls-test] parsed all %u firmware trust anchors using persistent nocopy DER\n", roots);

        Chain anchor, untrusted, ordinary, normalized, corrupt, expired, future, missing, rsa_anchor, rsa_chain;
        anchor.append(directory + "root.der");
        untrusted.append(directory + "untrusted-root.der");
        ordinary.append(directory + "leaf.der");
        ordinary.append(directory + "intermediate.der");
        normalized.append(directory + "normalized-leaf.der");
        normalized.append(directory + "normalized-intermediate.der");
        corrupt.append(directory + "corrupt-leaf.der");
        corrupt.append(directory + "intermediate.der");
        expired.append(directory + "expired-leaf.der");
        expired.append(directory + "intermediate.der");
        future.append(directory + "future-leaf.der");
        future.append(directory + "intermediate.der");
        missing.append(directory + "leaf.der");
        rsa_anchor.append(directory + "rsa-root.der");
        rsa_chain.append(directory + "leaf.der");
        rsa_chain.append(directory + "rsa-intermediate.der");

        verify_case("temporary synthetic CA is NOT trusted by production anchors", ordinary,
                    config.MBEDTLS_PRIVATE(ca_chain), "phone.test", config, MBEDTLS_X509_BADCERT_NOT_TRUSTED);
        verify_case("valid P384/SHA384 to P256/SHA256 signed chain", ordinary, &anchor.value, "phone.test", config, 0);
        verify_case("valid RSA2048/SHA256 to P256/SHA256 signed chain", rsa_chain, &rsa_anchor.value, "phone.test", config, 0);
        // Reproduce a valid name-encoding variation that exact raw-DN lookup
        // rejects. The standard verifier compares parsed X.509 names.
        const auto& encoded_issuer = normalized.value.next->issuer_raw;
        const auto& encoded_subject = anchor.value.subject_raw;
        require(encoded_issuer.len != encoded_subject.len ||
                std::memcmp(encoded_issuer.p, encoded_subject.p, encoded_issuer.len) != 0,
                "normalized-name fixture accidentally has identical raw DER names");
        verify_case("PrintableString/UTF8String issuer normalization", normalized, &anchor.value, "phone.test", config, 0);
        verify_case("wrong hostname rejected", ordinary, &anchor.value, "attacker.test", config, MBEDTLS_X509_BADCERT_CN_MISMATCH);
        verify_case("untrusted root rejected", ordinary, &untrusted.value, "phone.test", config, MBEDTLS_X509_BADCERT_NOT_TRUSTED);
        verify_case("corrupted signature rejected", corrupt, &anchor.value, "phone.test", config, MBEDTLS_X509_BADCERT_NOT_TRUSTED);
        verify_case("missing intermediate rejected", missing, &anchor.value, "phone.test", config, MBEDTLS_X509_BADCERT_NOT_TRUSTED);
        std::puts("[real-tls-test] Date checks below are HOST config only; target SDK date checks are disabled unchanged.");
        verify_case("HOST-only expired leaf rejected", expired, &anchor.value, "phone.test", config, MBEDTLS_X509_BADCERT_EXPIRED);
        verify_case("HOST-only future leaf rejected", future, &anchor.value, "phone.test", config, MBEDTLS_X509_BADCERT_FUTURE);

        mbedtls_x509_crt malformed;
        mbedtls_x509_crt_init(&malformed);
        const unsigned char invalid[] = {0x30, 0x82, 0x01, 0x00, 0x00};
        require(mbedtls_x509_crt_parse_der_nocopy(&malformed, invalid, sizeof invalid) != 0,
                "real DER parser accepted a truncated certificate");
        mbedtls_x509_crt_free(&malformed);
        mbedtls_ssl_config_free(&config);
        std::puts("[real-tls-test] all real verification and production trust-cache checks passed");
        return 0;
    } catch (const std::exception& error) {
        std::fprintf(stderr, "real TLS test failed: %s\n", error.what());
        return 1;
    }
}
