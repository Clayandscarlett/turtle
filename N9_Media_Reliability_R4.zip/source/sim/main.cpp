/*
 * nanoOS desktop simulator.
 *   Headless:     ./nanosim script.txt outdir      (scripted touches, PNG screenshots)
 *   Interactive:  ./nanosim --sdl                   (built with SDL=1)
 *
 * Script commands (one per line, '#' comments):
 *   tap X Y | long X Y MS | swipe X1 Y1 X2 Y2 [MS] | wait MS | shot NAME | home | back
 *   press X Y | move X Y | release | launch APPID | net on|off
 */
#include "lvgl.h"
#include "../ui/hal.h"
#include "../ui/os/system.h"
#include "../ui/os/theme.h"
#include "../ui/os/keyboard.h"
#include "../ui/os/list.h"
#include "../ui/svc/artwork.h"
#include "../ui/svc/player.h"
#include "../ui/svc/dashboard.h"
#include "../ui/os/aero.h"
namespace hal { extern bool g_sim_time_valid; extern int g_sim_battery; int sim_backlight(); }
namespace hal { extern int g_sim_usb_audio; }
using hal::g_sim_usb_audio;
#include "png_writer.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <string>
#include <vector>
#include <fstream>
#include <sstream>
#include <sys/stat.h>

void nano_register_apps();

uint32_t g_sim_ms = 0;
bool g_sim_net = false;

static uint16_t fb[SCR_W * SCR_H];
static int display_w(){return lv_display_get_horizontal_resolution(nullptr);}
static int display_h(){return lv_display_get_vertical_resolution(nullptr);}
static bool t_pressed = false;
static int16_t t_x = 0, t_y = 0;

namespace hal { extern bool g_sim_invert; }
static void flush_cb(lv_display_t* d, const lv_area_t* a, uint8_t* px) {
    uint16_t* p = (uint16_t*)px;
    for (int y = a->y1; y <= a->y2; y++)
        for (int x = a->x1; x <= a->x2; x++) fb[y * display_w() + x] = hal::g_sim_invert ? (uint16_t)~*p++ : *p++;
    lv_display_flush_ready(d);
}

static void read_cb(lv_indev_t*, lv_indev_data_t* data) {
    bool pr = t_pressed;
    int16_t x = t_x, y = t_y;
    os::input_filter(pr, x, y);
    data->point.x = x;
    data->point.y = y;
    data->state = pr ? LV_INDEV_STATE_PRESSED : LV_INDEV_STATE_RELEASED;
}

static void step(uint32_t ms) {
    /* advance simulated time in 5 ms ticks, like a 200 Hz touch poll */
    for (uint32_t t = 0; t < ms; t += 5) {
        g_sim_ms += 5;
        lv_tick_inc(5);
        lv_timer_handler();
        os::loop();
    }
}

static void shot(const std::string& path) {
    lv_refr_now(nullptr);
    std::vector<unsigned char> rgb(SCR_W * SCR_H * 3);
    for (int i = 0; i < SCR_W * SCR_H; i++) {
        uint16_t c = fb[i];
        int r = (c >> 11) & 31, g = (c >> 5) & 63, b = c & 31;
        rgb[i * 3] = (r * 527 + 23) >> 6;
        rgb[i * 3 + 1] = (g * 259 + 33) >> 6;
        rgb[i * 3 + 2] = (b * 527 + 23) >> 6;
    }
    const auto png = sim_png::encode24(rgb.data(), display_w(), display_h());
    FILE* f = fopen(path.c_str(), "wb");
    if (f) { fwrite(png.data(), 1, png.size(), f); fclose(f); }
    printf("[sim] shot %s\n", path.c_str());
}

static void drag(int x1, int y1, int x2, int y2, int ms) {
    t_pressed = true; t_x = x1; t_y = y1;
    step(20);
    int n = ms / 10; if (n < 2) n = 2;
    for (int i = 1; i <= n; i++) {
        t_x = x1 + (x2 - x1) * i / n;
        t_y = y1 + (y2 - y1) * i / n;
        step(10);
    }
    t_pressed = false;
    step(20);
}

#ifdef SIM_SDL
#include <SDL2/SDL.h>
static int run_sdl() {
    SDL_Init(SDL_INIT_VIDEO);
    const int Z = 2;
    SDL_Window* w = SDL_CreateWindow("nanoOS", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, SCR_W * Z, SCR_H * Z, 0);
    SDL_Renderer* r = SDL_CreateRenderer(w, -1, SDL_RENDERER_PRESENTVSYNC);
    SDL_Texture* tex = SDL_CreateTexture(r, SDL_PIXELFORMAT_RGB565, SDL_TEXTUREACCESS_STREAMING, SCR_W, SCR_H);
    bool quit = false;
    uint32_t last = SDL_GetTicks();
    while (!quit) {
        SDL_Event e;
        while (SDL_PollEvent(&e)) {
            if (e.type == SDL_QUIT) quit = true;
            if (e.type == SDL_MOUSEBUTTONDOWN) { t_pressed = true; t_x = e.button.x / Z; t_y = e.button.y / Z; }
            if (e.type == SDL_MOUSEBUTTONUP) t_pressed = false;
            if (e.type == SDL_MOUSEMOTION && t_pressed) { t_x = e.motion.x / Z; t_y = e.motion.y / Z; }
            if (e.type == SDL_KEYDOWN && e.key.keysym.sym == SDLK_h) os::go_home(true);
        }
        uint32_t now = SDL_GetTicks();
        step(now - last > 100 ? 100 : ((now - last) / 5) * 5 + 5);
        last = now;
        static int tw=SCR_W,th=SCR_H;
        if(tw!=display_w() || th!=display_h()){
            tw=display_w();th=display_h();SDL_DestroyTexture(tex);
            tex=SDL_CreateTexture(r,SDL_PIXELFORMAT_RGB565,SDL_TEXTUREACCESS_STREAMING,tw,th);
            SDL_SetWindowSize(w,tw*Z,th*Z);
        }
        SDL_UpdateTexture(tex, nullptr, fb, display_w() * 2);
        SDL_RenderCopy(r, tex, nullptr, nullptr);
        SDL_RenderPresent(r);
    }
    return 0;
}
#endif


/* Layout audit: report visible labels whose text runs past the screen edge or out of their parent's
 * visible area (a clipped/overflowing string), so text-overflow glitches are caught automatically. */
#include <set>
static std::set<std::string> g_audit_seen;
static bool audit_visible(lv_obj_t* o) {
    for (lv_obj_t* p = o; p; p = lv_obj_get_parent(p)) {
        if (lv_obj_has_flag(p, LV_OBJ_FLAG_HIDDEN)) return false;
        if (lv_obj_get_style_opa(p, LV_PART_MAIN) < 10) return false;
    }
    return true;
}
static void audit_obj(lv_obj_t* o, const std::string& ctx, int& n) {
    uint32_t cnt = lv_obj_get_child_count(o);
    for (uint32_t i = 0; i < cnt; i++) audit_obj(lv_obj_get_child(o, i), ctx, n);
    if (!lv_obj_check_type(o, &lv_label_class) || !audit_visible(o)) return;
    // A one-line editable field intentionally scrolls its label under a clipped viewport.
    auto* parent = lv_obj_get_parent(o);
    if (parent && lv_obj_check_type(parent, &lv_textarea_class) &&
        lv_textarea_get_one_line(parent) && lv_obj_get_scroll_x(parent) > 0) return;
    const char* txt = lv_label_get_text(o);
    if (!txt || !*txt) return;
    lv_area_t a; lv_obj_get_coords(o, &a);
    if (a.x2 < 0 || a.x1 >= display_w() || a.y2 < 0 || a.y1 >= display_h()) return;        /* page parked off-screen */
    const lv_font_t* f = lv_obj_get_style_text_font(o, LV_PART_MAIN);
    lv_point_t sz;
    lv_text_get_size(&sz, txt, f, lv_obj_get_style_text_letter_space(o, 0), lv_obj_get_style_text_line_space(o, 0), LV_COORD_MAX, LV_TEXT_FLAG_NONE);
    lv_label_long_mode_t lm = lv_label_get_long_mode(o);
    int w = lv_area_get_width(&a);
    std::string why;
    if (a.x1 < 0 && a.x2 > 0) why = "starts left of screen";
    else if (a.x2 > display_w() && a.x1 < display_w()) why = "runs past right edge";
    else if (lm != LV_LABEL_LONG_DOT && lm != LV_LABEL_LONG_WRAP && lm != LV_LABEL_LONG_SCROLL && lm != LV_LABEL_LONG_SCROLL_CIRCULAR && sz.x > w + 2) why = "text wider than label (clipped)";
    else {
        /* clipped by an ancestor that does not scroll horizontally */
        for (lv_obj_t* p = lv_obj_get_parent(o); p; p = lv_obj_get_parent(p)) {
            lv_area_t pa; lv_obj_get_coords(p, &pa);
            if (lv_obj_has_flag(p, LV_OBJ_FLAG_OVERFLOW_VISIBLE)) continue;
            if (a.x2 > pa.x2 + 1 && a.x1 < pa.x2 && pa.x2 <= display_w()) { why = "overflows parent (right)"; break; }
            if (a.y2 > pa.y2 + 1 && a.y1 < pa.y2 && !(lv_obj_get_scroll_dir(p) & LV_DIR_VER && lv_obj_has_flag(p, LV_OBJ_FLAG_SCROLLABLE)) && pa.y2 <= display_h()) { why = "overflows parent (bottom)"; break; }
            break;   /* only the direct parent */
        }
    }
    if (why.empty()) return;
    std::string t = txt; if (t.size() > 40) t = t.substr(0, 40) + "...";
    for (auto& ch : t) if (ch == '\n') ch = '|';
    std::string key = ctx + "|" + t + "|" + why;
    if (g_audit_seen.insert(key).second) { fprintf(stderr, "[audit] %s: \"%s\" %s (x %d..%d y %d..%d)\n", ctx.c_str(), t.c_str(), why.c_str(), (int)a.x1, (int)a.x2, (int)a.y1, (int)a.y2); n++; }
}
static int audit(const std::string& ctx) {
    int n = 0;
    if (lv_anim_count_running() > 0) return 0;          /* mid-slide positions are not layout bugs */
    audit_obj(lv_screen_active(), ctx, n);
    audit_obj(lv_layer_top(), ctx, n);
    return n;
}
static bool has_label(lv_obj_t* o,const std::string& value) {
    if(!audit_visible(o))return false;
    if(lv_obj_check_type(o,&lv_label_class) && value==lv_label_get_text(o)){
        lv_area_t a;lv_obj_get_coords(o,&a);
        if(a.x2>=0 && a.x1<display_w() && a.y2>=0 && a.y1<display_h())return true;
    }
    for(uint32_t i=0;i<lv_obj_get_child_count(o);i++)if(has_label(lv_obj_get_child(o,i),value))return true;
    return false;
}
/* Exercise production media row callbacks and library rescans on an isolated
 * test card. These helpers do not synthesize or mutate library Track objects. */
static lv_obj_t* find_media_label(lv_obj_t* object, const std::string& text) {
    if (!audit_visible(object)) return nullptr;
    if (lv_obj_check_type(object, &lv_label_class) && text == lv_label_get_text(object)) {
        lv_area_t area; lv_obj_get_coords(object, &area);
        if (area.x2 >= 0 && area.x1 < display_w() && area.y2 >= 0 && area.y1 < display_h()) return object;
    }
    for (uint32_t i = 0; i < lv_obj_get_child_count(object); ++i)
        if (auto* result = find_media_label(lv_obj_get_child(object, i), text)) return result;
    return nullptr;
}
static lv_obj_t* find_media_list(lv_obj_t* object) {
    if (!audit_visible(object)) return nullptr;
    const char* name = lv_obj_get_name(object);
    if (name && !strcmp(name, "media-list")) return object;
    for (uint32_t i = 0; i < lv_obj_get_child_count(object); ++i)
        if (auto* result = find_media_list(lv_obj_get_child(object, i))) return result;
    return nullptr;
}
static bool media_test_path(const std::string& relative, std::string& absolute) {
    if (!getenv("NANO_SDROOT") || relative.empty() || relative[0] == '/' || relative.find("..") != std::string::npos) return false;
    absolute = std::string(hal::fs_root()) + "/" + relative;
    return true;
}
int main(int argc, char** argv) {
    hal::init();
    lv_init();
    lv_display_t* disp = lv_display_create(SCR_W, SCR_H);
    static uint8_t buf[SCR_W * SCR_H * 2];
    lv_display_set_buffers(disp, buf, nullptr, sizeof buf, LV_DISPLAY_RENDER_MODE_PARTIAL);
    lv_display_set_flush_cb(disp, flush_cb);
    th::init(disp);
    lv_indev_t* in = lv_indev_create();
    lv_indev_set_type(in, LV_INDEV_TYPE_POINTER);
    lv_indev_set_read_cb(in, read_cb);
    nano_register_apps();
    os::init();
    step(100);

#ifdef SIM_SDL
    if (argc > 1 && !strcmp(argv[1], "--sdl")) return run_sdl();
#endif
    if (argc < 3) { fprintf(stderr, "usage: %s script.txt outdir\n", argv[0]); return 1; }
    std::string outdir = argv[2];
    mkdir(outdir.c_str(), 0755);
    std::ifstream in_f(argv[1]);
    std::string line;
    std::string remembered_media_path;
    int remembered_media_id = -1;
    while (std::getline(in_f, line)) {
        if (line.empty() || line[0] == '#') continue;
        std::istringstream ss(line);
        std::string cmd;
        ss >> cmd;
        int a = 0, b = 0, c2 = 0, d = 0, e = 300;
        if (cmd == "tap") { ss >> a >> b; t_pressed = true; t_x = a; t_y = b; step(60); t_pressed = false; step(40); }
        else if (cmd == "long") { ss >> a >> b >> c2; t_pressed = true; t_x = a; t_y = b; step(c2 ? c2 : 800); t_pressed = false; step(40); }
        else if (cmd == "press") { ss >> a >> b; t_pressed = true; t_x = a; t_y = b; step(20); }
        else if (cmd == "move") { ss >> a >> b; t_x = a; t_y = b; step(20); }
        else if (cmd == "release") { t_pressed = false; step(20); }
        else if (cmd == "swipe") { ss >> a >> b >> c2 >> d; if (!(ss >> e)) e = 200; drag(a, b, c2, d, e); }
        else if (cmd == "wait") { ss >> a; step(a); }
        else if (cmd == "shot") { std::string n; ss >> n; shot(outdir + "/" + n + ".png"); }
        else if (cmd == "home") { os::go_home(false); step(400); }
        else if (cmd == "back") { drag(40, 160, 200, 165, 150); step(400); }
        else if (cmd == "launch") { std::string id; ss >> id; os::launch(id.c_str()); step(500); }
        else if (cmd == "expect-rec-state") {
            std::string wanted;ss>>wanted;
            const char* names[]={"Idle","Starting","Recording","Saving","Saved","Failed"};
            if(wanted!=names[int(hal::rec_state())]){fprintf(stderr,"FAIL recorder: wanted %s, got %s (%s)\n",wanted.c_str(),names[int(hal::rec_state())],hal::rec_error().c_str());return 2;}
        }
        else if (cmd == "expect-app") {
            std::string id;ss>>id;auto* app=os::current_app();
            if(!app || id!=app->id){fprintf(stderr,"FAIL app expected %s, got %s\n",id.c_str(),app?app->id:"home");return 2;}
        }
        else if (cmd == "expect-home") { if(os::current_app() || display_w()!=320 || display_h()!=240){fprintf(stderr,"FAIL home orientation\n");return 2;} }
        else if (cmd == "sleep") { os::sleep_now(); step(100); }
        else if (cmd == "wake") { os::wake_now(); step(100); }
        else if (cmd == "expect-backlight") { ss>>a; if(hal::sim_backlight()!=a){fprintf(stderr,"FAIL backlight: expected %d, got %d\n",a,hal::sim_backlight());return 2;} }
        else if (cmd == "expect-power-saver") { ss>>a; if(hal::power_saver_enabled()!=(a!=0)){fprintf(stderr,"FAIL power saver\n");return 2;} }
        else if (cmd == "expect-size") {ss>>a>>b;if(display_w()!=a || display_h()!=b){fprintf(stderr,"FAIL size\n");return 2;}}
        else if (cmd == "expect-label") {
            std::string value;std::getline(ss,value);if(!value.empty())value.erase(0,1);
            if(!has_label(lv_screen_active(),value) && !has_label(lv_layer_top(),value)){fprintf(stderr,"FAIL label %s\n",value.c_str());return 2;}
        }
        else if(cmd=="expect-no-label"){
            std::string value;std::getline(ss,value);if(!value.empty())value.erase(0,1);
            if(has_label(lv_screen_active(),value) || has_label(lv_layer_top(),value)){fprintf(stderr,"FAIL stale label %s\n",value.c_str());return 2;}
        }
        else if(cmd=="truth-unknown") {hal::g_sim_time_valid=false;hal::g_sim_battery=-1;hal::wifi_enable(false);step(1200);}
        else if(cmd=="portrait-overlay") {ss>>a;os::portrait_overlay(a!=0);step(100);}
        else if(cmd=="wallpaper") {ss>>a;aero::set_wallpaper(a);step(100);}
        else if(cmd=="play-file") {std::string name;ss>>name;player::play_file(name,std::string(hal::fs_root())+"/Music/test.wav");step(1200);}
        else if(cmd=="play-library") {auto songs=lib::songs();if(songs.size()<2){fprintf(stderr,"FAIL test music missing\n");return 2;}player::play(songs,0,false);step(1200);}
        else if(cmd=="expect-playing") {ss>>a;if(player::playing()!=(a!=0)){fprintf(stderr,"FAIL playback state\n");return 2;}}
        else if(cmd=="click-media-label") {
            std::string text; std::getline(ss,text); if(!text.empty())text.erase(0,1);
            lv_obj_t* object=find_media_label(lv_screen_active(),text);
            while(object && !lv_obj_has_flag(object,LV_OBJ_FLAG_CLICKABLE))object=lv_obj_get_parent(object);
            if(!object){fprintf(stderr,"FAIL missing clickable media label %s\n",text.c_str());return 2;}
            /* No time advance: can deliberately click the old visible row in
             * the gap between scan completion and the view's refresh timer. */
            lv_obj_send_event(object,LV_EVENT_CLICKED,nullptr);
        }
        else if(cmd=="scroll-media") {
            ss>>a;auto* list=find_media_list(lv_screen_active());
            if(!list){fprintf(stderr,"FAIL visible media list missing\n");return 2;}
            os::VList::from(list)->scroll_to_item(a,false);step(20);
        }
        else if(cmd=="media-remove") {
            std::string relative,absolute;ss>>relative;
            if(!media_test_path(relative,absolute) || remove(absolute.c_str())!=0){fprintf(stderr,"FAIL isolated media removal\n");return 2;}
        }
        else if(cmd=="media-remove-before-reference") {
            int target=lib::find_path(remembered_media_path), candidate=-1;
            for(int id=0;id<target;id++) {
                const auto* track=lib::get(id);
                if(track && track->kind==lib::K_MUSIC && id!=player::current()){candidate=id;break;}
            }
            const auto* track=lib::get(candidate);
            if(!getenv("NANO_SDROOT") || !track || remove(track->path.c_str())!=0){fprintf(stderr,"FAIL no preceding isolated media track\n");return 2;}
            printf("[sim] removed preceding id=%d path=%s\n",candidate,track->path.c_str());
        }
        else if(cmd=="media-copy") {
            std::string from,to,source,destination;ss>>from>>to;
            if(!media_test_path(from,source) || !media_test_path(to,destination)){fprintf(stderr,"FAIL isolated media copy path\n");return 2;}
            std::ifstream input(source,std::ios::binary);std::ofstream output(destination,std::ios::binary);
            if(!input || !output){fprintf(stderr,"FAIL isolated media copy open\n");return 2;}
            output<<input.rdbuf();output.close();
            if(!output){fprintf(stderr,"FAIL isolated media copy write\n");return 2;}
        }
        else if(cmd=="rescan-library") {lib::rescan();hal::poll();}
        else if(cmd=="remember-media-id") {
            std::string relative;ss>>relative;
            if(!media_test_path(relative,remembered_media_path) || (remembered_media_id=lib::find_path(remembered_media_path))<0){fprintf(stderr,"FAIL missing reference media id\n");return 2;}
        }
        else if(cmd=="expect-media-reindexed") {
            int current=lib::find_path(remembered_media_path);
            if(remembered_media_id<0 || current<0 || current==remembered_media_id){fprintf(stderr,"FAIL test did not renumber reference track\n");return 2;}
        }
        else if(cmd=="expect-current-path") {
            std::string relative,absolute;ss>>relative;auto* track=player::track();
            bool matches=relative=="-" ? !track : media_test_path(relative,absolute) && track && track->path==absolute;
            if(!matches){fprintf(stderr,"FAIL media selection expected %s, got %s\n",relative.c_str(),track?track->path.c_str():"none");return 2;}
        }
        else if(cmd=="mark-media-played") {
            std::string relative,absolute;ss>>relative;
            int id=media_test_path(relative,absolute)?lib::find_path(absolute):-1;
            if(id<0){fprintf(stderr,"FAIL missing media stats track\n");return 2;}lib::mark_played(id);
        }
        else if(cmd=="snapshot-weather") {
            dash::Weather w;w.valid=true;w.received=hal::millis();w.key="Regina|50.4452|-104.6189";w.unit="C";w.city="Regina";w.temperature=12;
            dash::publish_weather(w);aero::refresh();
        }
        else if (cmd == "type") { std::string t; std::getline(ss, t); if (!t.empty() && t[0] == ' ') t.erase(0, 1);
            for (size_t k; (k = t.find("\\n")) != std::string::npos;) t.replace(k, 2, "\n");
            os::keyboard_type(t.c_str()); step(300); }
        else if (cmd == "monkey") {                /* random user: taps, swipes, holds, typing, app switches */
            int steps = 1000; unsigned seed = 1;
            ss >> steps >> seed;
            srand(seed);
            const auto& apps = os::apps();
            for (int k = 0; k < steps; k++) {
                int r = rand() % 100, x = rand() % display_w(), y = rand() % display_h();
                if (r < 45) { t_pressed = true; t_x = x; t_y = y; step(40 + rand() % 60); t_pressed = false; step(30 + rand() % 200); }
                else if (r < 55) { int x2 = rand() % display_w(), y2 = rand() % display_h(); drag(x, y, x2, y2, 60 + rand() % 300); step(50); }
                else if (r < 62) drag(20, 160, 220, 160, 150), step(300);                              /* back */
                else if (r < 67) os::go_home(false), step(300);                             /* home */
                else if (r < 72) { t_pressed = true; t_x = x; t_y = y; step(900); t_pressed = false; step(80); }   /* long press */
                else if (r < 77) { if (os::keyboard_visible()) os::keyboard_type(rand() % 3 ? "hello " : "a\n"); step(80); }
                else if (r < 82) { std::string id = apps[rand() % apps.size()].id; os::launch(id.c_str()); step(400); }
                else if (r < 84) { g_sim_usb_audio = !g_sim_usb_audio; step(100); }
                else if (r < 86) { g_sim_net = !g_sim_net; step(50); }
                else if (r < 87) { drag(x, 2, x, 6, 20); t_pressed = true; t_x = 120; t_y = 8; step(40); t_pressed = false; step(120); t_pressed = true; step(40); t_pressed = false; step(1500); t_pressed = true; step(40); t_pressed = false; step(300); } /* sleep + wake */
                else step(200 + rand() % 800);
                if (k % 10 == 9) { const os::App* ca = os::current_app(); audit(ca ? ca->id : "home"); }
            }
            fprintf(stderr, "[sim] monkey %d steps seed %u done\n", steps, seed);
        }
        else if (cmd == "audit") { std::string c; ss >> c; audit(c.empty() ? "screen" : c); }
        else if (cmd == "usb") { std::string v; ss >> v; g_sim_usb_audio = v == "on"; step(100); }
        else if (cmd == "net") { std::string v; ss >> v; g_sim_net = v == "on"; }
        else fprintf(stderr, "unknown command: %s\n", cmd.c_str());
    }
    art::clear();                       /* release the artwork cache so leak checks only show real leaks */
    return 0;
}
