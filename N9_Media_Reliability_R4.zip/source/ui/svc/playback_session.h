/* Bounded, versioned local-media sessions. File I/O runs on the storage worker;
 * a small atomic KV checkpoint selects the committed A/B snapshot. */
#pragma once
#include <cstddef>
#include <cstdint>
#include <cstdlib>
#include <functional>
#include <limits>
#include <memory>
#include <new>
#include <string>
#include <string_view>
#include <vector>
#ifdef NANO_TARGET_ESP32
#include <esp_heap_caps.h>
#endif

namespace playback_session {
constexpr size_t max_entries = 2048;
constexpr size_t max_path_bytes = 512;
constexpr size_t max_file_bytes = 256 * 1024;

// Session copies must not fill scarce internal Wi-Fi/DMA RAM with thousands
// of small std::string allocations. This allocator is local to these buffers;
// it never changes the library's or the system's global allocation policy.
#ifdef NANO_TARGET_ESP32
template<class T> struct StorageAllocator {
    using value_type = T;
    using is_always_equal = std::true_type;
    StorageAllocator() = default;
    template<class U> StorageAllocator(const StorageAllocator<U>&) {}
    T* allocate(size_t count) {
        void* p = count <= std::numeric_limits<size_t>::max() / sizeof(T)
            ? heap_caps_malloc(count * sizeof(T), MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT) : nullptr;
        if (!p) {
#ifdef __cpp_exceptions
            throw std::bad_alloc();
#else
            std::abort(); // preflight reduces risk; concurrent exhaustion is not fully recoverable
#endif
        }
        return static_cast<T*>(p);
    }
    void deallocate(T* p, size_t) { heap_caps_free(p); }
    template<class U> bool operator==(const StorageAllocator<U>&) const { return true; }
    template<class U> bool operator!=(const StorageAllocator<U>&) const { return false; }
};
#else
template<class T> using StorageAllocator = std::allocator<T>;
#endif
using Path = std::basic_string<char, std::char_traits<char>, StorageAllocator<char>>;
using Paths = std::vector<Path, StorageAllocator<Path>>;

// Conservative preflight for a snapshot + encoding/validation buffers. This
// cannot guarantee allocation after another task consumes/fragmentates PSRAM.
bool memory_available(size_t payload_bytes, size_t entries);

struct Snapshot {
    Paths order, queue; // card-relative paths; duplicates are significant
    bool shuffled = false;
    uint64_t identity = 0;
};
struct Checkpoint {
    uint64_t identity = 0;
    uint32_t index = 0, position_ms = 0;
    uint8_t slot = 0, repeat = 0;
    bool shuffle = false, paused = true;
};
struct Restored {
    std::vector<int> order, queue;
    int index = -1;
    uint32_t position_ms = 0;
    bool current_survived = false;
};
enum class Read { Missing, Invalid, Ok };

// Reject malformed paths, oversized sessions, and differing queue/order multisets.
bool seal(Snapshot& snapshot);
std::string encode_checkpoint(const Checkpoint& checkpoint);
bool decode_checkpoint(const std::string& text, Checkpoint& checkpoint);
Read read(const std::string& path, Snapshot& snapshot);
// Caller must select the INACTIVE slot. A failed replace never touches the active slot.
bool write_inactive(const std::string& path, const Snapshot& snapshot);
bool restore(const Snapshot& snapshot, const Checkpoint& checkpoint,
             const std::function<int(std::string_view)>& lookup,
             const std::function<uint32_t(int)>& duration, Restored& result);
uint32_t clamp_position(uint32_t position_ms, uint32_t duration_ms);
} // namespace playback_session
