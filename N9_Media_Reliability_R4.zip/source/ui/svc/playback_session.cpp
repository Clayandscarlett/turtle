#include "playback_session.h"
#include <algorithm>
#include <cerrno>
#include <cstdio>
#include <cstring>
#include <string_view>
#include <unistd.h>

namespace playback_session {
namespace {
using Bytes = std::vector<uint8_t, StorageAllocator<uint8_t>>;
constexpr uint8_t snapshot_magic[] = {'N','9','P','S',0,0,0,1};
constexpr uint8_t checkpoint_magic[] = {'N','9','P','C',0,0,0,1};
uint32_t crc(const uint8_t* p, size_t size) {
    uint32_t c = ~0u;
    for (size_t i = 0; i < size; ++i) {
        c ^= p[i];
        for (int b = 0; b < 8; ++b) c = (c >> 1) ^ (0xedb88320u & (0u - (c & 1u)));
    }
    return ~c;
}
void put(Bytes& bytes, uint64_t n, int size) {
    for (int i = 0; i < size; ++i) { bytes.push_back(uint8_t(n)); n >>= 8; }
}
bool take(const Bytes& bytes, size_t& at, uint64_t& n, int size) {
    if (at > bytes.size() || size_t(size) > bytes.size() - at) return false;
    n = 0;
    for (int i = 0; i < size; ++i) n |= uint64_t(bytes[at++]) << (8 * i);
    return true;
}
bool valid_path(std::string_view path) {
    if (path.size() < 2 || path.size() > max_path_bytes || path[0] != '/' || path.back() == '/') return false;
    if (path.find("//") != std::string::npos || path.find("/../") != std::string::npos ||
        path.find("/./") != std::string::npos || path.compare(path.size() - 2, 2, "/.") == 0 ||
        (path.size() >= 3 && path.compare(path.size() - 3, 3, "/..") == 0)) return false;
    for (unsigned char c : path) if (c < 32 || c == 127 || c == '\\') return false;
    return true;
}
bool valid(const Snapshot& s) {
    if (s.order.empty() || s.order.size() != s.queue.size() || s.order.size() > max_entries) return false;
    size_t size = 32;
    std::vector<std::string_view, StorageAllocator<std::string_view>> a, b;
    a.reserve(s.order.size()); b.reserve(s.queue.size());
    for (const auto* list : {&s.order, &s.queue}) for (const auto& path : *list) {
        if (!valid_path(path) || path.size() + 2 > max_file_bytes - size) return false;
        size += path.size() + 2;
    }
    for (const auto& p : s.order) a.emplace_back(p);
    for (const auto& p : s.queue) b.emplace_back(p);
    std::sort(a.begin(), a.end()); std::sort(b.begin(), b.end());
    return a == b;
}
uint64_t identity(const Snapshot& s) {
    uint64_t hash = 14695981039346656037ull;
    const auto add = [&hash](uint8_t c) { hash = (hash ^ c) * 1099511628211ull; };
    add(s.shuffled ? 1 : 0);
    for (const auto* list : {&s.order, &s.queue}) {
        add(uint8_t(list->size())); add(uint8_t(list->size() >> 8));
        for (const auto& path : *list) {
            add(uint8_t(path.size())); add(uint8_t(path.size() >> 8));
            for (unsigned char c : path) add(c);
        }
    }
    return hash ? hash : 1;
}
bool encode(const Snapshot& s, Bytes& bytes) {
    if (s.order.empty() || s.order.size() != s.queue.size() || s.order.size() > max_entries) return false;
    size_t total = 32;
    for (const auto* list : {&s.order, &s.queue}) for (const auto& p : *list) {
        if (p.size() + 2 > max_file_bytes - total) return false;
        total += p.size() + 2;
    }
    if (!memory_available(total, s.order.size())) return false;
    if (!valid(s) || !s.identity || s.identity != identity(s)) return false;
    bytes.assign(snapshot_magic, snapshot_magic + sizeof snapshot_magic);
    bytes.reserve(total);
    put(bytes, s.identity, 8); put(bytes, s.shuffled ? 1 : 0, 4); put(bytes, s.order.size(), 4);
    for (const auto* list : {&s.order, &s.queue}) for (const auto& p : *list) {
        put(bytes, p.size(), 2); bytes.insert(bytes.end(), p.begin(), p.end());
    }
    put(bytes, crc(bytes.data(), bytes.size()), 4);
    return true;
}
bool decode(const Bytes& bytes, Snapshot& result) {
    if (bytes.size() < 28 || bytes.size() > max_file_bytes ||
        std::memcmp(bytes.data(), snapshot_magic, sizeof snapshot_magic)) return false;
    size_t at = bytes.size() - 4; uint64_t checksum;
    if (!take(bytes, at, checksum, 4) || uint32_t(checksum) != crc(bytes.data(), bytes.size() - 4)) return false;
    at = 8; Snapshot s; uint64_t flags, count;
    if (!take(bytes, at, s.identity, 8) || !take(bytes, at, flags, 4) || flags > 1 ||
        !take(bytes, at, count, 4) || !count || count > max_entries) return false;
    s.shuffled = flags != 0;
    for (auto* list : {&s.order, &s.queue}) {
        list->reserve(size_t(count));
        for (uint64_t i = 0; i < count; ++i) {
            uint64_t len;
            if (!take(bytes, at, len, 2) || !len || len > max_path_bytes || at > bytes.size() - 4 || len > bytes.size() - 4 - at) return false;
            list->emplace_back(reinterpret_cast<const char*>(bytes.data() + at), size_t(len)); at += size_t(len);
        }
    }
    if (at != bytes.size() - 4 || !valid(s) || s.identity != identity(s)) return false;
    result = std::move(s);
    return true;
}
} // namespace

bool memory_available(size_t payload_bytes, size_t entries) {
#ifdef NANO_TARGET_ESP32
    if (payload_bytes > max_file_bytes || entries > max_entries) return false;
    constexpr size_t reserve = 128 * 1024;
    const size_t needed = payload_bytes * 3 + 2 * entries * (sizeof(Path) + sizeof(std::string_view) + 32);
    const size_t largest = std::max(payload_bytes, entries * sizeof(Path));
    constexpr uint32_t caps = MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT;
    return heap_caps_get_free_size(caps) >= needed + reserve && heap_caps_get_largest_free_block(caps) >= largest;
#else
    (void)payload_bytes; (void)entries;
    return true;
#endif
}

bool seal(Snapshot& snapshot) {
    if (!valid(snapshot)) return false;
    snapshot.identity = identity(snapshot);
    return true;
}

std::string encode_checkpoint(const Checkpoint& c) {
    if (!c.identity || c.slot > 1 || c.repeat > 2 || c.index >= max_entries) return {};
    Bytes bytes(checkpoint_magic, checkpoint_magic + sizeof checkpoint_magic);
    put(bytes, c.identity, 8); put(bytes, c.slot, 1); put(bytes, c.repeat, 1);
    put(bytes, (c.shuffle ? 1 : 0) | (c.paused ? 2 : 0), 2);
    put(bytes, c.index, 4); put(bytes, c.position_ms, 4);
    put(bytes, crc(bytes.data(), bytes.size()), 4);
    static const char hex[] = "0123456789abcdef";
    std::string out; out.reserve(bytes.size() * 2);
    for (uint8_t b : bytes) { out += hex[b >> 4]; out += hex[b & 15]; }
    return out;
}
bool decode_checkpoint(const std::string& text, Checkpoint& result) {
    if (text.size() != 64) return false;
    const auto digit = [](char c) -> int { return c >= '0' && c <= '9' ? c - '0' : c >= 'a' && c <= 'f' ? c - 'a' + 10 : -1; };
    Bytes bytes; bytes.reserve(32);
    for (size_t i = 0; i < text.size(); i += 2) {
        int a = digit(text[i]), b = digit(text[i+1]); if (a < 0 || b < 0) return false;
        bytes.push_back(uint8_t(a * 16 + b));
    }
    if (std::memcmp(bytes.data(), checkpoint_magic, sizeof checkpoint_magic)) return false;
    size_t at = 28; uint64_t n;
    if (!take(bytes, at, n, 4) || uint32_t(n) != crc(bytes.data(), 28)) return false;
    Checkpoint c; at = 8;
    if (!take(bytes, at, c.identity, 8) || !c.identity || !take(bytes, at, n, 1) || n > 1) return false;
    c.slot = uint8_t(n);
    if (!take(bytes, at, n, 1) || n > 2) return false;
    c.repeat = uint8_t(n);
    if (!take(bytes, at, n, 2) || n > 3) return false;
    c.shuffle = (n & 1) != 0; c.paused = (n & 2) != 0;
    if (!take(bytes, at, n, 4) || n >= max_entries) return false;
    c.index = uint32_t(n);
    if (!take(bytes, at, n, 4)) return false;
    c.position_ms = uint32_t(n);
    result = c; return true;
}

Read read(const std::string& path, Snapshot& snapshot) {
    FILE* f = fopen(path.c_str(), "rb");
    if (!f) return errno == ENOENT ? Read::Missing : Read::Invalid;
    bool ok = fseek(f, 0, SEEK_END) == 0;
    long size = ok ? ftell(f) : -1;
    ok = size >= 28 && size <= long(max_file_bytes) && memory_available(size_t(size), max_entries) && fseek(f, 0, SEEK_SET) == 0;
    Bytes bytes;
    if (ok) { bytes.resize(size_t(size)); ok = fread(bytes.data(), 1, bytes.size(), f) == bytes.size() && !ferror(f); }
    if (fclose(f) != 0) ok = false;
    return ok && decode(bytes, snapshot) ? Read::Ok : Read::Invalid;
}
bool write_inactive(const std::string& path, const Snapshot& snapshot) {
    Bytes bytes; if (!encode(snapshot, bytes)) return false;
    std::string temporary = path + ".tmp";
    FILE* f = fopen(temporary.c_str(), "wb"); if (!f) return false;
    bool ok = fwrite(bytes.data(), 1, bytes.size(), f) == bytes.size();
    if (ok) ok = fflush(f) == 0 && fsync(fileno(f)) == 0;
    if (fclose(f) != 0) ok = false;
    if (!ok) { std::remove(temporary.c_str()); return false; }
    if (std::rename(temporary.c_str(), path.c_str()) != 0) {
        // FAT may reject rename over an existing file. This slot is unreferenced;
        // the active slot and its checkpoint are never removed or rewritten here.
        if (std::remove(path.c_str()) != 0 && errno != ENOENT) { std::remove(temporary.c_str()); return false; }
        if (std::rename(temporary.c_str(), path.c_str()) != 0) { std::remove(temporary.c_str()); return false; }
    }
    return true;
}

uint32_t clamp_position(uint32_t position_ms, uint32_t duration_ms) {
    return duration_ms && position_ms >= duration_ms ? duration_ms - 1 : position_ms;
}
bool restore(const Snapshot& s, const Checkpoint& c,
             const std::function<int(std::string_view)>& lookup,
             const std::function<uint32_t(int)>& duration, Restored& result) {
    if (s.identity != c.identity || c.index >= s.queue.size() || !valid(s) || s.identity != identity(s)) return false;
    Restored out; int before = 0;
    out.order.reserve(s.order.size()); out.queue.reserve(s.queue.size());
    for (const auto& path : s.order) { int id = lookup(path); if (id >= 0) out.order.push_back(id); }
    for (size_t i = 0; i < s.queue.size(); ++i) {
        int id = lookup(s.queue[i]);
        if (id >= 0) { if (i == c.index) out.current_survived = true; out.queue.push_back(id); }
        else if (i < c.index) ++before;
    }
    if (out.queue.empty()) return false;
    out.index = std::min<int>(int(c.index) - before, int(out.queue.size()) - 1);
    out.position_ms = out.current_survived ? clamp_position(c.position_ms, duration(out.queue[out.index])) : 0;
    result = std::move(out); return true;
}
} // namespace playback_session
