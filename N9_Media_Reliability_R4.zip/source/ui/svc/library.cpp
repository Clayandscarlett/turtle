#include "library.h"
#include "../hal.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <dirent.h>
#include <sys/stat.h>
#include <algorithm>
#include <map>
#include <set>
#include <memory>
#include <unordered_map>
#include <string_view>
#include <errno.h>
#include <limits.h>
#include <unistd.h>

namespace lib {

static std::vector<Track> s_tracks;
static bool s_scanning = false;
static int s_version = 0;
static const char* kDirs[3] = {"/Music", "/Podcasts", "/Audiobooks"};
/* path -> id; the views point into s_tracks[i].path and are rebuilt whenever s_tracks is replaced */
static std::unordered_map<std::string_view, int> s_index;
static std::vector<std::function<void(const std::vector<int>&)>> s_reindex_cbs;

const std::vector<Track>& tracks() { return s_tracks; }
const Track* get(int id) { return id >= 0 && id < (int)s_tracks.size() ? &s_tracks[id] : nullptr; }
bool scanning() { return s_scanning; }
int version() { return s_version; }
static void rebuild_index() {
    s_index.clear();
    s_index.reserve(s_tracks.size());
    for (size_t i = 0; i < s_tracks.size(); i++) s_index.emplace(std::string_view(s_tracks[i].path), (int)i);
}
int find_path(const std::string& p) {
    auto it = s_index.find(std::string_view(p));
    return it == s_index.end() ? -1 : it->second;
}
void on_reindex(std::function<void(const std::vector<int>&)> cb) { if (cb) s_reindex_cbs.push_back(std::move(cb)); }

static std::string root(const char* rel) { return std::string(hal::fs_root()) + rel; }

/* ------------------------------------------------------------------ text helpers */
static void append_utf8(std::string& o, uint32_t cp) {
    if (cp < 0x80) o += (char)cp;
    else if (cp < 0x800) { o += (char)(0xC0 | (cp >> 6)); o += (char)(0x80 | (cp & 0x3F)); }
    else if (cp < 0x10000) { o += (char)(0xE0 | (cp >> 12)); o += (char)(0x80 | ((cp >> 6) & 0x3F)); o += (char)(0x80 | (cp & 0x3F)); }
    else { o += (char)(0xF0 | (cp >> 18)); o += (char)(0x80 | ((cp >> 12) & 0x3F)); o += (char)(0x80 | ((cp >> 6) & 0x3F)); o += (char)(0x80 | (cp & 0x3F)); }
}

static std::string latin1(const uint8_t* p, size_t n) {
    std::string o;
    for (size_t i = 0; i < n && p[i]; i++) append_utf8(o, p[i]);
    return o;
}

static std::string utf16(const uint8_t* p, size_t n, bool be) {
    std::string o;
    size_t i = 0;
    if (n >= 2 && p[0] == 0xFF && p[1] == 0xFE) { be = false; i = 2; }
    else if (n >= 2 && p[0] == 0xFE && p[1] == 0xFF) { be = true; i = 2; }
    for (; i + 1 < n; i += 2) {
        uint32_t u = be ? (p[i] << 8 | p[i + 1]) : (p[i + 1] << 8 | p[i]);
        if (!u) break;
        if (u >= 0xD800 && u < 0xDC00) {                 /* high surrogate: needs a following low one */
            uint32_t l = i + 3 < n ? (be ? (p[i + 2] << 8 | p[i + 3]) : (p[i + 3] << 8 | p[i + 2])) : 0;
            if (l >= 0xDC00 && l < 0xE000) { u = 0x10000 + ((u - 0xD800) << 10) + (l - 0xDC00); i += 2; }
            else u = 0xFFFD;                              /* unpaired: keep the next unit */
        } else if (u >= 0xDC00 && u < 0xE000) u = 0xFFFD;   /* lone low surrogate */
        append_utf8(o, u);
    }
    return o;
}

static std::string trim(std::string s) {
    while (!s.empty() && (s.back() == ' ' || s.back() == '\0' || s.back() == '\r' || s.back() == '\n')) s.pop_back();
    size_t a = 0;
    while (a < s.size() && s[a] == ' ') a++;
    return s.substr(a);
}

static std::string id3_text(const uint8_t* p, size_t n) {
    if (!n) return "";
    uint8_t enc = p[0];
    p++; n--;
    std::string s;
    if (enc == 0) s = latin1(p, n);
    else if (enc == 1) s = utf16(p, n, false);
    else if (enc == 2) s = utf16(p, n, true);
    else { size_t k = 0; while (k < n && p[k]) k++; s.assign((const char*)p, k); }
    return trim(s);
}

static const char* kGenres[] = {"Blues","Classic Rock","Country","Dance","Disco","Funk","Grunge","Hip-Hop","Jazz","Metal",
    "New Age","Oldies","Other","Pop","R&B","Rap","Reggae","Rock","Techno","Industrial","Alternative","Ska","Death Metal",
    "Pranks","Soundtrack","Euro-Techno","Ambient","Trip-Hop","Vocal","Jazz+Funk","Fusion","Trance","Classical",
    "Instrumental","Acid","House","Game","Sound Clip","Gospel","Noise","Alternative Rock","Bass","Soul","Punk","Space",
    "Meditative","Instrumental Pop","Instrumental Rock","Ethnic","Gothic","Darkwave","Techno-Industrial","Electronic",
    "Pop-Folk","Eurodance","Dream","Southern Rock","Comedy","Cult","Gangsta","Top 40","Christian Rap","Pop/Funk","Jungle",
    "Native American","Cabaret","New Wave","Psychedelic","Rave","Showtunes","Trailer","Lo-Fi","Tribal","Acid Punk",
    "Acid Jazz","Polka","Retro","Musical","Rock & Roll","Hard Rock"};
static std::string genre_name(std::string g) {
    /* "(17)" or "17" or "(17)Rock" */
    if (!g.empty() && (g[0] == '(' || isdigit((unsigned char)g[0]))) {
        size_t i = g[0] == '(' ? 1 : 0;
        int n = atoi(g.c_str() + i);
        size_t close = g.find(')');
        std::string rest = close != std::string::npos ? g.substr(close + 1) : "";
        if (!rest.empty()) return rest;
        if (n >= 0 && n < (int)(sizeof kGenres / sizeof kGenres[0]) && (isdigit((unsigned char)g[i]))) return kGenres[n];
    }
    return g;
}

/* ------------------------------------------------------------------ tag readers */
struct Reader {
    FILE* f;
    uint32_t size;
    bool rd(uint32_t off, void* buf, size_t n) { return fseek(f, off, SEEK_SET) == 0 && fread(buf, 1, n, f) == n; }
};
static uint32_t be32(const uint8_t* p) { return (uint32_t)p[0] << 24 | p[1] << 16 | p[2] << 8 | p[3]; }
static uint32_t le32(const uint8_t* p) { return (uint32_t)p[3] << 24 | p[2] << 16 | p[1] << 8 | p[0]; }
static uint32_t syncsafe(const uint8_t* p) { return (p[0] & 0x7F) << 21 | (p[1] & 0x7F) << 14 | (p[2] & 0x7F) << 7 | (p[3] & 0x7F); }

static void apply_num(uint16_t& dst, const std::string& s) { int n = atoi(s.c_str()); if (n > 0 && n < 65535) dst = (uint16_t)n; }

/* removes ID3 unsynchronisation (FF 00 -> FF) in place */
static void deunsync(std::vector<uint8_t>& b) {
    size_t w = 0;
    for (size_t i = 0; i < b.size(); i++) {
        b[w++] = b[i];
        if (b[i] == 0xFF && i + 1 < b.size() && b[i + 1] == 0x00) i++;
    }
    b.resize(w);
}

static void apply_id3_text(Track& t, const char* id, const std::string& v) {
    if (!strcmp(id, "TIT2") || !strcmp(id, "TT2")) t.title = v;
    else if (!strcmp(id, "TPE1") || !strcmp(id, "TP1")) t.artist = v;
    else if (!strcmp(id, "TALB") || !strcmp(id, "TAL")) t.album = v;
    else if (!strcmp(id, "TPE2") || !strcmp(id, "TP2")) t.album_artist = v;
    else if (!strcmp(id, "TCON") || !strcmp(id, "TCO")) t.genre = genre_name(v);
    else if (!strcmp(id, "TCOM") || !strcmp(id, "TCM")) t.composer = v;
    else if (!strcmp(id, "TRCK") || !strcmp(id, "TRK")) apply_num(t.track, v);
    else if (!strcmp(id, "TPOS") || !strcmp(id, "TPA")) apply_num(t.disc, v);
    else if (!strcmp(id, "TYER") || !strcmp(id, "TYE") || !strcmp(id, "TDRC")) apply_num(t.year, v.substr(0, 4));
    else if (!strcmp(id, "TLEN") || !strcmp(id, "TLE")) { long ms = atol(v.c_str()); if (ms > 0) t.dur_ms = (uint32_t)ms; }
}

static bool id3_id_ok(const uint8_t* p, int n) {
    for (int i = 0; i < n; i++) if (!((p[i] >= 'A' && p[i] <= 'Z') || (p[i] >= '0' && p[i] <= '9'))) return false;
    return true;
}

/* APIC / PIC header: finds where the picture bytes start inside the frame */
static void id3_picture(Reader& r, Track& t, int ver, uint64_t data_off, uint64_t fs) {
    uint8_t ph[300];
    uint32_t n = fs < sizeof ph ? (uint32_t)fs : (uint32_t)sizeof ph;
    if (n < 4 || data_off > 0xFFFFFFFFu || !r.rd((uint32_t)data_off, ph, n)) return;
    uint8_t enc = ph[0];
    uint32_t k = 1;
    if (ver == 2) k = 4;
    else { while (k < n && ph[k]) k++; k++; }
    k++;                                             /* picture type */
    if (enc == 1 || enc == 2) { while (k + 1 < n && (ph[k] || ph[k + 1])) k += 2; k += 2; }
    else { while (k < n && ph[k]) k++; k++; }
    if (k + 4 > n || k >= fs) return;
    uint64_t off = data_off + k, len = fs - k;
    if (off + len > r.size) return;
    uint8_t* sig = ph + k;
    uint8_t type = (sig[0] == 0xFF && sig[1] == 0xD8) ? ART_JPEG : (sig[0] == 0x89 && sig[1] == 'P') ? ART_PNG : ART_NONE;
    if (!type) return;
    t.art_off = (uint32_t)off;
    t.art_len = (uint32_t)len;
    t.art_type = type;
}

static uint32_t parse_id3v2(Reader& r, Track& t) {
    uint8_t h[10];
    if (!r.rd(0, h, 10) || memcmp(h, "ID3", 3)) return 0;
    int ver = h[3];
    uint64_t tag_size = (uint64_t)syncsafe(h + 6) + 10;
    if (ver == 4 && (h[5] & 0x10)) tag_size += 10;    /* footer */
    if (ver < 2 || ver > 4) return (uint32_t)tag_size;
    if (ver == 2 && (h[5] & 0x40)) return (uint32_t)tag_size;   /* v2.2 "compression": undefined, skip */
    bool tag_unsync = h[5] & 0x80;
    int idlen = ver == 2 ? 3 : 4, hlen = ver == 2 ? 6 : 10;
    uint64_t end = tag_size;                          /* frames live in [10, end) */
    if (ver == 4 && (h[5] & 0x10)) end -= 10;

    /* v2.2 / v2.3 unsynchronisation covers the whole tag (frame headers included): de-unsync a bounded
     * copy in memory and parse that. Picture offsets would not map to the file, so no artwork then. */
    std::vector<uint8_t> mem;
    bool in_mem = tag_unsync && ver < 4;
    if (in_mem) {
        uint64_t want = end - 10;
        if (want > 256 * 1024) want = 256 * 1024;
        if (want > r.size - 10 && r.size > 10) want = r.size - 10;
        mem.resize((size_t)want);
        if (mem.empty() || !r.rd(10, mem.data(), mem.size())) return (uint32_t)tag_size;
        deunsync(mem);
        end = 10 + mem.size();
    }
    auto rd = [&](uint64_t off, void* buf, size_t n) -> bool {
        if (off + n > end) return false;
        if (in_mem) { memcpy(buf, mem.data() + (off - 10), n); return true; }
        return r.rd((uint32_t)off, buf, n);
    };

    uint64_t pos = 10;
    if (ver >= 3 && (h[5] & 0x40)) {                  /* extended header */
        uint8_t e[4];
        if (!rd(pos, e, 4)) return (uint32_t)tag_size;
        pos += ver == 4 ? (uint64_t)syncsafe(e) : (uint64_t)be32(e) + 4;
    }
    std::vector<uint8_t> buf;
    while (pos + hlen <= end) {
        uint8_t fh[10];
        if (!rd(pos, fh, hlen)) break;
        if (fh[0] == 0 || !id3_id_ok(fh, idlen)) break;   /* padding / garbage */
        uint64_t fs = ver == 2 ? (uint64_t)(fh[3] << 16 | fh[4] << 8 | fh[5]) : (ver == 4 ? syncsafe(fh + 4) : be32(fh + 4));
        uint64_t data_off = pos + hlen;
        if (data_off + fs > end) break;
        pos = data_off + fs;
        if (fs == 0) continue;
        char id[5] = {0};
        memcpy(id, fh, idlen);
        uint8_t fl = ver == 2 ? 0 : fh[9];
        /* per-frame format flags */
        uint64_t skip = 0;
        bool frame_unsync = false, usable = true;
        if (ver == 3) {
            if (fl & 0x80) usable = false;             /* zlib compressed */
            if (fl & 0x40) usable = false;             /* encrypted */
            if (fl & 0x20) skip += 1;                  /* group id */
        } else if (ver == 4) {
            if (fl & 0x40) skip += 1;                  /* group id */
            if (fl & 0x08) usable = false;             /* compressed */
            if (fl & 0x04) usable = false;             /* encrypted */
            if (fl & 0x01) skip += 4;                  /* data length indicator */
            frame_unsync = (fl & 0x02) || tag_unsync;
        }
        if (!usable || skip >= fs) continue;
        uint64_t doff = data_off + skip, dlen = fs - skip;
        bool is_pic = !strcmp(id, "APIC") || !strcmp(id, "PIC");
        if (is_pic) {
            if (!t.art_type && !in_mem && !frame_unsync) id3_picture(r, t, ver, doff, dlen);
        } else if (id[0] == 'T' && dlen < 4096) {
            buf.resize((size_t)dlen);
            if (rd(doff, buf.data(), buf.size())) {
                if (frame_unsync) deunsync(buf);
                apply_id3_text(t, id, id3_text(buf.data(), buf.size()));
            }
        }
    }
    return tag_size > 0xFFFFFFFFu ? 0xFFFFFFFFu : (uint32_t)tag_size;
}

static void parse_id3v1(Reader& r, Track& t) {
    if (r.size < 128) return;
    uint8_t b[128];
    if (!r.rd(r.size - 128, b, 128) || memcmp(b, "TAG", 3)) return;
    if (t.title.empty()) t.title = trim(latin1(b + 3, 30));
    if (t.artist.empty()) t.artist = trim(latin1(b + 33, 30));
    if (t.album.empty()) t.album = trim(latin1(b + 63, 30));
    if (!t.year) { char y[5] = {0}; memcpy(y, b + 93, 4); apply_num(t.year, y); }
    if (!t.track && b[125] == 0 && b[126]) t.track = b[126];
    if (t.genre.empty() && b[127] < sizeof kGenres / sizeof kGenres[0]) t.genre = kGenres[b[127]];
}

static void mp3_duration(Reader& r, uint32_t start, Track& t) {
    if (t.dur_ms || start >= r.size) return;
    uint8_t b[4096];
    uint32_t n = r.size - start < sizeof b ? r.size - start : sizeof b;
    if (!r.rd(start, b, n)) return;
    static const int br1[] = {0, 32, 40, 48, 56, 64, 80, 96, 112, 128, 160, 192, 224, 256, 320, 0};
    static const int br2[] = {0, 8, 16, 24, 32, 40, 48, 56, 64, 80, 96, 112, 128, 144, 160, 0};
    static const int sr1[] = {44100, 48000, 32000, 0};
    for (uint32_t i = 0; i + 4 < n; i++) {
        if (b[i] != 0xFF || (b[i + 1] & 0xE0) != 0xE0) continue;
        int ver = (b[i + 1] >> 3) & 3;              /* 3 = MPEG1, 2 = MPEG2, 0 = MPEG2.5 */
        int layer = (b[i + 1] >> 1) & 3;
        int bri = b[i + 2] >> 4, sri = (b[i + 2] >> 2) & 3;
        if (ver == 1 || layer != 1 || bri == 0 || bri == 15 || sri == 3) continue;
        int sr = sr1[sri] >> (ver == 3 ? 0 : (ver == 2 ? 1 : 2));
        int kbps = ver == 3 ? br1[bri] : br2[bri];
        bool mono = (b[i + 3] >> 6) == 3;
        int spf = ver == 3 ? 1152 : 576;
        int side = ver == 3 ? (mono ? 17 : 32) : (mono ? 9 : 17);
        uint32_t x = i + 4 + side;
        if (x + 12 < n && (!memcmp(b + x, "Xing", 4) || !memcmp(b + x, "Info", 4))) {
            uint32_t flags = be32(b + x + 4);
            if (flags & 1) { uint32_t frames = be32(b + x + 8); t.dur_ms = (uint32_t)((uint64_t)frames * spf * 1000 / sr); return; }
        }
        uint32_t v = i + 4 + 32;
        if (v + 18 < n && !memcmp(b + v, "VBRI", 4)) {
            uint32_t frames = be32(b + v + 14);
            t.dur_ms = (uint32_t)((uint64_t)frames * spf * 1000 / sr);
            return;
        }
        if (kbps) {
            uint32_t audio = r.size - (start + i);
            if (r.size >= 128) { uint8_t tg[3]; if (r.rd(r.size - 128, tg, 3) && !memcmp(tg, "TAG", 3)) audio -= 128; }
            t.dur_ms = (uint32_t)((uint64_t)audio * 8 / kbps);
        }
        return;
    }
}

static void parse_flac(Reader& r, Track& t) {
    uint8_t h[4];
    if (!r.rd(0, h, 4) || memcmp(h, "fLaC", 4)) return;
    uint64_t pos = 4;
    for (int guard = 0; guard < 64; guard++) {
        uint8_t bh[4];
        if (pos + 4 > r.size || !r.rd((uint32_t)pos, bh, 4)) return;
        bool last = bh[0] & 0x80;
        int type = bh[0] & 0x7F;
        uint32_t len = bh[1] << 16 | bh[2] << 8 | bh[3];
        uint32_t d = (uint32_t)(pos + 4);
        if ((uint64_t)d + len > r.size) return;       /* truncated / corrupt block */
        if (type == 0 && len >= 18) {
            uint8_t s[18];
            if (r.rd(d, s, 18)) {
                uint32_t rate = (s[10] << 12) | (s[11] << 4) | (s[12] >> 4);
                uint64_t total = ((uint64_t)(s[13] & 0x0F) << 32) | be32(s + 14);
                if (rate) t.dur_ms = (uint32_t)(total * 1000 / rate);
            }
        } else if (type == 4 && len >= 8 && len <= 65536) {   /* text only; big blocks are embedded art */
            std::vector<uint8_t> v(len);
            if (r.rd(d, v.data(), len)) {
                uint32_t p = 0;
                uint32_t vl = le32(&v[p]); p += 4;
                if (vl <= len - p - 4) {                     /* vendor string + comment count fit */
                    p += vl;
                    uint32_t cnt = le32(&v[p]); p += 4;
                    for (uint32_t c = 0; c < cnt && len - p >= 4; c++) {
                        uint32_t l = le32(&v[p]); p += 4;
                        if (l > len - p) break;
                        std::string kv((char*)&v[p], l);
                        p += l;
                        size_t eq = kv.find('=');
                        if (eq == std::string::npos) continue;
                        std::string k = kv.substr(0, eq), val = trim(kv.substr(eq + 1));
                        for (auto& ch : k) ch = (char)toupper((unsigned char)ch);
                        if (k == "TITLE") t.title = val;
                        else if (k == "ARTIST") t.artist = val;
                        else if (k == "ALBUM") t.album = val;
                        else if (k == "ALBUMARTIST" || k == "ALBUM ARTIST") t.album_artist = val;
                        else if (k == "GENRE") t.genre = val;
                        else if (k == "COMPOSER") t.composer = val;
                        else if (k == "TRACKNUMBER") apply_num(t.track, val);
                        else if (k == "DISCNUMBER") apply_num(t.disc, val);
                        else if (k == "DATE" || k == "YEAR") apply_num(t.year, val.substr(0, 4));
                    }
                }
            }
        } else if (type == 6 && !t.art_type && len >= 32) {
            /* PICTURE: type(4) mime_len(4) mime desc_len(4) desc w h depth colors(16) data_len(4) data */
            uint8_t b[8];
            uint64_t k = 0;
            if (r.rd(d, b, 8)) {
                uint64_t ml = be32(b + 4);
                k = 8;
                std::string mime;
                if (ml <= len - k) {
                    char mb[64];
                    uint32_t mn = ml < sizeof mb ? (uint32_t)ml : (uint32_t)sizeof mb;
                    if (mn && r.rd(d + (uint32_t)k, mb, mn)) mime.assign(mb, mn);
                    k += ml;
                    uint8_t x[4];
                    if (k + 4 <= len && r.rd(d + (uint32_t)k, x, 4)) {
                        uint64_t dl = be32(x);
                        k += 4;
                        if (dl <= len - k && k + dl + 16 + 4 <= len) {
                            k += dl + 16;
                            if (r.rd(d + (uint32_t)k, x, 4)) {
                                uint64_t plen = be32(x);
                                k += 4;
                                if (plen && plen <= len - k) {
                                    t.art_off = d + (uint32_t)k;
                                    t.art_len = (uint32_t)plen;
                                    t.art_type = mime.find("png") != std::string::npos ? ART_PNG : ART_JPEG;
                                }
                            }
                        }
                    }
                }
            }
        }
        pos = (uint64_t)d + len;
        if (last) break;
    }
}

/* MP4 / M4A atoms */
static void mp4_walk(Reader& r, uint32_t start, uint32_t end, Track& t, int depth, const char* parent) {
    uint32_t pos = start;
    while (pos + 8 <= end && depth < 8) {
        uint8_t h[16];
        if (!r.rd(pos, h, 8)) return;
        uint64_t sz = be32(h);
        char type[5] = {0};
        memcpy(type, h + 4, 4);
        uint32_t hdr = 8;
        if (sz == 1) { if (!r.rd(pos + 8, h + 8, 8)) return; sz = ((uint64_t)be32(h + 8) << 32) | be32(h + 12); hdr = 16; }
        else if (sz == 0) sz = end - pos;
        if (sz < hdr || pos + sz > end) return;
        uint32_t body = pos + hdr, bend = (uint32_t)(pos + sz);
        if (!strcmp(type, "moov") || !strcmp(type, "udta") || !strcmp(type, "ilst")) mp4_walk(r, body, bend, t, depth + 1, type);
        else if (!strcmp(type, "meta")) mp4_walk(r, body + 4, bend, t, depth + 1, type);
        else if (!strcmp(type, "mvhd")) {
            uint8_t m[32];
            if (r.rd(body, m, 32)) {
                if (m[0] == 0) { uint32_t ts = be32(m + 12), du = be32(m + 16); if (ts) t.dur_ms = (uint32_t)((uint64_t)du * 1000 / ts); }
                else { uint32_t ts = be32(m + 20); uint8_t d8[8]; if (r.rd(body + 24, d8, 8) && ts) t.dur_ms = (uint32_t)((((uint64_t)be32(d8) << 32) | be32(d8 + 4)) * 1000 / ts); }
            }
        } else if (parent && !strcmp(parent, "ilst")) {
            /* item atom -> 'data' child */
            uint8_t dh[16];
            if (bend - body >= 16 && r.rd(body, dh, 16) && !memcmp(dh + 4, "data", 4) &&
                be32(dh) >= 16 && be32(dh) <= bend - body) {
                uint32_t dlen = be32(dh) - 16, doff = body + 16;
                uint32_t dtype = be32(dh + 8) & 0xFFFFFF;
                if (!strcmp(type, "covr")) {
                    if (!t.art_type) { t.art_off = doff; t.art_len = dlen; t.art_type = dtype == 14 ? ART_PNG : ART_JPEG; }
                } else if (dlen < 1024) {
                    std::vector<uint8_t> v(dlen);
                    if (r.rd(doff, v.data(), dlen)) {
                        std::string s((char*)v.data(), dlen);
                        const unsigned char* ty = (const unsigned char*)type;
                        if (ty[0] == 0xA9) {
                            std::string k(type + 1, 3);
                            if (k == "nam") t.title = trim(s);
                            else if (k == "ART") t.artist = trim(s);
                            else if (k == "alb") t.album = trim(s);
                            else if (k == "gen") t.genre = trim(s);
                            else if (k == "wrt") t.composer = trim(s);
                            else if (k == "day") apply_num(t.year, s.substr(0, 4));
                        } else if (!strcmp(type, "aART")) t.album_artist = trim(s);
                        else if (!strcmp(type, "trkn") && dlen >= 4) t.track = v[2] << 8 | v[3];
                        else if (!strcmp(type, "disk") && dlen >= 4) t.disc = v[2] << 8 | v[3];
                        else if (!strcmp(type, "gnre") && dlen >= 2) { int g = (v[0] << 8 | v[1]) - 1; if (g >= 0 && g < (int)(sizeof kGenres / sizeof kGenres[0])) t.genre = kGenres[g]; }
                    }
                }
            }
        }
        pos = bend;
    }
}

static void parse_wav(Reader& r, Track& t) {
    uint8_t h[12];
    if (!r.rd(0, h, 12) || memcmp(h, "RIFF", 4) || memcmp(h + 8, "WAVE", 4)) return;
    uint64_t pos = 12;
    uint32_t byte_rate = 0;
    for (int guard = 0; guard < 4096 && pos + 8 <= r.size; guard++) {
        uint8_t c[8];
        if (!r.rd((uint32_t)pos, c, 8)) break;
        uint64_t len = le32(c + 4);
        uint64_t avail = r.size - pos - 8;
        if (!memcmp(c, "fmt ", 4)) { uint8_t f[16]; if (len >= 16 && r.rd((uint32_t)pos + 8, f, 16)) byte_rate = le32(f + 8); }
        else if (!memcmp(c, "data", 4)) {
            /* streamed WAVs write 0 / 0xFFFFFFFF: use what the file really holds */
            uint64_t dl = (len == 0 || len > avail) ? avail : len;
            if (byte_rate) t.dur_ms = (uint32_t)std::min<uint64_t>(dl * 1000 / byte_rate, 0xFFFFFFFFu);
        }
        else if (!memcmp(c, "LIST", 4) && len > 4 && len < 8192 && len <= avail) {
            std::vector<uint8_t> v((size_t)len);
            if (r.rd((uint32_t)pos + 8, v.data(), (size_t)len) && !memcmp(v.data(), "INFO", 4)) {
                uint32_t p = 4;
                while (p + 8 <= len) {
                    uint32_t l = le32(&v[p + 4]);
                    if (l > len - p - 8) break;
                    std::string val = trim(std::string((char*)&v[p + 8], l));
                    if (!memcmp(&v[p], "INAM", 4)) t.title = val;
                    else if (!memcmp(&v[p], "IART", 4)) t.artist = val;
                    else if (!memcmp(&v[p], "IPRD", 4)) t.album = val;
                    else if (!memcmp(&v[p], "IGNR", 4)) t.genre = val;
                    p += 8 + l + (l & 1);
                }
            }
        }
        if (len > avail) break;                       /* chunk runs past the end of the file */
        pos += 8 + len + (len & 1);
    }
}

static std::string ext_of(const std::string& p) {
    size_t d = p.rfind('.');
    std::string e = d == std::string::npos ? "" : p.substr(d + 1);
    for (auto& c : e) c = (char)tolower((unsigned char)c);
    return e;
}

static bool audio_ext(const std::string& e) {
    return e == "mp3" || e == "m4a" || e == "aac" || e == "m4b" || e == "flac" || e == "wav" || e == "ogg" || e == "opus";
}

static void title_from_name(Track& t) {
    size_t s = t.path.rfind('/');
    std::string n = t.path.substr(s == std::string::npos ? 0 : s + 1);
    size_t d = n.rfind('.');
    if (d != std::string::npos) n = n.substr(0, d);
    /* "03 - Name" / "03. Name" / "03 Name" */
    size_t i = 0;
    while (i < n.size() && isdigit((unsigned char)n[i])) i++;
    if (i > 0 && i <= 3 && i < n.size() && (n[i] == ' ' || n[i] == '.' || n[i] == '-' || n[i] == '_')) {
        if (!t.track) t.track = (uint16_t)atoi(n.substr(0, i).c_str());
        while (i < n.size() && (n[i] == ' ' || n[i] == '.' || n[i] == '-' || n[i] == '_')) i++;
        n = n.substr(i);
    }
    for (auto& c : n) if (c == '_') c = ' ';
    t.title = n;
}

static void read_tags(Track& t) {
    FILE* f = fopen(t.path.c_str(), "rb");
    if (!f) return;
    static char iobuf[4096];
    setvbuf(f, iobuf, _IOFBF, sizeof iobuf);
    Reader r{f, t.size};
    std::string e = ext_of(t.path);
    if (e == "mp3") {
        uint32_t start = parse_id3v2(r, t);
        parse_id3v1(r, t);
        mp3_duration(r, start, t);
    } else if (e == "flac") parse_flac(r, t);
    else if (e == "m4a" || e == "m4b" || e == "aac") { if (e == "aac") parse_id3v2(r, t); else mp4_walk(r, 0, t.size, t, 0, nullptr); }
    else if (e == "wav") parse_wav(r, t);
    fclose(f);
    if (t.title.empty()) title_from_name(t);
    if (t.kind != K_MUSIC && t.album.empty()) {
        /* podcast show / book = parent folder name */
        size_t s = t.path.rfind('/');
        size_t s2 = s == std::string::npos ? std::string::npos : t.path.rfind('/', s - 1);
        if (s2 != std::string::npos) t.album = t.path.substr(s2 + 1, s - s2 - 1);
    }
}

/* ------------------------------------------------------------------ database */
static std::string esc(const std::string& s) {
    std::string o;
    for (char c : s) {
        if (c == '\t') o += "\\t"; else if (c == '\n') o += "\\n"; else if (c == '\\') o += "\\\\"; else o += c;
    }
    return o;
}
static std::string unesc(const std::string& s) {
    std::string o;
    for (size_t i = 0; i < s.size(); i++) {
        if (s[i] == '\\' && i + 1 < s.size()) { char n = s[++i]; o += n == 't' ? '\t' : n == 'n' ? '\n' : n; }
        else o += s[i];
    }
    return o;
}
static std::vector<std::string> split_tab(const std::string& l) {
    std::vector<std::string> v;
    size_t p = 0;
    for (;;) {
        size_t e = l.find('\t', p);
        v.push_back(l.substr(p, e == std::string::npos ? std::string::npos : e - p));
        if (e == std::string::npos) break;
        p = e + 1;
    }
    return v;
}

static const char* kDbVer = "NANOLIB3";

/* Keep the old, fully written file until the replacement has been closed and
 * synced. FAT cannot reliably rename over an existing destination, so rotate
 * the old file to a retained backup first. If either rename fails (or boot
 * stops between them), the loader can still read that backup. A staging file
 * alone is never treated as a committed save. */
struct StoreState { bool primary_valid = false, backup_valid = false, failed = false; };
static StoreState s_db_store, s_stats_store;
static constexpr size_t kStoreMaxBytes = 16 * 1024 * 1024;
static constexpr size_t kStoreMaxLine = 128 * 1024;

static bool store_failure(StoreState& state, const char* name, const char* phase, int error) {
    state.failed = true;
    fprintf(stderr, "[library] %s save/load failed at %s: %s\n", name, phase, strerror(error ? error : EIO));
    return false;
}

/* Unlike the permissive playlist reader below, persistent records must have a
 * complete newline and bounded size. A damaged primary must not partially
 * replace the complete dataset recovered from its backup. */
enum class RecordRead { Line, End, Error };
static RecordRead read_record(FILE* f, std::string& out, size_t& total) {
    out.clear();
    char buf[512];
    while (fgets(buf, sizeof buf, f)) {
        const size_t n = strlen(buf);
        if (!n || n > kStoreMaxBytes - total || n > kStoreMaxLine - out.size()) return RecordRead::Error;
        total += n;
        out.append(buf, n);
        if (out.back() == '\n') { out.pop_back(); return RecordRead::Line; }
    }
    return !ferror(f) && out.empty() ? RecordRead::End : RecordRead::Error;
}

static bool store_number(const std::string& text, uint32_t& value, uint32_t maximum = UINT32_MAX) {
    if (text.empty()) return false;
    uint32_t n = 0;
    for (unsigned char c : text) {
        if (c < '0' || c > '9' || n > maximum / 10 || (n == maximum / 10 && uint32_t(c - '0') > maximum % 10)) return false;
        n = n * 10 + uint32_t(c - '0');
    }
    value = n; return true;
}

static bool store_record_written(FILE* f, long& previous) {
    const long position = ftell(f);
    if (position < previous || size_t(position - previous) > kStoreMaxLine || size_t(position) > kStoreMaxBytes) {
        errno = EOVERFLOW; return false;
    }
    previous = position; return true;
}

template<class Load> static bool load_store(const char* name, StoreState& state, Load load) {
    state = {};
    const std::string path = root(name), backup = path + ".bak";
    for (int slot = 0; slot < 2; ++slot) {
        const std::string& candidate = slot ? backup : path;
        FILE* f = fopen(candidate.c_str(), "r");
        if (!f) {
            if (errno != ENOENT) store_failure(state, name, "open", errno);
            continue;
        }
        bool ok = load(f);
        if (ferror(f)) ok = false;
        if (fclose(f) != 0) ok = false;
        if (!ok) { store_failure(state, name, "read/validate", EIO); continue; }
        state.primary_valid = slot == 0;
        state.backup_valid = slot != 0;
        if (slot) fprintf(stderr, "[library] recovered %s from retained backup\n", name);
        return true;
    }
    return false;
}

template<class Write> static bool save_store(const char* name, const char* temporary, StoreState& state, Write write) {
    const std::string dir = root("/.nanoos"), path = root(name), tmp = root(temporary), backup = path + ".bak";
    if (mkdir(dir.c_str(), 0755) != 0 && errno != EEXIST) return store_failure(state, name, "mkdir", errno);
    FILE* f = fopen(tmp.c_str(), "w");
    if (!f) return store_failure(state, name, "open temporary", errno);
    int error = 0;
    errno = 0;
    if (!write(f) || ferror(f)) error = errno ? errno : EIO;
    if (fflush(f) != 0 && !error) error = errno ? errno : EIO;
    if (!error && fsync(fileno(f)) != 0) error = errno ? errno : EIO;
    if (fclose(f) != 0 && !error) error = errno ? errno : EIO;
    if (error) { remove(tmp.c_str()); return store_failure(state, name, "write/flush/sync/close", error); }

    if (state.primary_valid) {
        /* The primary remains untouched if removing an obsolete backup fails.
         * Never delete the only good file to make FAT accept the final rename. */
        struct stat st;
        if (stat(path.c_str(), &st) != 0) return store_failure(state, name, "stat primary", errno);
        if (remove(backup.c_str()) != 0 && errno != ENOENT) return store_failure(state, name, "remove obsolete backup", errno);
        state.backup_valid = false;
        if (rename(path.c_str(), backup.c_str()) != 0) return store_failure(state, name, "retain previous file", errno);
        state.primary_valid = false;
        state.backup_valid = true;
    } else {
        /* A failed/invalid primary may remain after backup recovery. Its valid
         * backup is retained while the newly written temporary is promoted. */
        if (remove(path.c_str()) != 0 && errno != ENOENT) return store_failure(state, name, "remove invalid primary", errno);
    }
    if (rename(tmp.c_str(), path.c_str()) != 0) return store_failure(state, name, "commit replacement", errno);
    state.primary_valid = true;
    state.failed = false;
    return true;
}

static bool read_line(FILE* f, std::string& out) {
    out.clear();
    char buf[512];
    while (fgets(buf, sizeof buf, f)) {
        out += buf;
        if (!out.empty() && out.back() == '\n') { out.pop_back(); return true; }
    }
    return !out.empty();
}

static void load_db(std::vector<Track>& v) {
    std::vector<Track> candidate;
    bool loaded = load_store("/.nanoos/library.db", s_db_store, [&](FILE* f) {
      candidate.clear();
      std::string l; size_t total = 0;
      if (read_record(f, l, total) != RecordRead::Line || l != kDbVer) return false;
      RecordRead result;
      while ((result = read_record(f, l, total)) == RecordRead::Line) {
        auto c = split_tab(l);
        if (c.size() != 18) return false;
        uint32_t n[11];
        const int fields[] = {1, 2, 3, 10, 11, 12, 13, 14, 15, 16, 17};
        for (size_t i = 0; i < sizeof(fields) / sizeof(fields[0]); ++i) if (!store_number(c[fields[i]], n[i])) return false;
        if (n[2] > K_AUDIOBOOK || n[3] > UINT16_MAX || n[4] > UINT16_MAX || n[5] > UINT16_MAX || n[9] > ART_PNG) return false;
        Track t;
        const std::string relative = unesc(c[0]);
        if (relative.empty() || relative[0] != '/') return false;
        t.path = std::string(hal::fs_root()) + relative;
        t.size = n[0]; t.mtime = n[1]; t.kind = uint8_t(n[2]);
        t.title = unesc(c[4]); t.artist = unesc(c[5]); t.album = unesc(c[6]); t.album_artist = unesc(c[7]);
        t.genre = unesc(c[8]); t.composer = unesc(c[9]);
        t.track = uint16_t(n[3]); t.disc = uint16_t(n[4]); t.year = uint16_t(n[5]);
        t.dur_ms = n[6]; t.art_off = n[7]; t.art_len = n[8]; t.art_type = uint8_t(n[9]); t.added = n[10];
        candidate.push_back(std::move(t));
      }
      return result == RecordRead::End;
    });
    if (loaded) v.swap(candidate);
}

static bool save_db(const std::vector<Track>& v) {
  return save_store("/.nanoos/library.db", "/.nanoos/library.tmp", s_db_store, [&](FILE* f) {
    if (fprintf(f, "%s\n", kDbVer) < 0) return false;
    long written = 0;
    if (!store_record_written(f, written)) return false;
    size_t rl = strlen(hal::fs_root());
    for (auto& t : v) {
        if (t.path.size() <= rl || t.path.compare(0, rl, hal::fs_root()) || t.path[rl] != '/' || t.kind > K_AUDIOBOOK || t.art_type > ART_PNG) return false;
        if (fprintf(f, "%s\t%u\t%u\t%u\t%s\t%s\t%s\t%s\t%s\t%s\t%u\t%u\t%u\t%u\t%u\t%u\t%u\t%u\n",
                esc(t.path.substr(rl)).c_str(), (unsigned)t.size, (unsigned)t.mtime, (unsigned)t.kind,
                esc(t.title).c_str(), esc(t.artist).c_str(), esc(t.album).c_str(), esc(t.album_artist).c_str(),
                esc(t.genre).c_str(), esc(t.composer).c_str(), t.track, t.disc, t.year, (unsigned)t.dur_ms,
                (unsigned)t.art_off, (unsigned)t.art_len, t.art_type, (unsigned)t.added) < 0) return false;
        if (!store_record_written(f, written)) return false;
    }
    return true;
  });
}

/* per-track stats: plays, rating, bookmark */
struct Stat { uint32_t plays = 0; uint8_t rating = 0; uint32_t bookmark = 0; };
static std::map<std::string, Stat> s_stats;
static bool s_stats_loaded = false;

static void load_stats() {
    s_stats_loaded = true;
    std::map<std::string, Stat> candidate;
    bool loaded = load_store("/.nanoos/stats.txt", s_stats_store, [&](FILE* f) {
      candidate.clear();
      std::string l; size_t total = 0; RecordRead result;
      while ((result = read_record(f, l, total)) == RecordRead::Line) {
        auto c = split_tab(l);
        if (c.size() != 4) return false;
        Stat s;
        uint32_t rating;
        if (!store_number(c[1], s.plays) || !store_number(c[2], rating, 5) || !store_number(c[3], s.bookmark)) return false;
        std::string relative = unesc(c[0]);
        if (relative.empty() || relative[0] != '/') return false;
        s.rating = uint8_t(rating);
        if (!candidate.emplace(std::move(relative), s).second) return false;
      }
      return result == RecordRead::End;
    });
    if (loaded) s_stats.swap(candidate);
}
static bool save_stats() {
    return save_store("/.nanoos/stats.txt", "/.nanoos/stats.tmp", s_stats_store, [&](FILE* f) {
        long written = 0;
        for (auto& kv : s_stats) {
            if (kv.first.empty() || kv.first[0] != '/' || kv.second.rating > 5) return false;
            if (fprintf(f, "%s\t%u\t%u\t%u\n", esc(kv.first).c_str(), (unsigned)kv.second.plays, kv.second.rating, (unsigned)kv.second.bookmark) < 0 || !store_record_written(f, written)) return false;
        }
        return true;
    });
}
static void apply_stats(std::vector<Track>& v) {
    size_t rl = strlen(hal::fs_root());
    for (auto& t : v) {
        auto it = s_stats.find(t.path.substr(rl));
        if (it != s_stats.end()) { t.plays = it->second.plays; t.rating = it->second.rating; t.bookmark_ms = it->second.bookmark; }
    }
}
static Stat& stat_of(int id) {
    size_t rl = strlen(hal::fs_root());
    return s_stats[s_tracks[id].path.substr(rl)];
}
void mark_played(int id) { if (!get(id)) return; s_tracks[id].plays++; stat_of(id).plays = s_tracks[id].plays; save_stats(); }
void set_rating(int id, int stars) { if (!get(id)) return; s_tracks[id].rating = (uint8_t)stars; stat_of(id).rating = (uint8_t)stars; save_stats(); }
void set_bookmark(int id, uint32_t ms) { if (!get(id)) return; s_tracks[id].bookmark_ms = ms; stat_of(id).bookmark = ms; save_stats(); }

/* ------------------------------------------------------------------ scanning */
struct FileEnt { std::string path; uint32_t size, mtime; uint8_t kind; };

static void walk(const std::string& dir, uint8_t kind, std::vector<FileEnt>& out, int depth) {
    if (depth > 8) return;
    DIR* d = opendir(dir.c_str());
    if (!d) return;
    struct dirent* e;
    while ((e = readdir(d)) != nullptr) {
        if (e->d_name[0] == '.') continue;
        std::string p = dir + "/" + e->d_name;
        struct stat st;
        if (stat(p.c_str(), &st) != 0) continue;
        if (S_ISDIR(st.st_mode)) walk(p, kind, out, depth + 1);
        else if (audio_ext(ext_of(p))) out.push_back({p, (uint32_t)st.st_size, (uint32_t)st.st_mtime, kind});
    }
    closedir(d);
}

/* What the worker needs to know about the current library: no full Track copies. */
struct Known { std::string path; uint32_t size, mtime, added; };
struct ScanResult {
    std::vector<FileEnt> files;          /* card contents in scan order */
    std::vector<int> fresh_idx;          /* per file: index into fresh, or -1 = unchanged (reuse the old Track) */
    std::vector<Track> fresh;            /* newly read tags */
};

static void scan_worker(const std::vector<Known>& known, ScanResult& res) {
    for (int k = 0; k < 3; k++) walk(root(kDirs[k]), (uint8_t)k, res.files, 0);
    std::unordered_map<std::string_view, const Known*> prev;
    prev.reserve(known.size());
    for (auto& k : known) prev.emplace(std::string_view(k.path), &k);
    res.fresh_idx.assign(res.files.size(), -1);
    uint32_t now = (uint32_t)hal::now();
    for (size_t i = 0; i < res.files.size(); i++) {
        const FileEnt& fe = res.files[i];
        auto it = prev.find(std::string_view(fe.path));
        if (it != prev.end() && it->second->size == fe.size && it->second->mtime == fe.mtime) continue;
        Track t;
        t.path = fe.path; t.size = fe.size; t.mtime = fe.mtime; t.kind = fe.kind;
        t.added = it != prev.end() ? it->second->added : now;
        read_tags(t);
        res.fresh_idx[i] = (int)res.fresh.size();
        res.fresh.push_back(std::move(t));
    }
}

static void apply_stat(Track& t) {
    size_t rl = strlen(hal::fs_root());
    auto it = s_stats.find(t.path.size() >= rl ? t.path.substr(rl) : t.path);
    if (it != s_stats.end()) { t.plays = it->second.plays; t.rating = it->second.rating; t.bookmark_ms = it->second.bookmark; }
}

/* UI thread: swap the scan result in, moving unchanged Tracks instead of copying them, and tell
 * listeners how ids moved. */
static void apply_scan(ScanResult& res) {
    size_t n = res.files.size();
    std::vector<int> old_of(n, -1);
    bool changed = n != s_tracks.size() || !res.fresh.empty();
    for (size_t i = 0; i < n; i++) {
        int o = find_path(res.files[i].path);
        if (res.fresh_idx[i] < 0) {
            /* the worker saw it unchanged; make sure it still is (the list may have been replaced) */
            const Track* ot = get(o);
            if (!ot || ot->size != res.files[i].size || ot->mtime != res.files[i].mtime) {
                Track t;
                t.path = res.files[i].path; t.size = res.files[i].size; t.mtime = res.files[i].mtime;
                t.kind = res.files[i].kind; t.added = ot ? ot->added : (uint32_t)hal::now();
                read_tags(t);
                res.fresh_idx[i] = (int)res.fresh.size();
                res.fresh.push_back(std::move(t));
                changed = true;
            }
        }
        old_of[i] = o;
        if (o != (int)i) changed = true;
    }
    if (!changed) return;
    std::vector<int> remap(s_tracks.size(), -1);
    std::vector<Track> nv;
    nv.reserve(n);
    s_index.clear();                     /* views into s_tracks die with the moves below */
    for (size_t i = 0; i < n; i++) {
        int o = old_of[i];
        if (o >= 0) remap[o] = (int)i;
        if (res.fresh_idx[i] >= 0) {
            Track& t = res.fresh[res.fresh_idx[i]];
            apply_stat(t);
            nv.push_back(std::move(t));
        } else {
            nv.push_back(std::move(s_tracks[o]));
        }
    }
    res = ScanResult();                  /* free the scan buffers before saving */
    s_tracks = std::move(nv);
    rebuild_index();
    s_version++;
    save_db(s_tracks);
    for (auto& cb : s_reindex_cbs) cb(remap);
}

void rescan() {
    if (s_scanning) return;
    s_scanning = true;
    auto known = std::make_shared<std::vector<Known>>();
    known->reserve(s_tracks.size());
    for (auto& t : s_tracks) known->push_back({t.path, t.size, t.mtime, t.added});
    auto res = std::make_shared<ScanResult>();
    auto completed = std::make_shared<bool>(false);
    hal::run_async([known, res, completed] { scan_worker(*known, *res); *completed = true; }, [known, res, completed] {
        s_scanning = false;
        if (!*completed) return; // preserve the library if the worker could not start
        known->clear();
        known->shrink_to_fit();
        apply_scan(*res);
    });
}

void init() {
    if (!s_stats_loaded) load_stats();
    std::vector<Track> v;
    load_db(v);
    apply_stats(v);
    s_index.clear();
    s_tracks.swap(v);
    rebuild_index();
    s_version++;
    rescan();
}

/* ------------------------------------------------------------------ queries */
std::string sort_key(const std::string& s) {
    std::string k = s;
    auto starts = [&](const char* p) { size_t n = strlen(p); return k.size() > n && !strncasecmp(k.c_str(), p, n); };
    if (starts("The ")) k = k.substr(4);
    else if (starts("A ")) k = k.substr(2);
    else if (starts("An ")) k = k.substr(3);
    for (auto& c : k) c = (char)tolower((unsigned char)c);
    return k;
}
char index_letter(const std::string& s) {
    std::string k = sort_key(s);
    if (k.empty()) return '#';
    char c = (char)toupper((unsigned char)k[0]);
    return (c >= 'A' && c <= 'Z') ? c : '#';
}
static bool key_less(const std::string& a, const std::string& b) {
    char la = index_letter(a), lb = index_letter(b);
    if ((la == '#') != (lb == '#')) return lb == '#';      /* '#' group last, like the iPod */
    return sort_key(a) < sort_key(b);
}

static std::vector<std::string> uniq_sorted(std::set<std::string>& s) {
    std::vector<std::string> v(s.begin(), s.end());
    std::sort(v.begin(), v.end(), key_less);
    return v;
}

static std::string art_or_unknown(const Track& t) { return t.shown_artist().empty() ? "Unknown Artist" : t.shown_artist(); }
static std::string alb_or_unknown(const Track& t) { return t.album.empty() ? "Unknown Album" : t.album; }

std::vector<std::string> artists(Kind k) {
    std::set<std::string> s;
    for (auto& t : s_tracks) if (t.kind == k) s.insert(art_or_unknown(t));
    return uniq_sorted(s);
}
std::vector<std::string> albums(const std::string& artist, Kind k) {
    std::set<std::string> s;
    for (auto& t : s_tracks)
        if (t.kind == k && (artist.empty() || art_or_unknown(t) == artist || t.artist == artist)) s.insert(alb_or_unknown(t));
    return uniq_sorted(s);
}
std::vector<std::string> genres() {
    std::set<std::string> s;
    for (auto& t : s_tracks) if (t.kind == K_MUSIC) s.insert(t.genre.empty() ? "Unknown Genre" : t.genre);
    return uniq_sorted(s);
}
std::vector<std::string> composers() {
    std::set<std::string> s;
    for (auto& t : s_tracks) if (t.kind == K_MUSIC && !t.composer.empty()) s.insert(t.composer);
    return uniq_sorted(s);
}
/* folded sort key: '#' group last (like the iPod), then the case-folded, article-stripped text */
struct FoldKey {
    bool hash; std::string k;
    explicit FoldKey(const std::string& s) : hash(index_letter(s) == '#'), k(sort_key(s)) {}
    int cmp(const FoldKey& o) const { if (hash != o.hash) return hash ? 1 : -1; return k.compare(o.k); }
};
static void sort_by_title(std::vector<int>& v) {
    std::vector<std::pair<FoldKey, int>> keyed;
    keyed.reserve(v.size());
    for (int id : v) keyed.emplace_back(FoldKey(s_tracks[id].title), id);
    std::sort(keyed.begin(), keyed.end(), [](const std::pair<FoldKey, int>& a, const std::pair<FoldKey, int>& b) {
        int c = a.first.cmp(b.first);
        if (c) return c < 0;
        int r = s_tracks[a.second].title.compare(s_tracks[b.second].title);
        if (r) return r < 0;
        return a.second < b.second;               /* deterministic tie-break */
    });
    for (size_t i = 0; i < v.size(); i++) v[i] = keyed[i].second;
}
static void sort_album_order(std::vector<int>& v) {
    struct K { FoldKey album, title; int id; };
    std::vector<K> keyed;
    keyed.reserve(v.size());
    for (int id : v) keyed.push_back({FoldKey(s_tracks[id].album.empty() ? "Unknown Album" : s_tracks[id].album), FoldKey(s_tracks[id].title), id});
    std::sort(keyed.begin(), keyed.end(), [](const K& a, const K& b) {
        const Track &x = s_tracks[a.id], &y = s_tracks[b.id];
        if (int c = a.album.cmp(b.album)) return c < 0;
        if (int c = x.album.compare(y.album)) return c < 0;   /* same folded key, different spelling */
        if (x.disc != y.disc) return x.disc < y.disc;
        if (x.track != y.track) return x.track < y.track;
        if (int c = a.title.cmp(b.title)) return c < 0;
        return a.id < b.id;
    });
    for (size_t i = 0; i < v.size(); i++) v[i] = keyed[i].id;
}
std::vector<int> songs(Kind k) {
    std::vector<int> v;
    for (size_t i = 0; i < s_tracks.size(); i++) if (s_tracks[i].kind == k) v.push_back((int)i);
    sort_by_title(v);
    return v;
}
std::vector<int> songs_by_artist(const std::string& a) {
    std::vector<int> v;
    for (size_t i = 0; i < s_tracks.size(); i++)
        if (s_tracks[i].kind == K_MUSIC && (art_or_unknown(s_tracks[i]) == a || s_tracks[i].artist == a)) v.push_back((int)i);
    sort_album_order(v);
    return v;
}
std::vector<int> songs_of_album(const std::string& album, const std::string& artist) {
    std::vector<int> v;
    for (size_t i = 0; i < s_tracks.size(); i++) {
        const Track& t = s_tracks[i];
        if (t.kind == K_MUSIC && alb_or_unknown(t) == album && (artist.empty() || art_or_unknown(t) == artist || t.artist == artist)) v.push_back((int)i);
    }
    sort_album_order(v);
    return v;
}
std::vector<int> songs_of_genre(const std::string& g) {
    std::vector<int> v;
    for (size_t i = 0; i < s_tracks.size(); i++)
        if (s_tracks[i].kind == K_MUSIC && (s_tracks[i].genre.empty() ? "Unknown Genre" : s_tracks[i].genre) == g) v.push_back((int)i);
    sort_by_title(v);
    return v;
}
std::vector<int> songs_of_composer(const std::string& c) {
    std::vector<int> v;
    for (size_t i = 0; i < s_tracks.size(); i++) if (s_tracks[i].kind == K_MUSIC && s_tracks[i].composer == c) v.push_back((int)i);
    sort_by_title(v);
    return v;
}
std::vector<int> shows(Kind k, const std::string& show) {
    std::vector<int> v;
    for (size_t i = 0; i < s_tracks.size(); i++) if (s_tracks[i].kind == k && alb_or_unknown(s_tracks[i]) == show) v.push_back((int)i);
    if (k == K_AUDIOBOOK) sort_album_order(v);
    else std::stable_sort(v.begin(), v.end(), [](int a, int b) { return s_tracks[a].mtime > s_tracks[b].mtime; });
    return v;
}
int album_art_track(const std::string& album, const std::string& artist) {
    for (size_t i = 0; i < s_tracks.size(); i++) {
        const Track& t = s_tracks[i];
        if (t.art_type && alb_or_unknown(t) == album && (artist.empty() || art_or_unknown(t) == artist)) return (int)i;
    }
    return -1;
}
int count(Kind k) { int n = 0; for (auto& t : s_tracks) if (t.kind == k) n++; return n; }

std::vector<Playlist> playlists() {
    std::vector<Playlist> out;
    /* smart playlists, like iTunes' defaults */
    Playlist recent{"Recently Added", "", {}, true};
    std::vector<int> all;
    for (size_t i = 0; i < s_tracks.size(); i++) if (s_tracks[i].kind == K_MUSIC) all.push_back((int)i);
    std::vector<int> ra = all;
    std::stable_sort(ra.begin(), ra.end(), [](int a, int b) { return s_tracks[a].added > s_tracks[b].added; });
    if (ra.size() > 25) ra.resize(25);
    recent.items = ra;
    Playlist top{"Top 25 Most Played", "", {}, true};
    for (int i : all) if (s_tracks[i].plays) top.items.push_back(i);
    std::stable_sort(top.items.begin(), top.items.end(), [](int a, int b) { return s_tracks[a].plays > s_tracks[b].plays; });
    if (top.items.size() > 25) top.items.resize(25);
    Playlist rated{"My Top Rated", "", {}, true};
    for (int i : all) if (s_tracks[i].rating >= 4) rated.items.push_back(i);
    out.push_back(rated);
    out.push_back(recent);
    out.push_back(top);
    /* .m3u files */
    std::string dir = root("/Playlists");
    DIR* d = opendir(dir.c_str());
    if (d) {
        struct dirent* e;
        std::vector<std::string> names;
        while ((e = readdir(d)) != nullptr) {
            std::string n = e->d_name;
            std::string x = ext_of(n);
            if (n[0] != '.' && (x == "m3u" || x == "m3u8")) names.push_back(n);
        }
        closedir(d);
        std::sort(names.begin(), names.end(), key_less);
        std::unordered_map<std::string_view, int> by_name;   /* file name -> id, built on first need */
        for (auto& n : names) {
            Playlist p;
            p.name = n.substr(0, n.rfind('.'));
            p.path = dir + "/" + n;
            FILE* f = fopen(p.path.c_str(), "r");
            if (f) {
                std::string l;
                while (read_line(f, l)) {
                    l = trim(l);
                    if (l.empty() || l[0] == '#') continue;
                    for (auto& c : l) if (c == '\\') c = '/';
                    std::string abs;
                    if (l[0] == '/') abs = std::string(hal::fs_root()) + l;
                    else abs = dir + "/" + l;
                    /* normalise "/Playlists/../Music/x.mp3" */
                    size_t dd;
                    while ((dd = abs.find("/../")) != std::string::npos) {
                        if (dd == 0) break;
                        size_t s = abs.rfind('/', dd - 1);
                        if (s == std::string::npos) break;
                        abs.erase(s, dd + 3 - s);
                    }
                    int id = find_path(abs);
                    if (id < 0) {   /* try matching by file name only (whole path component) */
                        size_t sl = abs.rfind('/');
                        std::string base = sl == std::string::npos ? abs : abs.substr(sl + 1);
                        if (!base.empty()) {
                            if (by_name.empty() && !s_tracks.empty()) {
                                by_name.reserve(s_tracks.size());
                                for (size_t i = 0; i < s_tracks.size(); i++) {
                                    const std::string& tp = s_tracks[i].path;
                                    size_t s = tp.rfind('/');
                                    by_name.emplace(std::string_view(tp).substr(s == std::string::npos ? 0 : s + 1), (int)i);   /* first wins */
                                }
                            }
                            auto it = by_name.find(std::string_view(base));
                            if (it != by_name.end()) id = it->second;
                        }
                    }
                    if (id >= 0) p.items.push_back(id);
                }
                fclose(f);
            }
            out.push_back(p);
        }
    }
    return out;
}

bool read_art(int id, std::vector<uint8_t>& out, ArtType& type) {
    const Track* t = get(id);
    if (!t || !t->art_type || !t->art_len || t->art_len > 4 * 1024 * 1024) return false;
    FILE* f = fopen(t->path.c_str(), "rb");
    if (!f) return false;
    out.resize(t->art_len);
    bool ok = fseek(f, t->art_off, SEEK_SET) == 0 && fread(out.data(), 1, t->art_len, f) == t->art_len;
    fclose(f);
    type = (ArtType)t->art_type;
    return ok;
}

} // namespace lib
