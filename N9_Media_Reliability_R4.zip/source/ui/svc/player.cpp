#include "player.h"
#include "playback_session.h"
#include "../hal.h"
#include "../os/system.h"
#include <algorithm>
#include <cerrno>
#include <memory>
#include <random>
#include <sys/stat.h>

namespace player {

static std::vector<int> s_order;      /* original order */
static std::vector<int> s_queue;      /* current (maybe shuffled) order */
static int s_idx = -1;
static bool s_shuffle = false;        /* the Shuffle setting */
static bool s_qshuf = false;          /* the current queue is in shuffled order */
static Repeat s_repeat = R_OFF;
static int s_version = 0;
static bool s_stream = false, s_file = false;
static std::string s_title, s_artist, s_album, s_url, s_path;
static bool s_loaded = false;
static uint32_t s_last_save = 0;
static std::mt19937 s_rng(12345);
static uint32_t s_pending = 0;     /* cued position while loaded-but-not-started */
static bool s_cued = false;

/* A/B queue snapshots are written only when their structure changes. The
 * 64-character KV checkpoint is the commit record; queue files have no periodic writes.
 * One worker job plus one coalesced pending snapshot bounds memory/job growth,
 * even when an HTTP request keeps the shared worker occupied. New queues are
 * durable only after that worker completes; shutdown does not wait for it.
 * A power cut before then restores the previous committed queue, never a mix
 * of old queue paths and a new queue's position. Progress saves retain the
 * existing 15-second cadence, plus immediate seek/pause/track-change saves. */
namespace ps = playback_session;
static uint64_t s_session_identity = 0, s_committed_identity = 0;
static int s_committed_slot = -1;
static bool s_session_busy = false, s_restore_pending = false;
static uint32_t s_session_retry_at = 0;
static std::shared_ptr<ps::Snapshot> s_session_pending, s_boot_snapshot;
static ps::Checkpoint s_local_checkpoint, s_boot_checkpoint;
static std::string s_checkpoint_text, s_legacy_path;
static uint32_t s_legacy_position = 0;
static void save_checkpoint();
static void queue_changed();
static void pump_session_write();
static void restore_at_boot();
static void cancel_boot_restore() { s_restore_pending = false; s_boot_snapshot.reset(); s_legacy_path.clear(); }

static const char* kEq[] = {"Off", "Bass Booster", "Bass Reducer", "Treble Booster", "Treble Reducer", "Vocal Booster",
                            "Loudness", "Rock", "Pop", "Jazz", "Classical", "Spoken Word", "Acoustic", "Hip Hop"};
const char* const* eq_names(int* n) { *n = sizeof kEq / sizeof kEq[0]; return kEq; }
void set_eq(int i) { hal::kv_set_int("eq", i); hal::audio_set_eq(i); }
int eq() { return hal::kv_get_int("eq", 0); }

bool active() { return s_loaded; }
bool playing() { return s_loaded && !s_cued && hal::audio_is_running() && !hal::audio_is_paused(); }
bool is_stream() { return s_stream; }
int current() { return (!s_stream && !s_file && s_idx >= 0 && s_idx < (int)s_queue.size()) ? s_queue[s_idx] : -1; }
const lib::Track* track() { return lib::get(current()); }
std::string title() { if (auto* t = track()) return t->title; return s_title; }
std::string artist() { if (auto* t = track()) return t->artist.empty() ? "Unknown Artist" : t->artist; return s_stream ? hal::audio_stream_title() : s_artist; }
std::string album() { if (auto* t = track()) return t->album.empty() ? "Unknown Album" : t->album; return s_album; }
uint32_t pos() { return !s_loaded ? 0 : (s_cued ? s_pending : hal::audio_pos_ms()); }
uint32_t dur() {
    uint32_t d = hal::audio_dur_ms();
    if (!d) if (auto* t = track()) d = t->dur_ms;
    return d;
}
int index() { return s_idx; }
int count() { return (int)s_queue.size(); }
const std::vector<int>& queue() { return s_queue; }
bool shuffle() { return s_shuffle; }
bool queue_shuffled() { return s_qshuf; }
Repeat repeat() { return s_repeat; }
int version() { return s_version; }

static void publish() { os::set_now_playing_state(s_loaded, playing()); }

/* shuffles q and moves `first` (if present) to the front */
static void shuffle_keep_first(std::vector<int>& q, int first) {
    std::shuffle(q.begin(), q.end(), s_rng);
    auto it = std::find(q.begin(), q.end(), first);
    if (it != q.end()) std::iter_swap(q.begin(), it);
}

static std::string session_path(int slot) {
    return std::string(hal::fs_root()) + "/.nanoos/playback-" + (slot ? "b" : "a") + ".bin";
}

static bool card_path(const std::string& absolute, ps::Path& relative) {
    std::string root = hal::fs_root();
    while (!root.empty() && root.back() == '/') root.pop_back();
    if (absolute.size() <= root.size() || absolute.size() - root.size() > ps::max_path_bytes ||
        absolute.compare(0, root.size(), root) || absolute[root.size()] != '/') return false;
    relative.assign(absolute.data() + root.size(), absolute.size() - root.size());
    return true;
}

static bool commit_checkpoint() {
    if (!s_local_checkpoint.identity || s_local_checkpoint.identity != s_committed_identity || s_committed_slot < 0) return false;
    s_local_checkpoint.slot = uint8_t(s_committed_slot);
    const auto encoded = ps::encode_checkpoint(s_local_checkpoint);
    if (!encoded.empty() && encoded != s_checkpoint_text) {
        hal::kv_set_str("np_session", encoded);
        // The HAL setter has no status return. Verify NVS before treating this
        // slot as active, so a rejected commit cannot expose it to replacement.
        if (hal::kv_get_str("np_session", "") != encoded) return false;
        s_checkpoint_text = encoded;
    }
    return !encoded.empty();
}

static void save_checkpoint() {
    if (s_stream || s_file || !s_session_identity || s_idx < 0 || !track()) return;
    s_local_checkpoint.identity = s_session_identity;
    s_local_checkpoint.index = uint32_t(s_idx);
    s_local_checkpoint.position_ms = ps::clamp_position(pos(), track()->dur_ms);
    s_local_checkpoint.shuffle = s_shuffle;
    s_local_checkpoint.paused = !playing();
    s_local_checkpoint.repeat = uint8_t(s_repeat);
    commit_checkpoint();
}

static void pump_session_write() {
    if (s_session_busy || !s_session_pending ||
        (s_session_retry_at && int32_t(hal::millis() - s_session_retry_at) < 0)) return;
    if (s_session_pending->identity == s_committed_identity) {
        s_session_pending.reset(); commit_checkpoint(); return;
    }
    auto snapshot = std::move(s_session_pending);
    const int slot = s_committed_slot == 0 ? 1 : 0;
    const std::string path = session_path(slot);
    const std::string directory = std::string(hal::fs_root()) + "/.nanoos";
    auto succeeded = std::make_shared<bool>(false);
    s_session_busy = true;
    hal::run_async([snapshot, path, directory, succeeded] {
        if (mkdir(directory.c_str(), 0755) != 0 && errno != EEXIST) return;
        *succeeded = ps::write_inactive(path, *snapshot);
    }, [snapshot, succeeded, slot] {
        s_session_busy = false;
        if (*succeeded && snapshot->identity == s_session_identity) {
            const uint64_t previous_identity = s_committed_identity;
            const int previous_slot = s_committed_slot;
            s_committed_identity = snapshot->identity;
            s_committed_slot = slot;
            s_session_retry_at = 0;
            save_checkpoint();
            if (!commit_checkpoint()) {
                s_committed_identity = previous_identity;
                s_committed_slot = previous_slot;
                if (!s_session_pending) s_session_pending = snapshot;
                s_session_retry_at = hal::millis() + 10000u;
            }
        } else if (!*succeeded && snapshot->identity == s_session_identity && !s_session_pending) {
            s_session_pending = snapshot;
            s_session_retry_at = hal::millis() + 10000u;
        }
        pump_session_write();
    });
}

static void queue_changed() {
    if (s_order.empty() || s_order.size() != s_queue.size() || s_queue.size() > ps::max_entries) {
        s_session_identity = 0; s_session_pending.reset();
        s_checkpoint_text = "invalid"; hal::kv_set_str("np_session", s_checkpoint_text);
        return;
    }
    size_t payload = 32;
    for (const auto* ids : {&s_order, &s_queue}) for (int id : *ids) {
        const auto* t = lib::get(id);
        if (!t || t->path.size() + 2 > ps::max_file_bytes - payload) { payload = ps::max_file_bytes; break; }
        payload += t->path.size() + 2;
    }
    if (!ps::memory_available(payload, s_queue.size())) {
        // Keep the previous durable session when persistence has no memory
        // budget. Never fall back to allocating these copies in internal RAM.
        s_session_identity = 0; s_session_pending.reset(); return;
    }
    auto snapshot = std::make_shared<ps::Snapshot>();
    snapshot->shuffled = s_qshuf;
    bool valid = !s_order.empty() && s_order.size() <= ps::max_entries && s_queue.size() <= ps::max_entries;
    size_t bytes = 32;
    if (valid) for (const auto* ids : {&s_order, &s_queue}) {
        auto& paths = ids == &s_order ? snapshot->order : snapshot->queue;
        paths.reserve(ids->size());
        for (int id : *ids) {
            const auto* t = lib::get(id); ps::Path path;
            if (!t || !card_path(t->path, path) || path.size() + 2 > ps::max_file_bytes - bytes) { valid = false; break; }
            bytes += path.size() + 2;
            paths.push_back(std::move(path));
        }
        if (!valid) break;
    }
    if (!valid || !ps::seal(*snapshot)) {
        s_session_identity = 0; s_session_pending.reset();
        // Never revive a different old queue for an unpersistable new session.
        s_checkpoint_text = "invalid"; hal::kv_set_str("np_session", s_checkpoint_text);
        return;
    }
    s_session_identity = snapshot->identity;
    save_checkpoint();
    if (snapshot->identity == s_committed_identity) { s_session_pending.reset(); return; }
    s_session_pending = std::move(snapshot);
    s_session_retry_at = 0;
    pump_session_write();
}

static void save_state() {
    if (s_stream || s_file || !s_loaded) return;
    auto* t = track();
    if (!t) return;
    uint32_t p = ps::clamp_position(pos(), t->dur_ms);
    hal::kv_set_str("np_path", t->path);
    hal::kv_set_int("np_pos", (int32_t)p);
    if (t->kind != lib::K_MUSIC) lib::set_bookmark(current(), p);
    save_checkpoint();
}

static void start_current(uint32_t at_ms, bool paused = false, bool use_bookmark = true) {
    auto* t = track();
    if (!t) return;
    uint32_t start = at_ms;
    if (!start && use_bookmark && t->kind != lib::K_MUSIC && t->bookmark_ms < t->dur_ms && t->dur_ms - t->bookmark_ms > 5000) start = t->bookmark_ms;
    start = ps::clamp_position(start, t->dur_ms);
    if (paused) {                     /* cue without starting the decoder */
        hal::audio_stop();
        s_cued = true;
        s_pending = start;
    } else {
        s_cued = false;
        hal::audio_play_file(t->path.c_str(), start);
    }
    s_loaded = true;
    s_version++;
    /* the saved position always belongs to the saved path */
    hal::kv_set_str("np_path", t->path);
    hal::kv_set_int("np_pos", (int32_t)start);
    s_last_save = hal::millis();
    save_checkpoint();
    publish();
}

void play(const std::vector<int>& ids, int start, bool shuffle_on) {
    if (ids.empty()) return;
    cancel_boot_restore();
    save_state();                     /* keep the bookmark of what was playing */
    s_session_identity = 0;           /* the old checkpoint belongs to a different queue */
    s_stream = s_file = false;
    s_order = ids;
    s_queue = ids;
    s_qshuf = shuffle_on;
    if (start >= (int)ids.size()) start = (int)ids.size() - 1;
    s_idx = start < 0 ? 0 : start;
    if (s_qshuf) {
        int first = s_queue[start < 0 ? (int)(s_rng() % s_queue.size()) : start];
        shuffle_keep_first(s_queue, first);
        s_idx = 0;
    }
    start_current(0);
    queue_changed();
}

void jump(int qi) {
    if (s_stream || s_file || qi < 0 || qi >= (int)s_queue.size()) return;
    save_state();
    s_idx = qi;
    start_current(0);
}

void play_stream(const std::string& name, const std::string& url) {
    cancel_boot_restore();
    save_state();
    s_stream = true; s_file = false; s_cued = false;
    s_queue.clear(); s_order.clear(); s_idx = -1; s_qshuf = false;
    s_title = name; s_artist = ""; s_album = "Radio"; s_url = url; s_path.clear();
    hal::audio_play_url(url.c_str());
    s_loaded = true;
    s_version++;
    publish();
}

void play_file(const std::string& title_, const std::string& path) {
    cancel_boot_restore();
    save_state();
    s_stream = false; s_file = true; s_cued = false;
    s_queue.clear(); s_order.clear(); s_idx = -1; s_qshuf = false;
    s_title = title_; s_artist = "Voice Memo"; s_album = ""; s_path = path; s_url.clear();
    hal::audio_play_file(path.c_str(), 0);
    s_loaded = true;
    s_version++;
    publish();
}

void toggle() { if (playing()) pause(); else resume(); }
void pause() { if (!s_loaded || s_cued) return; hal::audio_pause(true); save_state(); publish(); }
void resume() {
    if (!s_loaded) return;
    if (s_cued) {
        if (s_file) { s_cued = false; hal::audio_play_file(s_path.c_str(), s_pending); }
        else if (s_stream) { s_cued = false; hal::audio_play_url(s_url.c_str()); }
        else start_current(s_pending, false, false);
    } else if (!hal::audio_is_running()) {
        if (s_stream) hal::audio_play_url(s_url.c_str());
        else if (s_file) hal::audio_play_file(s_path.c_str(), 0);
        else start_current(0);
    } else hal::audio_pause(false);
    save_checkpoint();
    publish();
}
void stop() {
    save_state();                     /* before the decoder forgets its position */
    s_local_checkpoint.paused = true; commit_checkpoint();
    hal::audio_stop();
    s_loaded = false; s_cued = false;
    s_version++;
    publish();
}
void seek(uint32_t ms) {
    if (!s_loaded || s_stream) return;
    ms = ps::clamp_position(ms, dur());
    if (s_cued) s_pending = ms; else hal::audio_seek(ms);
    save_state();
}

void next() {
    if (s_stream || s_file || s_queue.empty()) return;
    if (current() >= 0) lib::set_bookmark(current(), 0);
    if (s_idx + 1 < (int)s_queue.size()) s_idx++;
    else if (s_repeat == R_ALL) s_idx = 0;
    else { s_idx = 0; start_current(0, true); publish(); return; }
    start_current(0);
}

void prev() {
    if (s_stream || s_file || s_queue.empty()) return;
    if (pos() > 3000) { seek(0); return; }
    save_state();
    if (s_idx > 0) s_idx--;
    else if (s_repeat == R_ALL) s_idx = (int)s_queue.size() - 1;
    start_current(0);
}

/* reorders the current queue to shuffled / original order keeping the current track playing */
static void reorder(bool shuffled) {
    if (shuffled == s_qshuf) return;
    s_qshuf = shuffled;
    if (s_queue.empty()) return;
    int cur = s_idx >= 0 && s_idx < (int)s_queue.size() ? s_queue[s_idx] : s_queue[0];
    if (shuffled) {
        shuffle_keep_first(s_queue, cur);
        s_idx = 0;
    } else {
        s_queue = s_order;
        auto it = std::find(s_queue.begin(), s_queue.end(), cur);
        s_idx = it == s_queue.end() ? 0 : (int)(it - s_queue.begin());
    }
    s_version++;
    queue_changed();
}

void set_shuffle(bool on) {
    if (on != s_shuffle) {
        s_shuffle = on;
        hal::kv_set_int("np_shuf", on);
    }
    reorder(on);
    save_checkpoint();
}

void set_repeat(Repeat r) {
    if (r < R_OFF || r > R_ONE) return;
    s_repeat = r; hal::kv_set_int("np_rep", r); save_checkpoint();
}

/* ---------------------------------------------------------------- save / restore for temporary sounds */
struct Saved {
    std::vector<int> order, queue;
    int idx = -1;
    bool qshuf = false, shuffle = false;
    Repeat repeat = R_OFF;
    bool loaded = false, was_playing = false, stream = false, file = false;
    uint32_t pos = 0;
    uint32_t token = 0;
    std::string title, artist, album, url, path;
};
static std::vector<Saved> s_saved;

static uint32_t s_token = 0;

uint32_t push_state() {
    save_state();
    Saved s;
    s.token = ++s_token;
    s.order = s_order; s.queue = s_queue; s.idx = s_idx;
    s.qshuf = s_qshuf; s.shuffle = s_shuffle; s.repeat = s_repeat;
    s.loaded = s_loaded; s.was_playing = playing(); s.stream = s_stream; s.file = s_file;
    s.pos = pos();
    s.title = s_title; s.artist = s_artist; s.album = s_album; s.url = s_url; s.path = s_path;
    if (s.was_playing) hal::audio_pause(true);
    if (s_saved.size() >= 4) s_saved.erase(s_saved.begin());
    uint32_t tok = s.token;
    s_saved.push_back(std::move(s));
    publish();
    return tok;
}

void pop_state(uint32_t token) {
    if (s_saved.empty()) return;
    if (token) {
        /* restore only the state this caller saved; an inner save that is still open (e.g. an alarm
           ringing over a video) keeps its own entry and restores when it finishes */
        if (s_saved.back().token != token) {
            for (size_t i = 0; i < s_saved.size(); i++)
                if (s_saved[i].token == token) { s_saved.erase(s_saved.begin() + i); break; }
            return;
        }
    }
    Saved s = std::move(s_saved.back());
    s_saved.pop_back();
    const bool local_session = !s.stream && !s.file && !s.queue.empty();
    if (local_session) s_session_identity = 0;
    hal::audio_take_eof();                 /* the temporary sound's end must not skip the restored track */
    s_order = std::move(s.order); s_queue = std::move(s.queue); s_idx = s.idx;
    s_qshuf = s.qshuf;
    if (s_shuffle != s.shuffle) { s_shuffle = s.shuffle; hal::kv_set_int("np_shuf", s_shuffle); }
    if (s_repeat != s.repeat) set_repeat(s.repeat);
    s_stream = s.stream; s_file = s.file;
    s_title = s.title; s_artist = s.artist; s_album = s.album; s_url = s.url; s_path = s.path;
    s_cued = false;
    s_loaded = false;
    if (s.loaded) {
        if (s_stream) {
            if (s.was_playing) hal::audio_play_url(s_url.c_str()); else hal::audio_stop();
            s_loaded = true;
        } else if (s_file) {
            if (s.was_playing) hal::audio_play_file(s_path.c_str(), s.pos);
            else { hal::audio_stop(); s_cued = true; s_pending = s.pos; }
            s_loaded = true;
        } else if (track()) {
            start_current(s.pos, !s.was_playing, false);
        }
    }
    if (!s_loaded) hal::audio_stop();
    if (local_session) queue_changed();
    s_version++;
    publish();
}

/* ---------------------------------------------------------------- library renumbering */
static void remap_list(std::vector<int>& v, const std::vector<int>& m) {
    size_t w = 0;
    for (int id : v) {
        int n = id >= 0 && id < (int)m.size() ? m[id] : -1;
        if (n >= 0) v[w++] = n;
    }
    v.resize(w);
}
/* returns false when the current track vanished */
static bool remap_queue(std::vector<int>& order, std::vector<int>& queue, int& idx, const std::vector<int>& m) {
    int cur = idx >= 0 && idx < (int)queue.size() ? queue[idx] : -1;
    int ncur = cur >= 0 && cur < (int)m.size() ? m[cur] : -1;
    int removed_before = 0;
    for (int i = 0; i < idx && i < (int)queue.size(); i++) {
        int id = queue[i];
        if (id < 0 || id >= (int)m.size() || m[id] < 0) removed_before++;
    }
    remap_list(order, m);
    remap_list(queue, m);
    if (ncur >= 0) {
        /* the surviving position is known: a queue may list the same track twice, and std::find
           would snap back to the earlier copy */
        idx = std::min(std::max(idx - removed_before, 0), (int)queue.size() - 1);
        if (idx < 0 || idx >= (int)queue.size() || queue[idx] != ncur) {
            auto it = std::find(queue.begin(), queue.end(), ncur);
            idx = it == queue.end() ? 0 : (int)(it - queue.begin());
        }
        return true;
    }
    /* current track gone: point at the track that followed it */
    idx = queue.empty() ? -1 : std::min(std::max(idx - removed_before, 0), (int)queue.size() - 1);
    return cur < 0;
}

static void on_reindex(const std::vector<int>& m) {
    if (s_restore_pending) { restore_at_boot(); return; }
    bool had_track = !s_stream && !s_file && current() >= 0;
    bool ok = remap_queue(s_order, s_queue, s_idx, m);
    if (had_track && !ok && s_loaded) {    /* the playing song was deleted from the card */
        hal::audio_stop();
        s_loaded = false; s_cued = false;
    }
    for (auto& s : s_saved)
        if (!s.stream && !s.file && !remap_queue(s.order, s.queue, s.idx, m)) s.loaded = false;
    if (s_cued && track()) s_pending = ps::clamp_position(s_pending, track()->dur_ms);
    if (!s_stream && !s_file && (had_track || !s_queue.empty())) queue_changed();
    s_version++;
    publish();
}

static void tick() {
    if (s_restore_pending) restore_at_boot();
    pump_session_write();
    if (!s_loaded) return;
    if (hal::audio_take_eof()) {
        if (int id = current(); id >= 0) lib::mark_played(id);
        if (s_file || s_stream) { s_loaded = false; s_cued = false; s_version++; publish(); return; }
        if (s_repeat == R_ONE) {
            if (int id = current(); id >= 0) lib::set_bookmark(id, 0);   /* restart podcasts from the top */
            start_current(0, false, false);
        } else next();
    }
    publish();
    if (hal::millis() - s_last_save > 15000 && playing()) { s_last_save = hal::millis(); save_state(); }
}

static void restore_at_boot() {
    if (!s_restore_pending) return;
    if (s_boot_snapshot) {
        std::string root = hal::fs_root();
        while (!root.empty() && root.back() == '/') root.pop_back();
        const auto lookup = [&root](std::string_view relative) { return lib::find_path(root + std::string(relative)); };
        // An empty/incomplete cached library must not permanently discard paths
        // that the initial scan is about to discover. A fresh Play cancels this.
        if (lib::scanning()) for (const auto& p : s_boot_snapshot->queue) if (lookup(p) < 0) return;
        ps::Restored restored;
        if (!ps::restore(*s_boot_snapshot, s_boot_checkpoint, lookup,
                         [](int id) { const auto* t = lib::get(id); return t ? t->dur_ms : 0; }, restored)) {
            cancel_boot_restore(); return;
        }
        s_committed_identity = s_boot_snapshot->identity;
        s_committed_slot = s_boot_checkpoint.slot;
        s_order = std::move(restored.order); s_queue = std::move(restored.queue); s_idx = restored.index;
        s_qshuf = s_boot_snapshot->shuffled;
        s_shuffle = s_boot_checkpoint.shuffle;
        s_repeat = Repeat(s_boot_checkpoint.repeat);
        hal::kv_set_int("np_shuf", s_shuffle); hal::kv_set_int("np_rep", s_repeat);
        s_stream = s_file = false;
        cancel_boot_restore();
        // Preserve the established paused-on-boot behavior. First Resume uses
        // this exact checkpoint, including an intentional zero bookmark.
        start_current(restored.position_ms, true, false);
        queue_changed();
        return;
    }
    int id = s_legacy_path.empty() ? -1 : lib::find_path(s_legacy_path);
    if (id < 0 && lib::scanning()) return;
    const uint32_t at = s_legacy_position;
    cancel_boot_restore();
    if (id >= 0) {
        const lib::Track* t = lib::get(id);
        std::vector<int> q;
        if (t->kind == lib::K_MUSIC)
            q = lib::songs_of_album(t->album.empty() ? "Unknown Album" : t->album,
                                    t->shown_artist().empty() ? "Unknown Artist" : t->shown_artist());
        else q = lib::shows((lib::Kind)t->kind, t->album.empty() ? "Unknown Album" : t->album);
        auto it = std::find(q.begin(), q.end(), id);
        s_idx = it == q.end() ? 0 : (int)(it - q.begin());
        if (it == q.end()) q = {id};
        s_order = s_queue = q;
        s_qshuf = false;
        if (s_shuffle && t->kind == lib::K_MUSIC) { shuffle_keep_first(s_queue, id); s_idx = 0; s_qshuf = true; }
        s_stream = s_file = false;
        start_current(at, true, false);
        queue_changed(); // migrate once; future boots never reconstruct this queue
    }
}

void init() {
    s_repeat = (Repeat)hal::kv_get_int("np_rep", 0);
    if (s_repeat < R_OFF || s_repeat > R_ONE) s_repeat = R_OFF;
    s_shuffle = hal::kv_get_int("np_shuf", 0) != 0;
    hal::audio_set_eq(eq());
    os::on_tick(tick);
    lib::on_reindex(on_reindex);
    // Read the bounded selected snapshot before network jobs can delay the
    // worker. Never use legacy state to bypass a corrupt new-format record.
    s_checkpoint_text = hal::kv_get_str("np_session", "");
    if (!s_checkpoint_text.empty()) {
        if (!ps::decode_checkpoint(s_checkpoint_text, s_boot_checkpoint)) return;
        auto snapshot = std::make_shared<ps::Snapshot>();
        if (ps::read(session_path(s_boot_checkpoint.slot), *snapshot) != ps::Read::Ok ||
            snapshot->identity != s_boot_checkpoint.identity || s_boot_checkpoint.index >= snapshot->queue.size()) return;
        // Protect the selected slot even while a cache miss defers mapping.
        // Fresh user playback must write the other slot during that window.
        s_committed_identity = snapshot->identity;
        s_committed_slot = s_boot_checkpoint.slot;
        s_boot_snapshot = std::move(snapshot);
    } else {
        s_legacy_path = hal::kv_get_str("np_path", "");
        const int32_t at = hal::kv_get_int("np_pos", 0);
        s_legacy_position = at > 0 ? uint32_t(at) : 0;
        if (s_legacy_path.empty()) return;
    }
    s_restore_pending = true;
    restore_at_boot();
}

} // namespace player
