/* Shared list builders for Music, Podcasts and Audiobooks, plus Now Playing. */
#pragma once
#include "apps.h"
#include "../svc/library.h"
#include "../svc/player.h"
#include "../svc/artwork.h"
#include <vector>
#include <string>
#include <memory>

namespace media {
enum class Sub { None, Artist, Album, ArtistAlbum, Duration };
using SongQuery = std::function<std::vector<int>()>;
using NameQuery = std::function<std::vector<std::string>()>;
void push_songs(os::Nav* nav, const char* title, SongQuery query, bool shuffle_row, Sub sub, bool index = true);
void push_album(os::Nav* nav, const std::string& album, const std::string& artist);
void push_albums(os::Nav* nav, const char* title, const std::string& artist);
void push_now_playing(os::Nav* nav, bool animated = true);
void push_queue(os::Nav* nav);
/* A VList of strings with an index strip; click(i) */
void push_name_list(os::Nav* nav, const char* title, NameQuery query, std::function<void(const std::string&, int)> click,
                    bool index = true);
void set_art(lv_obj_t* img, int track, int size);       /* thumb with placeholder, async refresh */
/* Numeric track ids belong to one library revision. Never bind or activate an old
 * row after a rescan, even if its old id is still in bounds. Timers belong to the
 * page body, so popping/closing a page removes both the timer and its captures. */
struct LibraryRevision {
    int revision = lib::version();
    bool current() const { return revision == lib::version(); }
    void accept() { revision = lib::version(); }
};
inline std::function<void()> watch_library(lv_obj_t* body, std::function<void()> refresh) {
    auto seen = std::make_shared<int>(lib::version());
    auto reload = [seen, refresh] {
        *seen = lib::version();
        refresh();
    };
    os::every(200, [seen, reload, body] {
        if (!lv_obj_is_visible(body)) return;
        if (*seen == lib::version()) return;
        reload();
    }, body);
    return reload;
}
inline void reset_list(os::VList* list, const os::VListSpec& spec) {
    int y = lv_obj_get_scroll_y(list->obj());
    list->reset(spec);
    lv_obj_update_layout(list->obj());
    int bottom = lv_obj_get_scroll_bottom(list->obj());
    if (y > bottom) y = bottom;
    if (y < 0) y = 0;
    lv_obj_scroll_to_y(list->obj(), y, LV_ANIM_OFF);
}
inline void list_empty_state(lv_obj_t* body, os::VList* list, lv_obj_t*& empty,
                             bool is_empty, const char* title, const char* hint = nullptr) {
    lv_obj_set_name(list->obj(), "media-list");
    if (is_empty) {
        lv_obj_add_flag(list->obj(), LV_OBJ_FLAG_HIDDEN);
        if (!empty) empty = os::list_empty(body, title, hint);
        lv_obj_remove_flag(empty, LV_OBJ_FLAG_HIDDEN);
    } else {
        lv_obj_remove_flag(list->obj(), LV_OBJ_FLAG_HIDDEN);
        if (empty) lv_obj_add_flag(empty, LV_OBJ_FLAG_HIDDEN);
    }
}
inline void clear_row(os::VRow& row, int art_size = 0) {
    if (row.title) th::label_set_text(row.title, "");
    if (row.sub) th::label_set_text(row.sub, "");
    if (row.detail) th::label_set_text(row.detail, "");
    if (row.dot) lv_obj_add_flag(row.dot, LV_OBJ_FLAG_HIDDEN);
    if (row.img) set_art(row.img, -1, art_size);
}
/* page user_data tags so the status-bar shortcut can recognise Now Playing / Track List */
static void* const NP_TAG = (void*)0x4E50;
static void* const QUEUE_TAG = (void*)0x5451;
}
