/* Music — the nano 7 Music app: Playlists, Artists, Albums, Songs, Genres, Composers, Now Playing. */
#include "media_ui.h"
#include <algorithm>

using namespace th;

namespace media {

static std::vector<std::pair<std::string, int>> letter_index(const std::vector<std::string>& names, int offset) {
    std::vector<std::pair<std::string, int>> idx;
    char last = 0;
    for (size_t i = 0; i < names.size(); i++) {
        char l = lib::index_letter(names[i]);
        if (l != last) { idx.push_back({std::string(1, l), (int)i + offset}); last = l; }
    }
    return idx;
}

/* placeholder thumbnail for tracks without artwork */
static const lv_image_dsc_t* placeholder(int size) {
    static lv_image_dsc_t* ph40 = nullptr;
    if (size <= 60) {
        if (!ph40) {
            ph40 = (lv_image_dsc_t*)calloc(1, sizeof(lv_image_dsc_t));
            int s = 44;
            uint16_t* px = (uint16_t*)malloc(s * s * 2);
            /* downsample the 240px placeholder art */
            const uint16_t* src = (const uint16_t*)img_ph_art.data;
            for (int y = 0; y < s; y++) for (int x = 0; x < s; x++) px[y * s + x] = src[(y * 240 / s) * 240 + x * 240 / s];
            ph40->header.magic = LV_IMAGE_HEADER_MAGIC; ph40->header.cf = LV_COLOR_FORMAT_RGB565;
            ph40->header.w = s; ph40->header.h = s; ph40->header.stride = s * 2;
            ph40->data = (const uint8_t*)px; ph40->data_size = s * s * 2;
        }
        return ph40;
    }
    return &img_ph_art;
}

void set_art(lv_obj_t* img, int track, int size) {
    /* art::bind gives the widget its own copy of the artwork (the LRU cache may free its
     * images while they are still on screen), loads it asynchronously and handles recycled rows. */
    art::bind(img, track, size, placeholder(size));
}

void push_name_list(os::Nav* nav, const char* title, NameQuery query, std::function<void(const std::string&, int)> click, bool index) {
    lv_obj_t* body = nav->push(title);
    struct Data : LibraryRevision { std::vector<std::string> names; os::VList* list = nullptr; lv_obj_t* empty = nullptr; };
    auto data = std::make_shared<Data>();
    auto refresh = [body, data, query, click, index] {
        data->names = query();
        data->accept();
        os::VListSpec sp;
        sp.count = (int)data->names.size();
        sp.bind = [data](int i, os::VRow& r) {
            if (!data->current() || i < 0 || i >= (int)data->names.size()) { clear_row(r); return; }
            th::label_set_text(r.title, data->names[i].c_str());
        };
        sp.click = [data, click](int i) {
            if (!data->current() || i < 0 || i >= (int)data->names.size()) return;
            /* The callback may push another page; give it an independent name. */
            std::string name = data->names[i];
            click(name, i);
        };
        if (index) sp.index = letter_index(data->names, 0);
        if (data->list) reset_list(data->list, sp);
        else data->list = new os::VList(body, sp);
        list_empty_state(body, data->list, data->empty, sp.count == 0, "No Items");
    };
    refresh();
    nav->top().on_show = watch_library(body, refresh);
}

/* Queries run again after each rescan: checking only get(id) cannot detect an
 * in-bounds id that now refers to a different file. */
static std::vector<int> valid_ids(std::vector<int> ids) {
    ids.erase(std::remove_if(ids.begin(), ids.end(), [](int id) { return !lib::get(id); }), ids.end());
    return ids;
}

void push_songs(os::Nav* nav, const char* title, SongQuery query, bool shuffle_row, Sub sub, bool index) {
    lv_obj_t* body = nav->push(title);
    struct Data : LibraryRevision { std::vector<int> ids; os::VList* list = nullptr; lv_obj_t* empty = nullptr; };
    auto data = std::make_shared<Data>();
    auto refresh = [body, data, query, shuffle_row, sub, index, nav] {
        data->ids = valid_ids(query());
        data->accept();
        int off = shuffle_row && !data->ids.empty() ? 1 : 0;
        os::VListSpec sp;
        sp.count = (int)data->ids.size() + off;
        sp.row_h = sub == Sub::None ? 40 : 44;
        sp.subtitle = sub != Sub::None && sub != Sub::Duration;
        sp.chevron = false;
        sp.dots = true;
        sp.bind = [data, off, sub](int i, os::VRow& r) {
            clear_row(r);
            if (!data->current() || i < 0 || i >= (int)data->ids.size() + off) return;
            if (i < off) { th::label_set_text(r.title, "Shuffle"); return; }
            const lib::Track* t = lib::get(data->ids[i - off]);
            if (!t) return;
            th::label_set_text(r.title, t->title.c_str());
            if (r.sub) {
                std::string s = sub == Sub::Artist ? (t->artist.empty() ? "Unknown Artist" : t->artist)
                              : sub == Sub::Album ? (t->album.empty() ? "Unknown Album" : t->album)
                              : (t->artist.empty() ? "Unknown Artist" : t->artist) + " \xE2\x80\x94 " + (t->album.empty() ? "Unknown Album" : t->album);
                th::label_set_text(r.sub, s.c_str());
            }
            th::label_set_text(r.detail, sub == Sub::Duration && t->dur_ms ? th::fmt_time_ms(t->dur_ms).c_str() : "");
            if (player::current() == data->ids[i - off]) lv_obj_remove_flag(r.dot, LV_OBJ_FLAG_HIDDEN);
        };
        sp.click = [data, off, nav](int i) {
            if (!data->current() || data->ids.empty() || i < 0 || i >= (int)data->ids.size() + off) return;
            if (i < off) player::play(data->ids, -1, true);
            else player::play(data->ids, i - off, player::shuffle());
            push_now_playing(nav);
        };
        if (index && data->ids.size() > 30) {
            std::vector<std::string> names;
            for (int id : data->ids) { const lib::Track* t = lib::get(id); names.push_back(t ? t->title : std::string()); }
            sp.index = letter_index(names, off);
        }
        if (data->list) reset_list(data->list, sp);
        else data->list = new os::VList(body, sp);
        list_empty_state(body, data->list, data->empty, sp.count == 0, "No Songs");
    };
    refresh();
    nav->top().on_show = watch_library(body, refresh);
}

void push_album(os::Nav* nav, const std::string& album, const std::string& artist) {
    lv_obj_t* body = nav->push(album.c_str());
    struct Data : LibraryRevision { std::vector<int> ids; lv_obj_t* column = nullptr; };
    auto data = std::make_shared<Data>();
    auto refresh = [body, data, album, artist, nav] {
        int scroll = data->column ? lv_obj_get_scroll_y(data->column) : 0;
        lv_obj_clean(body);
        data->ids = valid_ids(lib::songs_of_album(album, artist));
        data->accept();
        const std::vector<int>& ids = data->ids;
        lv_obj_t* col = os::scroll_column(body);
        data->column = col;
        /* header: artwork + info on a light gradient, like the iPod album view */
        lv_obj_t* hdr = grad(col, 0, 0, SCR_W, 86, 0xF4F5F7, 0xDCDFE3);
        lv_obj_set_style_border_width(hdr, 1, 0);
        lv_obj_set_style_border_side(hdr, LV_BORDER_SIDE_BOTTOM, 0);
        lv_obj_set_style_border_color(hdr, c(0xB9BDC3), 0);
        lv_obj_t* im = lv_image_create(hdr);
        lv_obj_set_pos(im, 8, 8);
        lv_obj_set_size(im, 70, 70);
        lv_image_set_inner_align(im, LV_IMAGE_ALIGN_STRETCH);
        lv_obj_set_style_shadow_width(im, 6, 0);
        lv_obj_set_style_shadow_opa(im, LV_OPA_40, 0);
        int art_id = lib::album_art_track(album, artist);
        set_art(im, art_id >= 0 ? art_id : (ids.empty() ? -1 : ids[0]), 70);
        const lib::Track* t0 = ids.empty() ? nullptr : lib::get(ids[0]);
        lv_obj_t* a = label(hdr, t0 ? (t0->shown_artist().empty() ? "Unknown Artist" : t0->shown_artist().c_str()) : "", B13, 0x3C3F45);
        th::dot1(a);
        lv_obj_set_width(a, 146);
        lv_obj_set_pos(a, 88, 12);
        lv_obj_t* al = label(hdr, album.c_str(), B15, 0x000000);
        th::dot1(al);
        lv_obj_set_width(al, 146);
        lv_obj_set_pos(al, 88, 29);
        uint32_t total = 0;
        for (int id : ids) if (const lib::Track* t = lib::get(id)) total += t->dur_ms;
        char info[64];
        if (t0 && t0->year) snprintf(info, sizeof info, "Released %u", t0->year); else info[0] = 0;
        lv_obj_t* y = label(hdr, info, R11, 0x6B6F75);
        lv_obj_set_pos(y, 88, 50);
        snprintf(info, sizeof info, "%d Song%s, %u Min.", (int)ids.size(), ids.size() == 1 ? "" : "s", (unsigned)((total + 30000) / 60000));
        lv_obj_t* n = label(hdr, info, R11, 0x6B6F75);
        lv_obj_set_pos(n, 88, 64);
        for (size_t i = 0; i < ids.size(); i++) {
            const lib::Track* t = lib::get(ids[i]);
            if (!t) continue;
            lv_obj_t* r = box(col, 0, 0, SCR_W, 36);
            lv_obj_set_style_bg_opa(r, LV_OPA_COVER, 0);
            lv_obj_set_style_bg_color(r, c(i % 2 ? 0xF3F4F6 : 0xFFFFFF), 0);
            lv_obj_set_style_border_width(r, 1, 0);
            lv_obj_set_style_border_side(r, LV_BORDER_SIDE_BOTTOM, 0);
            lv_obj_set_style_border_color(r, c(0xE2E3E6), 0);
            lv_obj_add_flag(r, LV_OBJ_FLAG_CLICKABLE);
            lv_obj_set_style_bg_color(r, c(col::sel_top), LV_STATE_PRESSED);
            lv_obj_set_style_bg_grad_color(r, c(col::sel_bot), LV_STATE_PRESSED);
            lv_obj_set_style_bg_grad_dir(r, LV_GRAD_DIR_VER, LV_STATE_PRESSED);
            os::row_highlight_setup(r);
            char num[8];
            snprintf(num, sizeof num, "%u", t->track ? t->track : (unsigned)(i + 1));
            lv_obj_t* nl = label(r, num, B13, 0x8A8E95);
            lv_obj_set_style_text_color(nl, c(0xFFFFFF), LV_STATE_PRESSED);
            lv_obj_set_width(nl, 22);
            lv_obj_set_style_text_align(nl, LV_TEXT_ALIGN_RIGHT, 0);
            lv_obj_align(nl, LV_ALIGN_LEFT_MID, 2, 0);
            lv_obj_t* tl = label(r, t->title.c_str(), B15, 0x000000);
            lv_obj_set_style_text_color(tl, c(0xFFFFFF), LV_STATE_PRESSED);
            th::dot1(tl);
            lv_obj_set_width(tl, 160);
            lv_obj_align(tl, LV_ALIGN_LEFT_MID, 32, 0);
            lv_obj_t* dl = label(r, t->dur_ms ? th::fmt_time_ms(t->dur_ms).c_str() : "", R13, 0x8A8E95);
            lv_obj_set_style_text_color(dl, c(0xFFFFFF), LV_STATE_PRESSED);
            lv_obj_align(dl, LV_ALIGN_RIGHT_MID, -8, 0);
            if (player::current() == ids[i]) {
                lv_obj_t* g = glyph(r, &gl_vol_hi, 0x2F7FEF);
                lv_obj_align(g, LV_ALIGN_LEFT_MID, 12, 0);
                lv_obj_add_flag(nl, LV_OBJ_FLAG_HIDDEN);
            }
            int idx = (int)i;
            on_click(r, [data, idx, nav] {
                if (!data->current() || idx < 0 || idx >= (int)data->ids.size()) return;
                player::play(data->ids, idx, player::shuffle());
                push_now_playing(nav);
            });
        }
        lv_obj_update_layout(col);
        lv_obj_scroll_to_y(col, scroll, LV_ANIM_OFF);
    };
    refresh();
    nav->top().on_show = watch_library(body, refresh);
}

void push_albums(os::Nav* nav, const char* title, const std::string& artist) {
    lv_obj_t* body = nav->push(title);
    struct Data : LibraryRevision { std::vector<std::string> albums; std::string artist; std::vector<int> art; os::VList* list = nullptr; lv_obj_t* empty = nullptr; };
    auto data = std::make_shared<Data>();
    data->artist = artist;
    auto refresh = [body, data, nav] {
        data->albums = lib::albums(data->artist);
        data->art.clear();
        for (const auto& album : data->albums) {
            int id = lib::album_art_track(album, data->artist);
            if (id < 0) { auto songs = lib::songs_of_album(album, data->artist); id = songs.empty() ? -1 : songs[0]; }
            data->art.push_back(id);
        }
        data->accept();
        int off = !data->artist.empty() && !data->albums.empty() ? 1 : 0;
        os::VListSpec sp;
        sp.count = (int)data->albums.size() + off;
        sp.row_h = 44;
        sp.thumbs = true;
        sp.subtitle = true;
        sp.bind = [data, off](int i, os::VRow& r) {
            if (!data->current() || i < 0 || i >= (int)data->albums.size() + off) { clear_row(r, 44); return; }
            if (i < off) {
                th::label_set_text(r.title, "All Songs");
                th::label_set_text(r.sub, "");
                set_art(r.img, -1, 44);
                return;
            }
            th::label_set_text(r.title, data->albums[i - off].c_str());
            const lib::Track* t = lib::get(data->art[i - off]);
            th::label_set_text(r.sub, t ? (t->shown_artist().empty() ? "Unknown Artist" : t->shown_artist().c_str()) : "");
            set_art(r.img, data->art[i - off], 44);
        };
        sp.click = [data, off, nav](int i) {
            if (!data->current() || i < 0 || i >= (int)data->albums.size() + off) return;
            std::string artist = data->artist;
            if (i < off) push_songs(nav, "All Songs", [artist] { return lib::songs_by_artist(artist); }, true, Sub::Album, false);
            else push_album(nav, data->albums[i - off], artist);
        };
        if (data->albums.size() > 30) sp.index = letter_index(data->albums, off);
        if (data->list) reset_list(data->list, sp);
        else data->list = new os::VList(body, sp);
        list_empty_state(body, data->list, data->empty, sp.count == 0, "No Albums");
    };
    refresh();
    nav->top().on_show = watch_library(body, refresh);
}

} // namespace media

/* ======================================================================= app */
static os::Nav* s_nav = nullptr;
static bool s_open_np = false;

static void build_root() {
    using namespace media;
    lv_obj_t* body = s_nav->push("Music", os::NavStyle::Light, false);
    lv_obj_t* col = os::scroll_column(body);
    auto rebuild = [col] {
        lv_obj_clean(col);
        if (lib::count(lib::K_MUSIC) == 0) {
            os::list_empty(col, lib::scanning() ? "Updating Library\xE2\x80\xA6" : "No Music",
                           lib::scanning() ? nullptr : "Copy songs to the Music folder on the microSD card.");
            return;
        }
        if (player::active()) {
            os::RowOpts o; o.text = "Now Playing"; o.chevron = true; o.color = 0x1F5FCC;
            os::list_row(col, o, [] { push_now_playing(s_nav); });
        }
        struct Item { const char* name; std::function<void()> fn; };
        std::vector<Item> items = {
            {"Playlists", [] {
                push_name_list(s_nav, "Playlists", [] {
                    std::vector<std::string> names;
                    for (const auto& playlist : lib::playlists()) names.push_back(playlist.name);
                    return names;
                }, [](const std::string& name, int index) {
                    /* Resolve against today's library; preserve distinct paths even for duplicate names. */
                    auto playlists = lib::playlists();
                    if (index >= 0 && index < (int)playlists.size() && playlists[index].name == name) {
                        std::string path = playlists[index].path;
                        bool smart = playlists[index].smart;
                        push_songs(s_nav, name.c_str(), [path, name, smart] {
                            for (const auto& current : lib::playlists())
                                if (current.path == path && current.name == name && current.smart == smart) return current.items;
                            return std::vector<int>();
                        }, true, Sub::Artist, false);
                    }
                }, false);
            }},
            {"Artists", [] {
                push_name_list(s_nav, "Artists", [] { return lib::artists(); }, [](const std::string& name, int) {
                    auto albums = lib::albums(name);
                    if (albums.size() == 1) push_album(s_nav, albums[0], name);
                    else push_albums(s_nav, name.c_str(), name);
                });
            }},
            {"Albums", [] { push_albums(s_nav, "Albums", ""); }},
            {"Songs", [] { push_songs(s_nav, "Songs", [] { return lib::songs(); }, true, Sub::Artist); }},
            {"Genres", [] {
                push_name_list(s_nav, "Genres", [] { return lib::genres(); }, [](const std::string& name, int) {
                    push_songs(s_nav, name.c_str(), [name] { return lib::songs_of_genre(name); }, true, Sub::Artist);
                }, false);
            }},
            {"Composers", [] {
                push_name_list(s_nav, "Composers", [] { return lib::composers(); }, [](const std::string& name, int) {
                    push_songs(s_nav, name.c_str(), [name] { return lib::songs_of_composer(name); }, true, Sub::Artist);
                });
            }},
        };
        for (auto& it : items) {
            os::RowOpts o; o.text = it.name; o.chevron = true;
            os::list_row(col, o, it.fn);
        }
    };
    rebuild();
    s_nav->top().on_show = rebuild;
    /* refresh when a background scan finishes */
    static int seen = 0;
    seen = lib::version();
    os::every(500, [rebuild] {
        if (lib::version() != seen && s_nav && s_nav->depth() == 1) { seen = lib::version(); rebuild(); }
    }, col);
}

void app_music_open(lv_obj_t* root) {
    s_nav = new os::Nav(root);
    build_root();
    if (s_open_np && player::active()) media::push_now_playing(s_nav, false);
    s_open_np = false;
}
void app_music_close() { s_nav = nullptr; }

/* "nowplaying" is the Music app opened straight into Now Playing (the nano's double-press Home) */
void app_nowplaying_open(lv_obj_t* root) { s_open_np = true; app_music_open(root); }
void app_nowplaying_close() { app_music_close(); }

void music_now_playing_shortcut() {
    if (!player::active()) return;
    const os::App* cur = os::current_app();
    if (cur && (!strcmp(cur->id, "music") || !strcmp(cur->id, "nowplaying")) && s_nav) {
        lv_obj_t* top = s_nav->top().obj;
        if (lv_obj_get_user_data(top) == media::NP_TAG) return;      /* already there */
        /* the Track List sits directly on top of Now Playing: go back instead of stacking */
        if (lv_obj_get_user_data(top) == media::QUEUE_TAG && s_nav->depth() > 1) { s_nav->pop(true); return; }
        media::push_now_playing(s_nav);
        return;
    }
    s_open_np = true;
    os::launch("music");
    s_open_np = false;     /* consumed by app_music_open; don't leak it if the launch was refused */
}
