/* Podcasts & Audiobooks — shows / books with artwork, episodes with unplayed dots, resume bookmarks. */
#include "media_ui.h"

using namespace th;

static os::Nav* s_nav = nullptr;

static void push_episodes(lib::Kind k, const std::string& show) {
    lv_obj_t* body = s_nav->push(show.c_str());
    struct Data : media::LibraryRevision { std::vector<int> ids; os::VList* list = nullptr; lv_obj_t* empty = nullptr; };
    auto data = std::make_shared<Data>();
    os::Nav* nav = s_nav;
    auto refresh = [body, data, k, show, nav] {
        data->ids = lib::shows(k, show);
        data->accept();
        os::VListSpec sp;
        sp.count = (int)data->ids.size();
        sp.row_h = 46;
        sp.subtitle = true;
        sp.chevron = false;
        sp.dots = true;
        sp.bind = [data](int i, os::VRow& r) {
            media::clear_row(r);
            if (!data->current() || i < 0 || i >= (int)data->ids.size()) return;
            const lib::Track* t = lib::get(data->ids[i]);
            if (!t) return;
            th::label_set_text(r.title, t->title.c_str());
            char b[64];
            if (t->bookmark_ms > 5000 && t->dur_ms) {
                const uint32_t remaining = t->bookmark_ms < t->dur_ms ? t->dur_ms - t->bookmark_ms : 0;
                snprintf(b, sizeof b, "%s remaining", fmt_time_ms(remaining).c_str());
            }
            else if (t->dur_ms) snprintf(b, sizeof b, "%s", fmt_time_ms(t->dur_ms).c_str());
            else b[0] = 0;
            th::label_set_text(r.sub, b);
            if (!t->plays && t->bookmark_ms < 5000) lv_obj_remove_flag(r.dot, LV_OBJ_FLAG_HIDDEN);
        };
        sp.click = [data, nav](int i) {
            if (!data->current() || i < 0 || i >= (int)data->ids.size() || !lib::get(data->ids[i])) return;
            player::play(data->ids, i, false);
            media::push_now_playing(nav);
        };
        if (data->list) media::reset_list(data->list, sp);
        else data->list = new os::VList(body, sp);
        media::list_empty_state(body, data->list, data->empty, sp.count == 0, "No Items");
    };
    refresh();
    nav->top().on_show = media::watch_library(body, refresh);
}

static void open_kind(lv_obj_t* root, lib::Kind k, const char* title, const char* empty_hint) {
    s_nav = new os::Nav(root);
    lv_obj_t* body = s_nav->push(title, os::NavStyle::Light, false);
    struct Data : media::LibraryRevision {
        std::vector<std::string> shows;
        std::vector<int> art, unplayed, counts;
        lib::Kind kind;
        os::VList* list = nullptr;
        lv_obj_t* empty = nullptr;
    };
    auto data = std::make_shared<Data>();
    data->kind = k;
    auto refresh = [body, data, empty_hint] {
        data->shows = lib::albums("", data->kind);
        data->art.clear();
        data->unplayed.clear();
        data->counts.clear();
        for (const auto& show : data->shows) {
            auto episodes = lib::shows(data->kind, show);
            int artwork = -1, unplayed = 0;
            for (int id : episodes) {
                const lib::Track* track = lib::get(id);
                if (!track) continue;
                if (artwork < 0 && track->art_type) artwork = id;
                if (!track->plays) unplayed++;
            }
            data->art.push_back(artwork >= 0 ? artwork : (episodes.empty() ? -1 : episodes[0]));
            data->unplayed.push_back(unplayed);
            data->counts.push_back((int)episodes.size());
        }
        data->accept();
        os::VListSpec sp;
        sp.count = (int)data->shows.size();
        sp.row_h = 56;
        sp.thumbs = true;
        sp.subtitle = true;
        sp.bind = [data](int i, os::VRow& row) {
            if (!data->current() || i < 0 || i >= (int)data->shows.size()) { media::clear_row(row, 56); return; }
            th::label_set_text(row.title, data->shows[i].c_str());
            const lib::Track* track = lib::get(data->art[i]);
            char text[48];
            int count = data->counts[i];
            if (data->kind == lib::K_PODCAST) snprintf(text, sizeof text, "%d episode%s", count, count == 1 ? "" : "s");
            else snprintf(text, sizeof text, "%s", track && !track->artist.empty() ? track->artist.c_str() : "");
            th::label_set_text(row.sub, text);
            if (data->unplayed[i]) { snprintf(text, sizeof text, "%d", data->unplayed[i]); th::label_set_text(row.detail, data->kind == lib::K_PODCAST ? text : ""); }
            else th::label_set_text(row.detail, "");
            media::set_art(row.img, data->art[i], 56);
        };
        sp.click = [data](int i) {
            if (!data->current() || i < 0 || i >= (int)data->shows.size()) return;
            push_episodes(data->kind, data->shows[i]);
        };
        if (data->list) media::reset_list(data->list, sp);
        else data->list = new os::VList(body, sp);
        media::list_empty_state(body, data->list, data->empty, sp.count == 0,
                               data->kind == lib::K_PODCAST ? "No Podcasts" : "No Audiobooks", empty_hint);
    };
    refresh();
    /* Plays/bookmarks do not bump the library revision. Recompute badges whenever
     * returning from an episode or Now Playing as well as after a rescan. */
    s_nav->top().on_show = media::watch_library(body, refresh);
}

void app_podcasts_open(lv_obj_t* root) { open_kind(root, lib::K_PODCAST, "Podcasts", "Copy episodes into folders (one per show) inside the Podcasts folder on the microSD card."); }
void app_podcasts_close() { s_nav = nullptr; }
void app_audiobooks_open(lv_obj_t* root) { open_kind(root, lib::K_AUDIOBOOK, "Audiobooks", "Copy each book into its own folder inside the Audiobooks folder on the microSD card."); }
void app_audiobooks_close() { s_nav = nullptr; }
